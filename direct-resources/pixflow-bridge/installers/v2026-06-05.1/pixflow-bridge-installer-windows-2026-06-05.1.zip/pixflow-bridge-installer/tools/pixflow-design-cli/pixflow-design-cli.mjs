#!/usr/bin/env node

import fs from 'node:fs/promises';
import { createWriteStream, existsSync, readFileSync, readdirSync } from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { inflateSync } from 'node:zlib';

const VERSION = '0.2.6';
const DEFAULT_REST_NAMESPACE = 'pixflow-ai/v1';
const DEFAULT_STAGE = 'stage_a';
const DEFAULT_STAGE_A_REPAIR_ATTEMPTS = 1;
const DEFAULT_STAGE_B_REPAIR_ATTEMPTS = 1;
const DEFAULT_STAGE_B_MIN_QA_SCORE = 97;
const BRIDGE_DAEMON_PROTOCOL_VERSION = '2026-06-04.2';
const DEFAULT_BRIDGE_DAEMON_PORT = 47873;
const DEFAULT_BRIDGE_DAEMON_HOST = '127.0.0.1';
const BRIDGE_AGENT_CATALOG = [
  {
    id: 'claude',
    label: 'Claude Code',
    description: 'Anthropic official CLI',
    commands: ['claude', 'openclaude'],
    versionArgs: ['--version'],
    docsUrl: 'https://docs.anthropic.com/en/docs/claude-code',
    installUrl: 'https://docs.anthropic.com/en/docs/claude-code/setup',
    supportStatus: 'stage_runner_ready',
  },
  {
    id: 'codex',
    label: 'Codex CLI',
    description: 'OpenAI official CLI',
    commands: ['codex'],
    versionArgs: ['--version'],
    docsUrl: 'https://developers.openai.com/codex',
    installUrl: 'https://github.com/openai/codex',
    supportStatus: 'stage_runner_ready',
    authProbe: {
      args: ['debug', 'models'],
      label: 'codex debug models',
    },
  },
  {
    id: 'devin',
    label: 'Devin for Terminal',
    description: 'Cognition terminal CLI',
    commands: ['devin'],
    versionArgs: ['--version'],
    docsUrl: 'https://docs.devin.ai',
    installUrl: 'https://cli.devin.ai/docs',
    supportStatus: 'detected',
  },
  {
    id: 'gemini',
    label: 'Gemini CLI',
    description: 'Google official CLI',
    commands: ['gemini'],
    versionArgs: ['--version'],
    docsUrl: 'https://github.com/google-gemini/gemini-cli/blob/main/README.md',
    installUrl: 'https://github.com/google-gemini/gemini-cli',
    supportStatus: 'stage_runner_ready',
  },
  {
    id: 'opencode',
    label: 'OpenCode',
    description: 'Open-source agent CLI',
    commands: ['opencode-cli', 'opencode'],
    versionArgs: ['--version'],
    docsUrl: 'https://github.com/sst/opencode',
    installUrl: 'https://opencode.ai/docs',
    supportStatus: 'stage_runner_ready',
    authProbe: {
      args: ['models'],
      label: 'opencode models',
    },
  },
  {
    id: 'hermes',
    label: 'Hermes',
    description: 'ACP agent CLI',
    commands: ['hermes'],
    versionArgs: ['--version'],
    docsUrl: 'https://hermes-agent.nousresearch.com/docs/',
    installUrl: 'https://hermes-agent.nousresearch.com/docs/',
    supportStatus: 'detected',
  },
  {
    id: 'trae-cli',
    label: 'Trae CLI',
    description: 'Trae coding CLI',
    commands: ['traecli'],
    versionArgs: ['--version'],
    docsUrl: 'https://www.volcengine.com/docs/86677/2227861?lang=zh',
    installUrl: 'https://www.volcengine.com/docs/86677/2227861?lang=zh',
    supportStatus: 'detected',
  },
  {
    id: 'grok-build',
    label: 'Grok Build',
    description: 'xAI coding CLI',
    commands: ['grok'],
    versionArgs: ['--version'],
    docsUrl: 'https://x.ai/cli',
    installUrl: 'https://x.ai/cli',
    supportStatus: 'detected',
  },
  {
    id: 'kimi',
    label: 'Kimi CLI',
    description: 'Moonshot Kimi CLI',
    commands: ['kimi'],
    versionArgs: ['--version'],
    docsUrl: 'https://www.kimi.com/code/docs/en/kimi-cli/guides/getting-started.html',
    installUrl: 'https://github.com/MoonshotAI/kimi-cli',
    supportStatus: 'detected',
  },
  {
    id: 'cursor-agent',
    label: 'Cursor Agent',
    description: 'Cursor command line',
    commands: ['cursor-agent'],
    versionArgs: ['--version'],
    docsUrl: 'https://docs.cursor.com/en/cli/overview',
    installUrl: 'https://cursor.com/docs/cli/overview',
    supportStatus: 'stage_runner_ready',
    authProbe: {
      args: ['status'],
      label: 'cursor-agent status',
    },
  },
  {
    id: 'qwen',
    label: 'Qwen Code',
    description: 'Qwen coding CLI',
    commands: ['qwen'],
    versionArgs: ['--version'],
    docsUrl: 'https://qwenlm.github.io/qwen-code-docs/en/index',
    installUrl: 'https://github.com/QwenLM/qwen-code',
    supportStatus: 'stage_runner_ready',
  },
  {
    id: 'qoder',
    label: 'Qoder CLI',
    description: 'Alibaba coding CLI',
    commands: ['qodercli'],
    versionArgs: ['--version'],
    docsUrl: 'https://docs.qoder.com',
    installUrl: 'https://qoder.com/download',
    supportStatus: 'detected',
  },
  {
    id: 'copilot',
    label: 'GitHub Copilot CLI',
    description: 'GitHub coding CLI',
    commands: ['copilot'],
    versionArgs: ['--version'],
    docsUrl: 'https://docs.github.com/en/copilot/how-tos/use-copilot-extensions/use-in-cli',
    installUrl: 'https://github.com/github/copilot-cli',
    supportStatus: 'detected',
  },
  {
    id: 'pi',
    label: 'Pi',
    description: 'Inflection chat CLI',
    commands: ['pi'],
    versionArgs: ['--version'],
    docsUrl: 'https://github.com/badlogic/pi-mono/blob/main/packages/coding-agent/README.md',
    installUrl: 'https://github.com/badlogic/pi-mono/blob/main/packages/coding-agent/README.md',
    supportStatus: 'detected',
  },
  {
    id: 'kiro',
    label: 'Kiro CLI',
    description: 'Kiro agent CLI',
    commands: ['kiro-cli'],
    versionArgs: ['--version'],
    docsUrl: 'https://kiro.dev/docs/cli/',
    installUrl: 'https://kiro.dev',
    supportStatus: 'detected',
  },
  {
    id: 'kilo',
    label: 'Kilo',
    description: 'Kilo Code CLI',
    commands: ['kilo'],
    versionArgs: ['--version'],
    docsUrl: 'https://kilo.ai/docs/cli',
    installUrl: 'https://kilo.ai',
    supportStatus: 'detected',
  },
  {
    id: 'vibe',
    label: 'Mistral Vibe CLI',
    description: 'Mistral open-source CLI',
    commands: ['vibe-acp'],
    versionArgs: ['--version'],
    docsUrl: 'https://github.com/mistralai/vibe-acp',
    installUrl: 'https://docs.mistral.ai',
    supportStatus: 'detected',
  },
  {
    id: 'deepseek',
    label: 'DeepSeek TUI',
    description: 'DeepSeek terminal UI',
    commands: ['deepseek', 'codewhale'],
    versionArgs: ['--version'],
    docsUrl: 'https://github.com/Hmbown/CodeWhale/blob/main/README.md',
    installUrl: 'https://github.com/Hmbown/CodeWhale',
    supportStatus: 'detected',
  },
  {
    id: 'aider',
    label: 'Aider',
    description: 'Aider coding CLI',
    commands: ['aider'],
    versionArgs: ['--version'],
    docsUrl: 'https://aider.chat',
    installUrl: 'https://aider.chat/docs/install.html',
    supportStatus: 'detected',
  },
  {
    id: 'antigravity',
    label: 'Antigravity',
    description: 'Google Antigravity CLI',
    commands: ['antigravity', 'agy'],
    versionArgs: ['--version'],
    docsUrl: 'https://antigravity.google/docs/cli-overview',
    installUrl: 'https://antigravity.google',
    supportStatus: 'detected',
  },
  {
    id: 'reasonix',
    label: 'DeepSeek Reasonix',
    description: 'DeepSeek native coding CLI',
    commands: ['reasonix', 'dsnix'],
    versionArgs: ['--version'],
    docsUrl: 'https://esengine.github.io/DeepSeek-Reasonix/',
    installUrl: 'https://esengine.github.io/DeepSeek-Reasonix/',
    supportStatus: 'detected',
  },
];

const BRIDGE_STAGE_RUNNER_AGENT_IDS = new Set(
  BRIDGE_AGENT_CATALOG
    .filter((agent) => agent.supportStatus === 'stage_runner_ready')
    .map((agent) => agent.id)
);
const BRIDGE_STAGE_RUNNER_ALIASES = new Map([
  ['claude-code', 'claude'],
  ['openclaude', 'claude'],
  ['openai', 'codex'],
  ['opencode-cli', 'opencode'],
  ['cursor', 'cursor-agent'],
  ['cursoragent', 'cursor-agent'],
  ['qwen-code', 'qwen'],
]);

const COMMANDS = new Set([
  'daemon',
  'status',
  'resources',
  'preflight',
  'prepare-stage-a',
  'run-stage-a',
  'repair-stage-a',
  'prepare-stage-b',
  'run-stage-b',
  'repair-stage-b',
  'import-stage-b',
  'insert-stage-b',
  'import-artifact',
  'stage-a-status',
  'pair-url',
  'help',
]);

async function main() {
  const parsed = parseArgs(process.argv.slice(2));
  const command = parsed.command || 'help';

  if (!COMMANDS.has(command)) {
    printError(`Unknown command "${command}".`);
    printHelp();
    process.exitCode = 2;
    return;
  }

  if (command === 'help' || parsed.flags.help) {
    printHelp();
    return;
  }

  if (command === 'daemon') {
    await runBridgeDaemonCommand(parsed.positional.slice(1), parsed.flags);
    return;
  }

  if (command === 'pair-url') {
    const result = await pairBridgeFromProtocolUrl(parsed.positional.slice(1), parsed.flags);
    outputResult(result, parsed.flags, renderBridgeProtocolPairSummary);
    return;
  }

  if (command === 'prepare-stage-a') {
    const result = await prepareStageAWorkspace(parsed.flags);
    outputResult(result, parsed.flags, renderPrepareStageASummary);
    return;
  }

  if (command === 'run-stage-a') {
    const result = await runStageAWorkspace(parsed.flags);
    outputResult(result, parsed.flags, renderRunStageASummary);
    return;
  }

  if (command === 'repair-stage-a') {
    const result = await repairStageAWorkspace(parsed.flags);
    outputResult(result, parsed.flags, renderRunStageASummary);
    return;
  }

  if (command === 'prepare-stage-b') {
    const result = await prepareStageBWorkspace(parsed.flags);
    outputResult(result, parsed.flags, renderPrepareStageBSummary);
    return;
  }

  if (command === 'run-stage-b') {
    const result = await runStageBWorkspace(parsed.flags);
    outputResult(result, parsed.flags, renderRunStageBSummary);
    return;
  }

  if (command === 'repair-stage-b') {
    const result = await repairStageBWorkspace(parsed.flags);
    outputResult(result, parsed.flags, renderRunStageBSummary);
    return;
  }

  const config = await loadConfig(parsed.flags);
  const client = createPixflowClient(config);

  if (command === 'status') {
    const result = await client.post('/cli-bridge/status', {});
    outputResult(result, parsed.flags, renderStatusSummary);
    return;
  }

  if (command === 'resources') {
    const stage = config.stage || DEFAULT_STAGE;
    const result = await client.post('/cli-bridge/resources/status', { stage });
    outputResult(result, parsed.flags, renderResourcesSummary);
    return;
  }

  if (command === 'preflight') {
    const stage = config.stage || DEFAULT_STAGE;
    const [status, resources] = await Promise.all([
      client.post('/cli-bridge/status', {}),
      client.post('/cli-bridge/resources/status', { stage }),
    ]);
    const result = { status, resources };
    outputResult(result, parsed.flags, renderPreflightSummary);
    return;
  }

  if (command === 'import-artifact') {
    const payload = await buildImportArtifactPayload(parsed.flags);
    const result = await client.post('/cli-bridge/stage-a/import-artifact', payload);
    outputResult(result, parsed.flags, renderImportSummary);
    return;
  }

  if (command === 'import-stage-b') {
    const payload = await buildStageBImportPayload(parsed.flags);
    const result = await client.post('/cli-bridge/stage-b/import-result', payload);
    outputResult(result, parsed.flags, renderStageBImportSummary);
    return;
  }

  if (command === 'insert-stage-b') {
    const payload = await buildStageBInsertPayload(parsed.flags);
    const result = await client.post('/cli-bridge/stage-b/insert-page', payload);
    outputResult(result, parsed.flags, renderStageBInsertSummary);
    return;
  }

  if (command === 'stage-a-status') {
    const runId = firstString(parsed.flags.runId, parsed.flags.run, parsed.flags.run_id);
    if (!runId) {
      throw new CliError('Missing required --runId for stage-a-status.');
    }
    const result = await client.post('/cli-bridge/stage-a/status', { runId });
    outputResult(result, parsed.flags, renderStageAStatusSummary);
  }
}

function parseArgs(args) {
  const flags = {};
  const positional = [];

  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];

    if (!arg.startsWith('--')) {
      positional.push(arg);
      continue;
    }

    const eqIndex = arg.indexOf('=');
    if (eqIndex !== -1) {
      flags[arg.slice(2, eqIndex)] = arg.slice(eqIndex + 1);
      continue;
    }

    const key = arg.slice(2);
    const next = args[index + 1];
    if (next && !next.startsWith('--')) {
      flags[key] = next;
      index += 1;
    } else {
      flags[key] = true;
    }
  }

  return {
    command: positional[0] || '',
    positional,
    flags: normalizeFlags(flags),
  };
}

async function buildPixflowStageBHtmlBaseline({ htmlFile, plan, iconSystem }) {
  const html = await readTextFile(htmlFile, 'Stage A artifact for Stage B baseline');
  const cssText = extractStageBStyleText(html);
  const baseCssText = stripPixflowStageBAtRuleBlocks(cssText, 'media');
  const rules = extractStageBCssRuleSummaries(baseCssText);
  const classInfo = buildPixflowStageBHtmlClassInfo(html, cssText, rules);
  const documentRoot = parsePixflowStageBHtmlDocument(html);
  const body = findFirstPixflowHtmlElement(documentRoot, (node) => node.tag === 'body') || documentRoot;
  const roots = getPixflowStageBBodyRootNodes(body);
  const headerNodes = selectPixflowStageBHeaderNodes(documentRoot, plan);
  const footerNodes = selectPixflowStageBFooterNodes(documentRoot, plan);
  const pageSkipNodes = new Set([
    ...headerNodes.pageSkipNodes,
    ...footerNodes.pageSkipNodes,
  ]);

  const pageContext = createPixflowStageBHtmlCompilerContext({
    scope: 'page',
    plan,
    classInfo,
    iconSystem,
  });
  for (const node of roots) {
    compilePixflowStageBHtmlNode(node, '', pageContext, { pageSkipNodes });
  }

  const headerContext = createPixflowStageBHtmlCompilerContext({
    scope: 'header',
    plan,
    classInfo,
    iconSystem,
  });
  if (plan?.headerPlan?.includeHeader) {
    for (const node of headerNodes.templateNodes) {
      compilePixflowStageBHtmlNode(node, '', headerContext, { templatePart: 'header' });
    }
  }

  const footerContext = createPixflowStageBHtmlCompilerContext({
    scope: 'footer',
    plan,
    classInfo,
    iconSystem,
  });
  if (plan?.footerPlan?.includeFooter) {
    for (const node of footerNodes.templateNodes) {
      compilePixflowStageBHtmlNode(node, '', footerContext, { templatePart: 'footer' });
    }
  }

  const scriptCode = buildStageBJavaScriptCode(plan?.scripts || extractStageBScripts(html));
  const pageSettings = buildPixflowStageBPageSettings(scriptCode);

  const content = pageContext.content;
  const headerContent = headerContext.content;
  const footerContent = footerContext.content;
  const tokensUsed = extractPixflowStageBTokenReferences(`${html}\n${cssText}`);

  return {
    mode: 'pixflow_html_baseline',
    content,
    headerContent,
    footerContent,
    globalClasses: classInfo.globalClasses,
    pageSettings,
    tokensUsed,
    rawColorFallbacks: extractPixflowStageBRawColorFallbacks(cssText),
    summary: {
      parser: 'pixflow_clean_room_html_to_bricks_baseline',
      sourceHtmlLength: html.length,
      cssRuleCount: rules.length,
      classCount: classInfo.globalClasses.length,
      pageElementCount: content.length,
      headerElementCount: headerContent.length,
      footerElementCount: footerContent.length,
      pageSettingsScriptCount: pageSettings.customScriptsBodyFooter ? 1 : 0,
      skippedHeaderNodes: headerNodes.pageSkipNodes.length,
      skippedFooterNodes: footerNodes.pageSkipNodes.length,
    },
  };
}

function buildPixflowStageBPageSettings(scriptCode) {
  const code = firstString(scriptCode);
  if (!code) {
    return {};
  }
  return {
    customScriptsBodyFooter: `<script>\n${code}\n</script>`,
  };
}

function buildPixflowStageBHtmlClassInfo(html, cssText, rules) {
  const usage = extractStageBClassUsage(html);
  const usageByClass = new Map(usage.map((item) => [item.name, item]));
  const nestedInlineClassesByClass = extractPixflowStageBNestedInlineClassesByClass(html);
  const classNames = uniqueStrings([
    ...usage.map((item) => item.name),
    ...rules.flatMap((rule) => rule.classNames || []),
  ]).filter((name) => !/^od-root$/i.test(name));
  const cssVariables = extractPixflowStageBCssVariables(rules);
  const responsiveRulesByClass = extractPixflowStageBResponsiveClassRules(cssText, classNames, cssVariables);
  const tagDeclarationsByTag = extractPixflowStageBTagDeclarations(rules);
  const inheritedTextDeclarations = pickPixflowStageBInheritedTextDeclarations(tagDeclarationsByTag.get('body') || {});
  const syntheticClassIdByKey = new Map();
  const syntheticGlobalClasses = [];
  const lateSyntheticGlobalClasses = [];
  const usedPublicNames = new Set();
  const addSyntheticClass = (key, preferredName, settings) => {
    if (Object.keys(objectValue(settings)).length === 0) {
      return '';
    }
    const publicName = normalizePixflowStageBHtmlGlobalClassName(preferredName, usedPublicNames);
    const id = deterministicBricksId(`stage-b-html-synthetic-class:${key}`);
    syntheticClassIdByKey.set(key, id);
    syntheticGlobalClasses.push({ id, name: publicName, settings });
    return id;
  };
  const addLateSyntheticClass = (key, preferredName, settings) => {
    if (Object.keys(objectValue(settings)).length === 0) {
      return '';
    }
    const publicName = normalizePixflowStageBHtmlGlobalClassName(preferredName, usedPublicNames);
    const id = deterministicBricksId(`stage-b-html-synthetic-class:${key}`);
    syntheticClassIdByKey.set(key, id);
    lateSyntheticGlobalClasses.push({ id, name: publicName, settings });
    return id;
  };

  addSyntheticClass(
    'body',
    'stage-a-body-type',
    mapPixflowCssDeclarationsToBricksSettings(inheritedTextDeclarations, { cssVariables }),
  );
  for (const [tag, declarations] of tagDeclarationsByTag.entries()) {
    if (tag === 'body') {
      continue;
    }
    addSyntheticClass(
      `tag:${tag}`,
      `stage-a-${tag}-type`,
      mapPixflowCssDeclarationsToBricksSettings(declarations, { cssVariables }),
    );
  }
  addSyntheticClass('template:header-root', 'stage-a-header-template-reset', {
    _padding: { top: '0', right: '0', bottom: '0', left: '0' },
  });
  addSyntheticClass('template:footer-root', 'stage-a-footer-template-reset', {
    _padding: { top: '0', right: '0', bottom: '0', left: '0' },
  });

  const declarationsByClass = new Map();
  const customRulesByClass = new Map();

  for (const rule of rules) {
    const classNamesForRule = Array.isArray(rule.classNames) ? rule.classNames : [];
    for (const className of classNamesForRule) {
      if (!classNames.includes(className)) continue;
      if (isPixflowStageBSimpleClassSelector(rule.selector, className) && !declarationsByClass.has(className)) {
        const declarations = { ...objectValue(rule.declarations) };
        if (className === 'plate') {
          delete declarations.border;
          delete declarations['border-color'];
          delete declarations['border-style'];
          delete declarations['border-width'];
        }
        declarationsByClass.set(className, declarations);
      }
      const customRule = convertPixflowStageBCssRuleToRoot(rule, className, cssVariables);
      if (customRule) {
        const list = customRulesByClass.get(className) || [];
        list.push(customRule);
        customRulesByClass.set(className, list);
      }
    }
  }

  const workContainerShellSettings = buildPixflowStageBWorkContainerShellSettings(
    declarationsByClass.get('work'),
    declarationsByClass.get('section'),
    declarationsByClass.get('section-dark'),
    responsiveRulesByClass,
    cssVariables,
  );
  addLateSyntheticClass('work:container-shell', 'work-container-shell', workContainerShellSettings);

  const sourceGlobalClasses = classNames.map((className) => {
    const publicName = normalizePixflowStageBHtmlGlobalClassName(className, usedPublicNames);
    const declarations = declarationsByClass.get(className) || {};
    const settings = mapPixflowCssDeclarationsToBricksSettings(declarations, {
      cssVariables,
      preferFlexForGridCenter: shouldUsePixflowStageBFlexForInlineGridCenter(usageByClass.get(className), declarations),
    });
    applyPixflowStageBResponsiveSettings(settings, [className], { responsiveRulesByClass });
    if (className === 'work') {
      removePixflowStageBWorkSectionShellSettings(settings);
      applyPixflowStageBWorkSectionWrapperReset(settings);
    }
    applyPixflowStageBClassStyleHeuristics(settings, [className]);
    const customRules = [...(customRulesByClass.get(className) || [])];
    if (className === 'section') {
      const revealCss = buildPixflowStageBRevealCss(cssText);
      if (revealCss) customRules.push(revealCss);
    }
    if (className === 'marquee-track') {
      const keyframes = extractPixflowStageBKeyframes(cssText, 'marquee-x');
      if (keyframes) customRules.push(keyframes);
    }
    if (className === 'section-dark') {
      const themeVariableOverride = buildPixflowStageBDarkSectionThemeVariableOverride(declarations);
      if (themeVariableOverride) customRules.push(themeVariableOverride);
    }
    customRules.push(...buildPixflowStageBNestedInlineClassCustomRules(
      className,
      nestedInlineClassesByClass.get(className),
      declarationsByClass,
      cssVariables,
    ));
    if (customRules.length > 0) {
      settings._cssCustom = customRules.join('\n');
    }
    return {
      id: deterministicBricksId(`stage-b-html-class:${className}`),
      name: publicName,
      settings,
    };
  });
  const globalClasses = [...syntheticGlobalClasses, ...sourceGlobalClasses, ...lateSyntheticGlobalClasses];
  const sourceClassIdByName = new Map(classNames.map((className, index) => [className, sourceGlobalClasses[index].id]));

  return {
    usage,
    cssText,
    rules,
    classNames,
    globalClasses,
    declarationsByClass,
    responsiveRulesByClass,
    customRulesByClass,
    cssVariables,
    tagDeclarationsByTag,
    inheritedTextDeclarations,
    syntheticClassIdByKey,
    classIdByName: sourceClassIdByName,
  };
}

function parsePixflowStageBHtmlDocument(html) {
  const root = {
    type: 'root',
    tag: '#document',
    attrs: {},
    attrList: [],
    children: [],
    parent: null,
    sourceIndex: 0,
    contentStart: 0,
    contentEnd: String(html || '').length,
  };
  const stack = [root];
  const voidTags = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
  const pattern = /<!--[\s\S]*?-->|<!doctype[^>]*>|<[^>]+>/gi;
  let match;
  let lastIndex = 0;
  let sourceIndex = 1;

  while ((match = pattern.exec(String(html || ''))) !== null) {
    const token = match[0];
    if (match.index > lastIndex) {
      appendPixflowStageBHtmlText(stack[stack.length - 1], html.slice(lastIndex, match.index), sourceIndex++);
    }
    lastIndex = pattern.lastIndex;
    if (/^<!--/.test(token) || /^<!doctype/i.test(token)) {
      continue;
    }
    if (/^<\s*\//.test(token)) {
      const closingTag = (token.match(/^<\s*\/\s*([a-zA-Z0-9:-]+)/) || [])[1]?.toLowerCase();
      if (closingTag) {
        for (let index = stack.length - 1; index > 0; index -= 1) {
          const node = stack[index];
          node.contentEnd = match.index;
          if (node.tag === closingTag) {
            stack.length = index;
            break;
          }
        }
      }
      continue;
    }

    const open = token.match(/^<\s*([a-zA-Z0-9:-]+)([\s\S]*?)(\/?)>$/);
    if (!open) {
      continue;
    }
    const tag = String(open[1] || '').toLowerCase();
    const attrText = open[2] || '';
    const attrList = parsePixflowStageBHtmlAttributes(attrText);
    const attrs = {};
    for (const attr of attrList) {
      attrs[attr.name.toLowerCase()] = attr.value;
    }
    const node = {
      type: 'element',
      tag,
      attrs,
      attrList,
      children: [],
      parent: stack[stack.length - 1],
      sourceIndex: sourceIndex++,
      openTag: token,
      contentStart: pattern.lastIndex,
      contentEnd: pattern.lastIndex,
    };
    stack[stack.length - 1].children.push(node);
    const selfClosing = Boolean(open[3]) || voidTags.has(tag);
    if (!selfClosing) {
      stack.push(node);
    }
  }

  if (lastIndex < String(html || '').length) {
    appendPixflowStageBHtmlText(stack[stack.length - 1], html.slice(lastIndex), sourceIndex++);
  }
  while (stack.length > 1) {
    const node = stack.pop();
    node.contentEnd = String(html || '').length;
  }
  root.rawHtml = String(html || '');
  return root;
}

function appendPixflowStageBHtmlText(parent, text, sourceIndex) {
  if (!text) return;
  parent.children.push({
    type: 'text',
    text,
    children: [],
    parent,
    sourceIndex,
  });
}

function parsePixflowStageBHtmlAttributes(attrText) {
  const attrs = [];
  const pattern = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
  let match;
  while ((match = pattern.exec(String(attrText || ''))) !== null) {
    const name = String(match[1] || '').trim();
    if (!name || name === '/') continue;
    const value = match[2] !== undefined ? match[2] : (match[3] !== undefined ? match[3] : (match[4] !== undefined ? match[4] : ''));
    attrs.push({ name, value: decodeHtmlEntities(value) });
  }
  return attrs;
}

function createPixflowStageBHtmlCompilerContext({ scope, plan, classInfo, iconSystem }) {
  return {
    scope,
    plan,
    classInfo,
    iconSystem: iconSystem || {},
    content: [],
    elementsById: new Map(),
  };
}

function compilePixflowStageBHtmlNode(node, parentId, context, options = {}) {
  if (!node) return '';
  if (node.type === 'text') {
    const text = normalizeWhitespace(decodeHtmlEntities(node.text));
    if (!text || !parentId) return '';
    const settings = { text };
    if (isPixflowStageBInlineTextParentNode(options.parentNode)) {
      settings.tag = 'span';
    }
    return addPixflowStageBHtmlElement(context, `text:${node.sourceIndex}`, 'text-basic', settings, parentId);
  }
  if (node.type !== 'element') return '';
  if (options.pageSkipNodes && options.pageSkipNodes.has(node)) {
    return '';
  }

  const tag = node.tag;
  if (['html', 'body', 'main'].includes(tag) || isPixflowStageBPageWrapper(node)) {
    for (const child of node.children || []) {
      compilePixflowStageBHtmlNode(child, parentId, context, options);
    }
    return '';
  }
  if (['head', 'style', 'script', 'meta', 'link', 'title', 'noscript', 'template'].includes(tag)) {
    return '';
  }
  if (tag === 'svg') {
    return addPixflowStageBHtmlIconElement(node, parentId, context);
  }

  const classNames = pixflowStageBHtmlClassList(node);
  const settings = buildPixflowStageBElementBaseSettings(node, context, options, parentId);
  const { name, wholeNode } = resolvePixflowStageBBricksElement(node, settings);
  const elementId = addPixflowStageBHtmlElement(
    context,
    `${context.scope}:${tag}:${node.sourceIndex}:${classNames.join('.')}`,
    name,
    settings,
    parentId,
  );

  if (!wholeNode) {
    for (const child of node.children || []) {
      compilePixflowStageBHtmlNode(child, elementId, context, { ...options, parentNode: node });
    }
  }
  return elementId;
}

function resolvePixflowStageBBricksElement(node, settings) {
  const tag = node.tag;
  if (tag === 'div' && isPixflowStageBStructuralContainerNode(node)) {
    return { name: 'container', wholeNode: false };
  }
  if (/^h[1-6]$/.test(tag)) {
    settings.tag = tag;
    settings.text = sanitizePixflowStageBInlineHtml(pixflowStageBNodeInnerHtml(node));
    return { name: 'heading', wholeNode: true };
  }
  if (tag === 'img') {
    const src = pixflowStageBAttr(node, 'src');
    settings.image = { url: src };
    settings.altText = pixflowStageBAttr(node, 'alt');
    return { name: 'image', wholeNode: true };
  }
  if (tag === 'a') {
    const href = pixflowStageBAttr(node, 'href');
    if (isPixflowStageBCtaNode(node)) {
      settings.text = normalizeWhitespace(pixflowStageBNodeText(node));
      if (href) {
        settings.link = { type: 'external', url: href };
      }
      settings.icon = buildPixflowStageBActionIconSetting(node);
      settings.iconPosition = 'right';
      return { name: 'button', wholeNode: true };
    }
    if (hasPixflowStageBElementChildren(node)) {
      applyPixflowStageBStructuralAnchorSettings(settings, node, href);
      return { name: 'div', wholeNode: false };
    }
    settings.text = sanitizePixflowStageBInlineHtml(pixflowStageBNodeInnerHtml(node));
    if (href) {
      settings.link = { type: 'external', url: href };
    }
    return { name: 'text-link', wholeNode: true };
  }
  if (tag === 'button') {
    settings.text = normalizeWhitespace(pixflowStageBNodeText(node));
    settings.icon = buildPixflowStageBActionIconSetting(node);
    settings.iconPosition = 'right';
    return { name: 'button', wholeNode: true };
  }
  if (['p', 'blockquote', 'label'].includes(tag)) {
    settings.tag = tag;
    settings.text = sanitizePixflowStageBInlineHtml(pixflowStageBNodeInnerHtml(node));
    return { name: 'text-basic', wholeNode: true };
  }
  if (tag === 'span' && isPixflowStageBEmptyDecorativeInlineNode(node)) {
    settings.tag = 'span';
    return { name: 'div', wholeNode: false };
  }
  if (isPixflowStageBCollapsibleInlineTextNode(node)) {
    settings.tag = tag === 'span' ? 'span' : 'custom';
    if (tag !== 'span') {
      settings.customTag = tag;
    }
    settings.text = sanitizePixflowStageBInlineHtml(pixflowStageBNodeInnerHtml(node));
    return { name: 'text-basic', wholeNode: true };
  }
  if (tag === 'span' && hasPixflowStageBElementChildren(node)) {
    settings.tag = 'custom';
    settings.customTag = 'span';
    return { name: 'div', wholeNode: false };
  }
  if (['span', 'small', 'strong', 'b', 'em', 'code'].includes(tag) && !hasPixflowStageBElementChildren(node)) {
    settings.tag = tag === 'span' ? 'span' : 'custom';
    if (tag !== 'span') {
      settings.customTag = tag;
    }
    settings.text = sanitizePixflowStageBInlineHtml(pixflowStageBNodeInnerHtml(node));
    return { name: 'text-basic', wholeNode: true };
  }
  if (['section', 'header', 'footer'].includes(tag)) {
    if (tag !== 'section') {
      settings.tag = tag;
    }
    return { name: 'section', wholeNode: false };
  }
  if (tag === 'nav') {
    settings.tag = 'nav';
    return { name: 'div', wholeNode: false };
  }
  if (['article', 'aside'].includes(tag)) {
    settings.tag = tag;
    return { name: 'div', wholeNode: false };
  }
  if (tag === 'br') {
    settings.text = '';
    return { name: 'text-basic', wholeNode: true };
  }
  return { name: 'div', wholeNode: false };
}

function addPixflowStageBHtmlIconElement(node, parentId, context) {
  if (!parentId) return '';
  const iconId = inferPixflowStageBIconId(node);
  return addPixflowStageBHtmlElement(context, `${context.scope}:icon:${node.sourceIndex}:${iconId}`, 'icon', {
    icon: {
      library: 'pixflowSvg',
      icon: buildStageBIconPlaceholder(firstString(context.iconSystem?.defaultSetId, 'tabler-outline'), iconId),
    },
  }, parentId);
}

function addPixflowStageBHtmlElement(context, seed, name, settings = {}, parent = '') {
  const id = deterministicBricksId(`stage-b-html-element:${seed}`);
  const element = {
    id,
    name,
    settings: removeUndefinedObjectValues(settings),
    children: [],
  };
  if (parent) {
    element.parent = parent;
  }
  context.content.push(element);
  context.elementsById.set(id, element);
  if (parent) {
    const parentElement = context.elementsById.get(parent);
    if (parentElement && !parentElement.children.includes(id)) {
      parentElement.children.push(id);
    }
  }
  return id;
}

function buildPixflowStageBElementBaseSettings(node, context, options = {}, parentId = '') {
  const settings = {};
  const classNames = pixflowStageBHtmlClassList(node);
  const classIds = [];
  const tag = firstString(node?.tag).toLowerCase();
  const bodyClassId = context.classInfo.syntheticClassIdByKey?.get('body');
  const tagClassId = context.classInfo.syntheticClassIdByKey?.get(`tag:${tag}`);
  if (bodyClassId && shouldAttachPixflowStageBBodyTypeClass(node, parentId)) {
    classIds.push(bodyClassId);
  }
  if (tagClassId) {
    classIds.push(tagClassId);
  }
  if (!parentId && options.templatePart === 'header') {
    const resetClassId = context.classInfo.syntheticClassIdByKey?.get('template:header-root');
    if (resetClassId) classIds.push(resetClassId);
  }
  if (!parentId && options.templatePart === 'footer') {
    const resetClassId = context.classInfo.syntheticClassIdByKey?.get('template:footer-root');
    if (resetClassId) classIds.push(resetClassId);
  }
  classIds.push(...classNames
    .map((className) => context.classInfo.classIdByName.get(className))
    .filter(Boolean));
  if (isPixflowStageBWorkInnerContainerNode(node)) {
    const workShellClassId = context.classInfo.syntheticClassIdByKey?.get('work:container-shell');
    if (workShellClassId) classIds.push(workShellClassId);
  }
  if (classIds.length > 0) {
    settings._cssGlobalClasses = uniqueStrings(classIds);
  }
  const attributes = buildPixflowStageBHtmlBricksAttributes(node, `${context.scope}:${node.tag}:${node.sourceIndex}`);
  if (attributes.length > 0) {
    settings._attributes = attributes;
  }
  return settings;
}

function applyPixflowStageBClassStyleHeuristics(settings, classNames) {
  const classText = classNames.join(' ');
  if (settings._display === 'flex' && /\b(?:nav|links|actions?|menu|footer-nav|header-nav)\b/i.test(classText) && !settings._flexWrap) {
    settings._flexWrap = 'wrap';
  }
  if (settings._display === 'flex' && /\b(?:nav|links|menu|footer-nav|header-nav)\b/i.test(classText) && !settings._justifyContent) {
    settings._justifyContent = 'center';
  }
  if (settings._display === 'flex' && /\b(?:nav-inner|header-inner)\b/i.test(classText) && !settings['_direction:mobile_portrait']) {
    settings['_direction:mobile_portrait'] = 'column';
  }
  return settings;
}

function shouldAttachPixflowStageBBodyTypeClass(node, parentId) {
  const tag = firstString(node?.tag).toLowerCase();
  if (!tag) {
    return false;
  }
  if (!parentId) {
    return /^(?:section|header|footer|nav|div|article|aside)$/.test(tag);
  }
  return false;
}

function isPixflowStageBStructuralContainerNode(node) {
  return node?.tag === 'div'
    && pixflowStageBHtmlClassList(node).includes('container')
    && /^(?:section|header|footer)$/.test(firstString(node?.parent?.tag).toLowerCase());
}

function isPixflowStageBWorkInnerContainerNode(node) {
  return isPixflowStageBStructuralContainerNode(node)
    && pixflowStageBHtmlClassList(node?.parent).includes('work');
}

function buildPixflowStageBWorkContainerShellSettings(workDeclarations, sectionDeclarations, sectionDarkDeclarations, responsiveRulesByClass, cssVariables) {
  const declarations = {
    ...pickPixflowStageBSectionShellDeclarations(sectionDeclarations, sectionDarkDeclarations),
    ...pickPixflowStageBWorkShellDeclarations(workDeclarations),
  };
  const settings = mapPixflowCssDeclarationsToBricksSettings(declarations, { cssVariables });
  applyPixflowStageBResponsiveSettings(settings, ['section', 'work'], { responsiveRulesByClass });
  removePixflowStageBNonShellResponsiveSettings(settings);
  return settings;
}

function buildPixflowStageBDarkSectionThemeVariableOverride(declarations) {
  const textColor = firstString(objectValue(declarations).color, 'var(--inverse)');
  return [
    `%root% { --heading: ${textColor}; --text: ${textColor}; }`,
    `%root% .stat-label b, %root% .stat-label strong { color: ${textColor}; }`,
  ].join('\n');
}

function pickPixflowStageBSectionShellDeclarations(sectionDeclarations, sectionDarkDeclarations) {
  const picked = {};
  const section = objectValue(sectionDeclarations);
  const dark = objectValue(sectionDarkDeclarations);
  if (firstString(section['padding-block'])) {
    picked['padding-block'] = section['padding-block'];
  } else if (firstString(section.padding)) {
    picked.padding = section.padding;
  }
  const sectionBg = firstString(dark['--section-bg'], dark['background'], dark['background-color']);
  if (sectionBg) {
    picked.background = sectionBg;
  }
  return picked;
}

function pickPixflowStageBWorkShellDeclarations(declarations) {
  const allowed = new Set([
    'margin',
    'margin-inline',
    'margin-left',
    'margin-right',
    'border-radius',
    'overflow',
  ]);
  const picked = {};
  for (const [property, value] of Object.entries(objectValue(declarations))) {
    if (allowed.has(String(property || '').toLowerCase()) && value) {
      picked[property] = value;
    }
  }
  return picked;
}

function removePixflowStageBWorkSectionShellSettings(settings) {
  removePixflowStageBSettingsByBaseKey(settings, new Set([
    '_margin',
    '_border',
    '_overflow',
  ]));
}

function applyPixflowStageBWorkSectionWrapperReset(settings) {
  settings._padding = {
    ...objectValue(settings._padding),
    top: '0',
    bottom: '0',
  };
  for (const suffix of ['tablet_portrait', 'mobile_landscape', 'mobile_portrait']) {
    const key = `_padding:${suffix}`;
    settings[key] = {
      ...objectValue(settings[key]),
      top: '0',
      bottom: '0',
    };
  }
  settings._background = { color: { raw: 'var(--paper)' } };
}

function removePixflowStageBNonShellResponsiveSettings(settings) {
  const allowedBaseKeys = new Set(['_padding', '_background', '_margin', '_border', '_overflow']);
  for (const key of Object.keys(settings)) {
    const baseKey = key.split(':')[0];
    if (key.includes(':') && !allowedBaseKeys.has(baseKey)) {
      delete settings[key];
    }
  }
}

function removePixflowStageBSettingsByBaseKey(settings, baseKeys) {
  for (const key of Object.keys(objectValue(settings))) {
    if (baseKeys.has(key.split(':')[0])) {
      delete settings[key];
    }
  }
}

function shouldUsePixflowStageBFlexForInlineGridCenter(usageItem, declarations) {
  const source = objectValue(declarations);
  if (!/^grid$/i.test(firstString(source.display)) || !firstString(source['place-items'])) {
    return false;
  }
  const tags = Array.isArray(usageItem?.tags) ? usageItem.tags.map((tag) => firstString(tag).toLowerCase()).filter(Boolean) : [];
  if (tags.length === 0) {
    return false;
  }
  return tags.every((tag) => /^(?:span|small|strong|b|em|code)$/.test(tag));
}

function extractPixflowStageBResponsiveClassRules(cssText, classNames, cssVariables = new Map()) {
  const rulesByClass = new Map();
  const classSet = new Set(Array.isArray(classNames) ? classNames : []);
  const source = stripStageBCssComments(cssText);
  const pattern = /@media\s*([^{]+)\{/gi;
  let match;
  let order = 0;

  while ((match = pattern.exec(source)) !== null) {
    const condition = normalizeWhitespace(match[1] || '');
    const suffixes = pixflowStageBResponsiveSuffixesForMediaCondition(condition);
    const openIndex = source.lastIndexOf('{', pattern.lastIndex - 1);
    const closeIndex = openIndex >= 0 ? findPixflowCssBlockClose(source, openIndex) : -1;
    if (openIndex < 0 || closeIndex <= openIndex) {
      continue;
    }
    pattern.lastIndex = closeIndex + 1;
    if (suffixes.length === 0) {
      continue;
    }

    const mediaRules = extractStageBCssRuleSummaries(source.slice(openIndex + 1, closeIndex));
    for (const rule of mediaRules) {
      for (const className of rule.classNames || []) {
        if (!classSet.has(className) || !isPixflowStageBSimpleClassSelector(rule.selector, className)) {
          continue;
        }
        const mapped = mapPixflowCssDeclarationsToBricksSettings(rule.declarations, { deriveResponsive: false, cssVariables });
        const declarations = pickPixflowStageBResponsiveDeclarations(mapped);
        if (Object.keys(declarations).length === 0) {
          continue;
        }
        const list = rulesByClass.get(className) || [];
        list.push({
          condition,
          suffixes,
          selector: rule.selector,
          order: order += 1,
          settings: declarations,
        });
        rulesByClass.set(className, list);
      }
    }
  }

  return rulesByClass;
}

function pixflowStageBResponsiveSuffixesForMediaCondition(condition) {
  const maxWidths = [...String(condition || '').matchAll(/max-width\s*:\s*([0-9.]+)px/gi)]
    .map((match) => Number(match[1]))
    .filter((value) => Number.isFinite(value));
  if (maxWidths.length === 0) {
    return [];
  }
  const maxWidth = Math.min(...maxWidths);
  if (maxWidth <= 520) {
    return ['mobile_portrait'];
  }
  if (maxWidth <= 800) {
    return ['mobile_landscape', 'mobile_portrait'];
  }
  return ['tablet_portrait', 'mobile_landscape', 'mobile_portrait'];
}

function pickPixflowStageBResponsiveDeclarations(settings) {
  const allowed = new Set([
    '_display',
    '_direction',
    '_flexWrap',
    '_alignItems',
    '_alignItemsGrid',
    '_justifyContent',
    '_justifyContentGrid',
    '_justifyItemsGrid',
    '_alignContentGrid',
    '_columnGap',
    '_rowGap',
    '_gridTemplateColumns',
    '_gridTemplateRows',
    '_width',
    '_height',
    '_widthMin',
    '_widthMax',
    '_heightMin',
    '_heightMax',
    '_aspectRatio',
    '_objectFit',
    '_overflow',
    '_padding',
    '_margin',
    '_typography',
    '_border',
  ]);
  const picked = {};
  for (const [key, value] of Object.entries(objectValue(settings))) {
    if (allowed.has(key) && value !== undefined && value !== null && value !== '') {
      picked[key] = value;
    }
  }
  return picked;
}

function applyPixflowStageBResponsiveSettings(settings, classNames, classInfo) {
  const responsiveRulesByClass = classInfo?.responsiveRulesByClass;
  if (!responsiveRulesByClass || typeof responsiveRulesByClass.get !== 'function') {
    return settings;
  }
  const responsiveRules = [];
  for (const className of Array.isArray(classNames) ? classNames : []) {
    responsiveRules.push(...(responsiveRulesByClass.get(className) || []));
  }
  responsiveRules.sort((a, b) => (a.order || 0) - (b.order || 0));
  for (const rule of responsiveRules) {
    for (const suffix of rule.suffixes || []) {
      for (const [key, value] of Object.entries(objectValue(rule.settings))) {
        if (key.includes(':')) {
          continue;
        }
        settings[`${key}:${suffix}`] = value;
      }
    }
  }
  return settings;
}

function buildPixflowStageBHtmlBricksAttributes(node, seed) {
  return (Array.isArray(node?.attrList) ? node.attrList : [])
    .filter((attribute) => /^(?:data|aria)-[A-Za-z0-9_-]+$|^(?:id|role|tabindex|title)$/i.test(attribute.name))
    .map((attribute) => {
      const value = firstString(attribute.value);
      const result = {
        id: deterministicBricksId(`stage-b-html-attribute:${seed}:${attribute.name}:${value}`),
        name: attribute.name,
      };
      if (value) {
        result.value = value;
      }
      return result;
    });
}

function buildPixflowStageBManualAttribute(seed, name, value = '') {
  const result = {
    id: deterministicBricksId(`stage-b-html-attribute:manual:${seed}:${name}:${value}`),
    name,
  };
  if (firstString(value)) {
    result.value = firstString(value);
  }
  return result;
}

function applyPixflowStageBStructuralAnchorSettings(settings, node, href) {
  settings.tag = 'a';
  delete settings.customTag;

  const ariaLabel = pixflowStageBAttr(node, 'aria-label');
  if (Array.isArray(settings._attributes)) {
    settings._attributes = settings._attributes.filter((attribute) => {
      const name = firstString(attribute?.name).toLowerCase();
      return name !== 'aria-label' && name !== 'href';
    });
    if (settings._attributes.length === 0) {
      delete settings._attributes;
    }
  }

  if (href || ariaLabel) {
    settings.link = {
      type: 'meta',
    };
    if (href) {
      settings.link.useDynamicData = href;
    }
    if (ariaLabel) {
      settings.link.ariaLabel = ariaLabel;
    }
  }
}

function extractPixflowStageBCssVariables(rules) {
  const variables = new Map();
  for (const rule of Array.isArray(rules) ? rules : []) {
    const selectors = splitPixflowCssSelectorList(rule?.selector || '');
    if (!selectors.some((selector) => selector.trim() === ':root')) {
      continue;
    }
    for (const [key, value] of Object.entries(objectValue(rule.declarations))) {
      const name = normalizePixflowStageBCssVariableName(key);
      if (name && firstString(value)) {
        variables.set(name, firstString(value));
      }
    }
  }
  return variables;
}

function normalizePixflowStageBCssVariableName(name) {
  const value = firstString(name).trim();
  if (!value) return '';
  const normalized = value.startsWith('--') ? value : `--${value}`;
  return /^--[A-Za-z0-9_-]+$/.test(normalized) ? normalized : '';
}

function lookupPixflowStageBCssVariable(name, cssVariables) {
  const normalized = normalizePixflowStageBCssVariableName(name);
  if (!normalized) return '';
  if (cssVariables instanceof Map) {
    return firstString(cssVariables.get(normalized), cssVariables.get(normalized.toLowerCase()));
  }
  const source = objectValue(cssVariables);
  return firstString(source[normalized], source[normalized.toLowerCase()]);
}

function resolvePixflowStageBCssVariableExpression(value, cssVariables, seen = new Set()) {
  const source = firstString(value);
  const match = source.match(/^var\(\s*(--[A-Za-z0-9_-]+)\s*(?:,\s*([\s\S]+))?\)$/i);
  if (!match) {
    return source;
  }
  const name = normalizePixflowStageBCssVariableName(match[1]);
  if (!name || seen.has(name)) {
    return firstString(match[2], source);
  }
  seen.add(name);
  const resolved = lookupPixflowStageBCssVariable(name, cssVariables);
  if (resolved) {
    return resolvePixflowStageBCssVariableExpression(resolved, cssVariables, seen);
  }
  return firstString(match[2], source);
}

function resolvePixflowStageBFontFamilyValue(value, cssVariables = new Map()) {
  const resolved = resolvePixflowStageBCssVariableExpression(value, cssVariables);
  const firstFamily = splitPixflowCssCommaList(resolved)[0] || resolved;
  const family = firstFamily
    .replace(/^["']|["']$/g, '')
    .trim();
  if (!family || /^var\(/i.test(family) || /^(?:serif|sans-serif|monospace|cursive|fantasy|system-ui|ui-serif|ui-sans-serif|ui-monospace)$/i.test(family)) {
    return '';
  }
  return family;
}

function extractPixflowStageBTagDeclarations(rules) {
  const declarationsByTag = new Map();
  for (const rule of Array.isArray(rules) ? rules : []) {
    if (rule?.hasPseudoElement || rule?.hasPseudoState) {
      continue;
    }
    const declarations = objectValue(rule?.declarations);
    if (Object.keys(declarations).length === 0) {
      continue;
    }
    for (const selector of splitPixflowCssSelectorList(rule.selector || '')) {
      const tag = normalizePixflowStageBTagSelector(selector);
      if (!tag) {
        continue;
      }
      declarationsByTag.set(tag, {
        ...objectValue(declarationsByTag.get(tag)),
        ...declarations,
      });
    }
  }
  return declarationsByTag;
}

function normalizePixflowStageBTagSelector(selector) {
  const tag = firstString(selector).toLowerCase();
  if (!tag || tag === ':root') {
    return '';
  }
  if (!/^[a-z][a-z0-9-]*$/.test(tag)) {
    return '';
  }
  const allowed = new Set([
    'body',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6',
    'p',
    'blockquote',
    'label',
    'span',
    'small',
    'strong',
    'b',
    'em',
    'code',
    'a',
    'button',
    'figcaption',
    'li',
  ]);
  return allowed.has(tag) ? tag : '';
}

function pickPixflowStageBInheritedTextDeclarations(declarations) {
  const allowed = new Set([
    'color',
    'font-family',
    'font-size',
    'font-weight',
    'line-height',
    'letter-spacing',
    'text-align',
    'text-transform',
  ]);
  const result = {};
  for (const [key, value] of Object.entries(objectValue(declarations))) {
    if (allowed.has(String(key || '').toLowerCase()) && value) {
      result[key] = value;
    }
  }
  return result;
}

function isPixflowStageBInheritedTextTag(tag) {
  return /^(?:section|header|footer|nav|div|article|aside|h[1-6]|p|blockquote|label|span|small|strong|b|em|code|a|button|figcaption|li)$/.test(firstString(tag).toLowerCase());
}

function splitPixflowCssCommaList(value) {
  const result = [];
  let current = '';
  let depth = 0;
  let quote = '';
  for (const char of String(value || '')) {
    if (quote) {
      current += char;
      if (char === quote) {
        quote = '';
      }
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
      current += char;
      continue;
    }
    if (char === '(') depth += 1;
    if (char === ')') depth = Math.max(0, depth - 1);
    if (char === ',' && depth === 0) {
      if (current.trim()) result.push(current.trim());
      current = '';
      continue;
    }
    current += char;
  }
  if (current.trim()) {
    result.push(current.trim());
  }
  return result;
}

function applyPixflowStageBTemplateRootDefaults(node, name, settings, parentId, context, options) {
  if (name !== 'section' || parentId) {
    return;
  }
  if (options.templatePart === 'header') {
    settings._padding = {
      top: firstString(settings._padding?.top, '0'),
      right: firstString(settings._padding?.right, '0'),
      bottom: firstString(settings._padding?.bottom, '0'),
      left: firstString(settings._padding?.left, '0'),
    };
  }
  if (options.templatePart === 'footer' && !hasStageBTopBottomPadding(settings)) {
    settings._padding = {
      top: firstString(settings._padding?.top, '0'),
      right: firstString(settings._padding?.right, '0'),
      bottom: firstString(settings._padding?.bottom, '0'),
      left: firstString(settings._padding?.left, '0'),
    };
  }
}

function mapPixflowCssDeclarationsToBricksSettings(declarations, options = {}) {
  const settings = {};
  const typography = {};
  const border = {};
  const source = objectValue(declarations);
  const cssVariables = options.cssVariables || new Map();

  for (const [property, value] of Object.entries(source)) {
    const key = property.toLowerCase();
    if (!value || key.startsWith('--')) continue;
    if (key === 'display') settings._display = options.preferFlexForGridCenter && /^grid$/i.test(value) ? 'flex' : value;
    else if (key === 'flex-direction') settings._direction = value;
    else if (key === 'flex-wrap') settings._flexWrap = value;
    else if (key === 'align-items') settings._alignItems = value;
    else if (key === 'justify-content') settings._justifyContent = value;
    else if (key === 'justify-items') settings._justifyItemsGrid = value;
    else if (key === 'align-content') settings._alignContentGrid = value;
    else if (key === 'place-items') {
      const pair = parsePixflowCssPlacePairValue(value);
      if (options.preferFlexForGridCenter) {
        settings._alignItems = pair.align;
        settings._justifyContent = pair.justify;
      } else {
        settings._alignItemsGrid = pair.align;
        settings._justifyItemsGrid = pair.justify;
      }
    }
    else if (key === 'place-content') {
      const pair = parsePixflowCssPlacePairValue(value);
      settings._alignContentGrid = pair.align;
      settings._justifyContentGrid = pair.justify;
    }
    else if (key === 'gap') {
      settings._columnGap = value;
      settings._rowGap = value;
    } else if (key === 'column-gap') settings._columnGap = value;
    else if (key === 'row-gap') settings._rowGap = value;
    else if (key === 'grid-template-columns') settings._gridTemplateColumns = value;
    else if (key === 'grid-template-rows') settings._gridTemplateRows = value;
    else if (key === 'width') settings._width = value;
    else if (key === 'height') settings._height = value;
    else if (key === 'min-width') settings._widthMin = value;
    else if (key === 'max-width') settings._widthMax = value;
    else if (key === 'min-height') settings._heightMin = value;
    else if (key === 'max-height') settings._heightMax = value;
    else if (key === 'aspect-ratio') settings._aspectRatio = value;
    else if (key === 'object-fit') settings._objectFit = value;
    else if (key === 'overflow') settings._overflow = value;
    else if (key === 'position') settings._position = value;
    else if (key === 'padding') settings._padding = parsePixflowCssBoxValue(value);
    else if (key === 'padding-block') settings._padding = { ...objectValue(settings._padding), ...parsePixflowCssLogicalBlockValue(value) };
    else if (key === 'padding-inline') settings._padding = { ...objectValue(settings._padding), ...parsePixflowCssLogicalInlineValue(value) };
    else if (/^padding-(?:top|right|bottom|left)$/.test(key)) {
      settings._padding = { ...objectValue(settings._padding), [key.replace('padding-', '')]: value };
    }
    else if (key === 'margin') settings._margin = parsePixflowCssBoxValue(value);
    else if (key === 'margin-block') settings._margin = { ...objectValue(settings._margin), ...parsePixflowCssLogicalBlockValue(value) };
    else if (key === 'margin-inline') settings._margin = { ...objectValue(settings._margin), ...parsePixflowCssLogicalInlineValue(value) };
    else if (/^margin-(?:top|right|bottom|left)$/.test(key)) {
      settings._margin = { ...objectValue(settings._margin), [key.replace('margin-', '')]: value };
    }
    else if (key === 'color') typography.color = { raw: value };
    else if (key === 'font-family') {
      const fontFamily = resolvePixflowStageBFontFamilyValue(value, cssVariables);
      if (fontFamily) {
        typography['font-family'] = fontFamily;
      }
    }
    else if (key === 'font-size') typography['font-size'] = value;
    else if (key === 'font-weight') typography['font-weight'] = value;
    else if (key === 'line-height') typography['line-height'] = value;
    else if (key === 'letter-spacing') typography['letter-spacing'] = value;
    else if (key === 'text-align') typography['text-align'] = value;
    else if (key === 'text-transform') typography['text-transform'] = value;
    else if ((key === 'background' || key === 'background-color') && isPixflowCssColorValue(value)) settings._background = { color: { raw: value } };
    else if (key === 'border-radius') border.radius = parsePixflowCssBorderRadiusValue(value);
    else if (key === 'border') Object.assign(border, parsePixflowCssBorderValue(value));
  }

  if (Object.keys(typography).length > 0) {
    settings._typography = typography;
  }
  if (Object.keys(border).length > 0) {
    settings._border = border;
  }
  if (settings._display === 'flex' && !settings._direction) {
    settings._direction = 'row';
  }
  if (['grid', 'inline-grid'].includes(firstString(settings._display).toLowerCase())) {
    if (settings._alignItems && !settings._alignItemsGrid) {
      settings._alignItemsGrid = settings._alignItems;
    }
    if (settings._justifyContent && !settings._justifyContentGrid) {
      settings._justifyContentGrid = settings._justifyContent;
    }
    delete settings._alignItems;
    delete settings._justifyContent;
  }
  if ((settings._direction || settings._flexWrap) && !settings._display) {
    settings._display = 'flex';
  }
  if (settings._gridTemplateColumns && !settings._display) {
    settings._display = 'grid';
  }
  if (options.deriveResponsive !== false && settings._gridTemplateColumns && stageBGridColumnCountHint(settings._gridTemplateColumns) > 1 && !settings['_gridTemplateColumns:mobile_portrait']) {
    settings['_gridTemplateColumns:mobile_portrait'] = '1fr';
  }
  return settings;
}

function getPixflowStageBBodyRootNodes(body) {
  const children = (body?.children || []).filter((node) => node.type !== 'text' || normalizeWhitespace(node.text));
  const pageWrapper = children.find((node) => node.type === 'element' && isPixflowStageBPageWrapper(node));
  if (pageWrapper) {
    return pageWrapper.children || [];
  }
  return children;
}

function normalizePixflowStageBHtmlGlobalClassName(className, usedNames) {
  const preferred = firstString(className)
    .replace(/(?:^|[-_])primary(?:$|[-_])/gi, (match) => match.replace(/primary/i, 'main'))
    .replace(/(?:^|[-_])secondary(?:$|[-_])/gi, (match) => match.replace(/secondary/i, 'alt'));
  let name = preferred || 'stage-a-class';
  let suffix = 2;
  while (usedNames.has(name)) {
    name = `${preferred}-${suffix}`;
    suffix += 1;
  }
  usedNames.add(name);
  return name;
}

function isPixflowStageBPageWrapper(node) {
  return node?.type === 'element'
    && node.tag === 'div'
    && pixflowStageBHtmlClassList(node).includes('page')
    && !pixflowStageBAttr(node, 'data-od-id');
}

function findFirstPixflowHtmlElement(node, predicate) {
  if (!node) return null;
  if (node.type === 'element' && predicate(node)) {
    return node;
  }
  for (const child of node.children || []) {
    const found = findFirstPixflowHtmlElement(child, predicate);
    if (found) return found;
  }
  return null;
}

function flattenPixflowHtmlElements(node, result = []) {
  if (!node) return result;
  if (node.type === 'element') {
    result.push(node);
  }
  for (const child of node.children || []) {
    flattenPixflowHtmlElements(child, result);
  }
  return result;
}

function selectPixflowStageBHeaderNodes(documentRoot, plan) {
  const elements = flattenPixflowHtmlElements(documentRoot);
  const selectedOdId = firstString(plan?.headerPlan?.selectedSectionOdId);
  const selected = elements.find((node) => (
    node.tag === 'header'
    && (!selectedOdId || pixflowStageBAttr(node, 'data-od-id') === selectedOdId || pixflowStageBAttr(node, 'id') === selectedOdId)
  )) || elements.find((node) => node.tag === 'header');
  if (!selected) {
    return { templateNodes: [], pageSkipNodes: [] };
  }
  const extras = [];
  const previous = findPreviousPixflowElementSibling(selected);
  if (previous && isPixflowStageBHeaderAuxiliaryNode(previous)) {
    extras.push(previous);
  }
  return {
    templateNodes: [...extras, selected],
    pageSkipNodes: [...extras, selected],
  };
}

function selectPixflowStageBFooterNodes(documentRoot, plan) {
  const elements = flattenPixflowHtmlElements(documentRoot);
  const selectedOdId = firstString(plan?.footerPlan?.selectedSectionOdId);
  const selected = elements.find((node) => (
    node.tag === 'footer'
    && (!selectedOdId || pixflowStageBAttr(node, 'data-od-id') === selectedOdId || pixflowStageBAttr(node, 'id') === selectedOdId)
  )) || elements.find((node) => node.tag === 'footer');
  if (!selected) {
    return { templateNodes: [], pageSkipNodes: [] };
  }
  return {
    templateNodes: [selected],
    pageSkipNodes: [selected],
  };
}

function findPreviousPixflowElementSibling(node) {
  const siblings = node?.parent?.children || [];
  const index = siblings.indexOf(node);
  for (let cursor = index - 1; cursor >= 0; cursor -= 1) {
    const sibling = siblings[cursor];
    if (sibling?.type === 'text' && !normalizeWhitespace(sibling.text)) {
      continue;
    }
    return sibling?.type === 'element' ? sibling : null;
  }
  return null;
}

function isPixflowStageBHeaderAuxiliaryNode(node) {
  const haystack = [
    node?.tag,
    pixflowStageBAttr(node, 'data-od-id'),
    pixflowStageBAttr(node, 'id'),
    ...pixflowStageBHtmlClassList(node),
  ].join(' ').toLowerCase();
  return /\b(topbar|announcement|preheader|utility-bar|header-bar)\b/.test(haystack);
}

function pixflowStageBAttr(node, name) {
  return firstString(node?.attrs?.[String(name || '').toLowerCase()]);
}

function pixflowStageBHtmlClassList(node) {
  return classListFromAttr(pixflowStageBAttr(node, 'class'));
}

function pixflowStageBNodeText(node) {
  if (!node) return '';
  if (node.type === 'text') return node.text || '';
  if (node.tag === 'script' || node.tag === 'style') return '';
  return (node.children || []).map((child) => pixflowStageBNodeText(child)).join(' ');
}

function pixflowStageBNodeInnerHtml(node) {
  const root = findPixflowStageBDocumentRoot(node);
  if (!root?.rawHtml || typeof node?.contentStart !== 'number' || typeof node?.contentEnd !== 'number') {
    return pixflowStageBNodeText(node);
  }
  return root.rawHtml.slice(node.contentStart, node.contentEnd);
}

function findPixflowStageBDocumentRoot(node) {
  let cursor = node;
  while (cursor?.parent) {
    cursor = cursor.parent;
  }
  return cursor;
}

function hasPixflowStageBElementChildren(node) {
  return (node?.children || []).some((child) => child.type === 'element');
}

function isPixflowStageBInlineTextParentNode(node) {
  const tag = firstString(node?.tag).toLowerCase();
  if (['a', 'span', 'small', 'b', 'strong', 'em', 'i', 'u', 'code'].includes(tag)) {
    return true;
  }
  return firstString(node?.customTag).toLowerCase() === 'span';
}

function isPixflowStageBCollapsibleInlineTextNode(node) {
  const tag = firstString(node?.tag).toLowerCase();
  if (!['span', 'small'].includes(tag) || !hasPixflowStageBElementChildren(node)) {
    return false;
  }
  const allowed = new Set(['b', 'strong', 'em', 'i', 'u', 'code', 'small', 'span']);
  const elements = flattenPixflowHtmlElements(node).filter((item) => item !== node);
  if (elements.length === 0) {
    return false;
  }
  return elements.every((item) => {
    if (!allowed.has(firstString(item.tag).toLowerCase())) {
      return false;
    }
    return pixflowStageBHtmlClassList(item).length === 0
      && !pixflowStageBAttr(item, 'id')
      && !pixflowStageBAttr(item, 'data-od-id');
  });
}

function isPixflowStageBEmptyDecorativeInlineNode(node) {
  if (node?.tag !== 'span' || hasPixflowStageBElementChildren(node)) {
    return false;
  }
  if (normalizeWhitespace(pixflowStageBNodeText(node))) {
    return false;
  }
  return pixflowStageBHtmlClassList(node).length > 0
    || buildPixflowStageBHtmlBricksAttributes(node, `decorative:${node.sourceIndex}`).length > 0;
}

function sanitizePixflowStageBInlineHtml(value) {
  const withoutUnsafe = String(value || '')
    .replace(/<script\b[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[\s\S]*?<\/style>/gi, '')
    .replace(/<svg\b[\s\S]*?<\/svg>/gi, '')
    .replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  return normalizeWhitespace(withoutUnsafe)
    .replace(/>\s+</g, '><')
    .replace(/\s+([,.;:!?])/g, '$1');
}

function isPixflowStageBCtaNode(node) {
  const classText = pixflowStageBHtmlClassList(node).join(' ').toLowerCase();
  return /\b(btn|button|cta|action)\b/.test(classText)
    || pixflowStageBAttr(node, 'role').toLowerCase() === 'button';
}

function buildPixflowStageBActionIconSetting(node) {
  const iconId = inferPixflowStageBIconId(node);
  return {
    library: 'pixflowSvg',
    icon: buildStageBIconPlaceholder('tabler-outline', iconId),
  };
}

function inferPixflowStageBIconId(node) {
  const text = normalizeWhitespace(pixflowStageBNodeText(node)).toLowerCase();
  const href = pixflowStageBAttr(node, 'href').toLowerCase();
  const classText = pixflowStageBHtmlClassList(node).join(' ').toLowerCase();
  const haystack = `${text} ${href} ${classText}`;
  if (/download|release/.test(text)) return 'download';
  if (/github|repository/.test(haystack)) return 'brand-github';
  if (/download|release/.test(haystack)) return 'download';
  if (/search/.test(haystack)) return 'search';
  if (/mail|email|subscribe/.test(haystack)) return 'mail';
  if (/play|video/.test(haystack)) return 'player-play';
  if (/plus|\+/.test(haystack)) return 'plus';
  if (/heart|like/.test(haystack)) return 'heart';
  if (/external|open|start|study|try|book|contact|arrow|method/.test(haystack)) return 'arrow-up-right';
  return 'arrow-up-right';
}

function isPixflowStageBSimpleClassSelector(selector, className) {
  return splitPixflowCssSelectorList(selector).some((part) => {
    const trimmed = part.trim();
    if (!trimmed || !trimmed.includes(`.${className}`)) return false;
    if (/[>+~\s]/.test(trimmed.replace(`.${className}`, ''))) return false;
    if (/:(?:hover|focus|active|visited|not|nth-|first-|last-)|::/i.test(trimmed)) return false;
    return true;
  });
}

function convertPixflowStageBCssRuleToRoot(rule, className, cssVariables = new Map()) {
  const selector = firstString(rule?.selector);
  let declarations = objectValue(rule?.declarations);
  if (!selector || Object.keys(declarations).length === 0) return '';
  if (/:root\b|^\s*(?:html|body)\b/i.test(selector)) return '';
  if (/@import\b|@font-face\b|fonts\.googleapis\.com|fonts\.gstatic\.com/i.test(selector)) return '';
  if (isPixflowStageBSimpleClassSelector(selector, className)) {
    declarations = filterPixflowStageBUnsupportedCssDeclarations(declarations);
    if (Object.keys(declarations).length === 0) return '';
  }
  const selectors = splitPixflowCssSelectorList(selector)
    .filter((part) => part.includes(`.${className}`))
    .map((part) => part.replace(new RegExp(`\\.${escapeRegExp(className)}\\b`, 'g'), '%root%').trim())
    .filter(Boolean);
  if (selectors.length === 0) return '';
  const body = serializePixflowCssDeclarations(declarations, { cssVariables });
  if (!body) return '';
  return `${selectors.join(', ')} { ${body} }`;
}

function filterPixflowStageBUnsupportedCssDeclarations(declarations) {
  const result = {};
  for (const [property, value] of Object.entries(objectValue(declarations))) {
    if (!isPixflowStageBMappableCssDeclaration(property, value)) {
      result[property] = value;
    }
  }
  return result;
}

function isPixflowStageBMappableCssDeclaration(property, value) {
  const key = String(property || '').toLowerCase();
  if (!value) return true;
  if (key.startsWith('--')) return false;
  if ([
    'display',
    'flex-direction',
    'flex-wrap',
    'align-items',
    'justify-content',
    'justify-items',
    'align-content',
    'place-items',
    'place-content',
    'gap',
    'column-gap',
    'row-gap',
    'grid-template-columns',
    'grid-template-rows',
    'width',
    'height',
    'min-width',
    'max-width',
    'min-height',
    'max-height',
    'aspect-ratio',
    'object-fit',
    'overflow',
    'position',
    'padding',
    'padding-block',
    'padding-inline',
    'padding-top',
    'padding-right',
    'padding-bottom',
    'padding-left',
    'margin',
    'margin-block',
    'margin-inline',
    'margin-top',
    'margin-right',
    'margin-bottom',
    'margin-left',
    'color',
    'font-family',
    'font-size',
    'font-weight',
    'line-height',
    'letter-spacing',
    'text-align',
    'text-transform',
    'border-radius',
    'border',
  ].includes(key)) {
    return true;
  }
  if ((key === 'background' || key === 'background-color') && isPixflowCssColorValue(value)) {
    return true;
  }
  return false;
}

function splitPixflowCssSelectorList(selector) {
  const result = [];
  let depth = 0;
  let current = '';
  for (const char of String(selector || '')) {
    if (char === '(' || char === '[') depth += 1;
    if (char === ')' || char === ']') depth = Math.max(0, depth - 1);
    if (char === ',' && depth === 0) {
      if (current.trim()) result.push(current.trim());
      current = '';
      continue;
    }
    current += char;
  }
  if (current.trim()) result.push(current.trim());
  return result;
}

function serializePixflowCssDeclarations(declarations, options = {}) {
  const cssVariables = options.cssVariables || new Map();
  return Object.entries(objectValue(declarations))
    .filter(([key, value]) => key && value)
    .map(([key, value]) => `${key}: ${normalizePixflowStageBCustomCssDeclarationValue(key, value, cssVariables)};`)
    .join(' ');
}

function normalizePixflowStageBCustomCssDeclarationValue(property, value, cssVariables = new Map()) {
  const key = String(property || '').toLowerCase();
  if (key === 'font-family') {
    const fontFamily = resolvePixflowStageBFontFamilyValue(value, cssVariables);
    if (fontFamily) {
      return /[\s,]/.test(fontFamily) ? `"${fontFamily.replace(/"/g, '\\"')}"` : fontFamily;
    }
  }
  return value;
}

function parsePixflowCssBoxValue(value) {
  const parts = splitPixflowCssValueList(value);
  const top = parts[0] || '0';
  const right = parts[1] || top;
  const bottom = parts[2] || top;
  const left = parts[3] || right;
  return { top, right, bottom, left };
}

function parsePixflowCssLogicalBlockValue(value) {
  const parts = splitPixflowCssValueList(value);
  return {
    top: parts[0] || '0',
    bottom: parts[1] || parts[0] || '0',
  };
}

function parsePixflowCssLogicalInlineValue(value) {
  const parts = splitPixflowCssValueList(value);
  return {
    right: parts[1] || parts[0] || '0',
    left: parts[0] || '0',
  };
}

function parsePixflowCssPlacePairValue(value) {
  const parts = splitPixflowCssValueList(value).filter((part) => !/^normal$/i.test(part));
  const align = parts[0] || 'center';
  return {
    align,
    justify: parts[1] || align,
  };
}

function parsePixflowCssBorderRadiusValue(value) {
  const box = parsePixflowCssBoxValue(value);
  return {
    top: box.top,
    right: box.right,
    bottom: box.bottom,
    left: box.left,
  };
}

function buildPixflowCssBorderSideBox(value) {
  const normalized = normalizePixflowCssBorderWidthValue(value);
  return {
    top: normalized,
    right: normalized,
    bottom: normalized,
    left: normalized,
  };
}

function normalizePixflowCssBorderWidthValue(value) {
  const source = firstString(value).trim();
  const pxMatch = source.match(/^(-?(?:\d+|\d*\.\d+))px$/i);
  if (pxMatch) {
    return pxMatch[1];
  }
  return source;
}

function splitPixflowCssValueList(value) {
  const parts = [];
  let depth = 0;
  let current = '';
  for (const char of String(value || '').trim()) {
    if (char === '(') depth += 1;
    if (char === ')') depth = Math.max(0, depth - 1);
    if (/\s/.test(char) && depth === 0) {
      if (current.trim()) parts.push(current.trim());
      current = '';
      continue;
    }
    current += char;
  }
  if (current.trim()) parts.push(current.trim());
  return parts;
}

function parsePixflowCssBorderValue(value) {
  const parts = splitPixflowCssValueList(value);
  const styleIndex = parts.findIndex((part) => /^(?:none|solid|dashed|dotted|double)$/i.test(part));
  if (styleIndex < 0) {
    return {};
  }
  const width = parts.slice(0, styleIndex).join(' ') || '1px';
  const style = parts[styleIndex];
  const color = parts.slice(styleIndex + 1).join(' ');
  const border = { width: buildPixflowCssBorderSideBox(width), style };
  if (color) {
    border.color = { raw: color };
  }
  return border;
}

function isPixflowCssColorValue(value) {
  const source = String(value || '').trim();
  if (!source) return false;
  return source === 'transparent'
    || source === 'currentColor'
    || /^var\(\s*--[A-Za-z0-9_-]+(?:\s*,[\s\S]+)?\)$/i.test(source)
    || /^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(source)
    || /^(?:rgb|rgba|hsl|hsla|oklch|oklab|color-mix)\(/i.test(source);
}

function mergePixflowBricksSettings(...settingsList) {
  const result = {};
  for (const settings of settingsList) {
    mergePixflowBricksSettingsInto(result, settings);
  }
  return result;
}

function mergePixflowBricksSettingsInto(target, source) {
  for (const [key, value] of Object.entries(objectValue(source))) {
    if (value === undefined || value === null || value === '') continue;
    if (
      value
      && typeof value === 'object'
      && !Array.isArray(value)
      && target[key]
      && typeof target[key] === 'object'
      && !Array.isArray(target[key])
      && !['link', 'image', 'icon'].includes(key)
    ) {
      target[key] = mergePixflowBricksSettings(target[key], value);
    } else {
      target[key] = value;
    }
  }
  return target;
}

function removeUndefinedObjectValues(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return value;
  }
  const result = {};
  for (const [key, child] of Object.entries(value)) {
    if (child === undefined || child === null || child === '') {
      continue;
    }
    if (Array.isArray(child)) {
      result[key] = child.map((item) => removeUndefinedObjectValues(item));
    } else if (child && typeof child === 'object') {
      result[key] = removeUndefinedObjectValues(child);
    } else {
      result[key] = child;
    }
  }
  return result;
}

function extractPixflowStageBTokenReferences(value) {
  return uniqueStrings([...String(value || '').matchAll(/var\(\s*(--[A-Za-z0-9_-]+)/g)].map((match) => match[1])).slice(0, 120);
}

function extractPixflowStageBRawColorFallbacks(cssText) {
  const raw = uniqueStrings([...String(cssText || '').matchAll(/#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})\b/gi)].map((match) => match[0].toLowerCase()));
  return raw.slice(0, 40);
}

function stripPixflowStageBAtRuleBlocks(cssText, atRuleName) {
  const source = String(cssText || '');
  const name = firstString(atRuleName).replace(/^@/, '');
  if (!name) return source;
  let result = '';
  let cursor = 0;
  const pattern = new RegExp(`@${escapeRegExp(name)}\\b`, 'gi');
  let match;
  while ((match = pattern.exec(source)) !== null) {
    result += source.slice(cursor, match.index);
    const openIndex = source.indexOf('{', pattern.lastIndex);
    if (openIndex < 0) {
      cursor = pattern.lastIndex;
      continue;
    }
    const closeIndex = findPixflowCssBlockClose(source, openIndex);
    cursor = closeIndex > openIndex ? closeIndex + 1 : openIndex + 1;
    pattern.lastIndex = cursor;
  }
  result += source.slice(cursor);
  return result;
}

function extractPixflowStageBKeyframes(cssText, name) {
  const source = String(cssText || '');
  const keyframeName = firstString(name);
  const pattern = new RegExp(`@keyframes\\s+${escapeRegExp(keyframeName)}\\s*\\{`, 'i');
  const match = source.match(pattern);
  if (!match || typeof match.index !== 'number') return '';
  const openIndex = source.indexOf('{', match.index);
  const closeIndex = findPixflowCssBlockClose(source, openIndex);
  if (openIndex < 0 || closeIndex <= openIndex) return '';
  return source.slice(match.index, closeIndex + 1).trim();
}

function findPixflowCssBlockClose(source, openIndex) {
  let depth = 0;
  for (let index = openIndex; index < source.length; index += 1) {
    const char = source[index];
    if (char === '{') depth += 1;
    if (char === '}') {
      depth -= 1;
      if (depth === 0) return index;
    }
  }
  return -1;
}

function buildPixflowStageBRevealCss(cssText) {
  if (!/\[data-reveal\]/i.test(String(cssText || ''))) {
    return '';
  }
  return [
    '%root% [data-reveal] { opacity: 0; translate: 0 28px; transition: opacity 720ms cubic-bezier(0.22, 1, 0.36, 1) var(--reveal-delay, 0ms), translate 720ms cubic-bezier(0.22, 1, 0.36, 1) var(--reveal-delay, 0ms), scale 720ms cubic-bezier(0.22, 1, 0.36, 1) var(--reveal-delay, 0ms); will-change: opacity, translate, scale; }',
    '%root% [data-reveal="left"] { translate: -32px 0; }',
    '%root% [data-reveal="right"] { translate: 32px 0; }',
    '%root% [data-reveal="scale"] { translate: 0 0; scale: 0.97; }',
    '%root% [data-reveal][data-revealed="true"] { opacity: 1; translate: 0 0; scale: 1; }',
    '@media (prefers-reduced-motion: reduce) { %root% [data-reveal] { opacity: 1 !important; translate: 0 0 !important; scale: 1 !important; transition: none !important; } }',
  ].join('\n');
}

function renderPixflowStageBHtmlBaselineReport(plan, baseline, globalClasses, content) {
  const lines = [];
  lines.push('# Stage B Baseline Conversion Report');
  lines.push('');
  lines.push('Mode: Pixflow-owned clean-room HTML-to-Bricks baseline. Bricks source code was not copied; the converter targets the copied-elements JSON contract and Pixflow Stage B QA rules.');
  lines.push('');
  lines.push('## Summary');
  lines.push('');
  lines.push(`- Source title: ${safe(plan.source?.title)}`);
  lines.push(`- Page elements: ${content.length}`);
  lines.push(`- Header elements: ${Number(baseline.headerContent?.length || 0)}`);
  lines.push(`- Footer elements: ${Number(baseline.footerContent?.length || 0)}`);
  lines.push(`- Global classes: ${globalClasses.length}`);
  lines.push(`- CSS rules observed: ${Number(baseline.summary?.cssRuleCount || 0)}`);
  lines.push(`- Source tokens referenced: ${baseline.tokensUsed.join(', ') || '-'}`);
  lines.push('');
  lines.push('## Conversion Policy');
  lines.push('');
  lines.push('- Stage A DOM hierarchy is used as the first-pass structure instead of a model-authored blank Bricks payload.');
  lines.push('- Source classes are preserved as Bricks global classes and applied to elements by class id.');
  lines.push('- Simple source CSS declarations are projected onto Bricks settings for layout, type, spacing, colors, radius, borders, media sizing, and flex/grid controls.');
  lines.push('- Selector details, pseudo states, and unsupported effects remain scoped in global-class `_cssCustom` with `%root%` selectors. Routine layout, spacing, typography, background, border, radius, media, and object-fit declarations are represented as Bricks settings instead of duplicated in `_cssCustom`.');
  lines.push('- Visible pseudo-element marks such as label rules, timeline lines, and small dividers should be rebuilt as editable Bricks child elements when practical; do not use `%root%::before`/`%root%::after` for token buckets or page-wide overlays.');
  lines.push('- CTA anchors with source button classes become Bricks `button` elements, with Pixflow Tabler SVG placeholders replacing inline arrow SVGs.');
  lines.push('- Stage A `data-*`, `aria-*`, `role`, `title`, and `tabindex` attributes are represented with Bricks `_attributes`.');
  lines.push('- Stage A JavaScript is carried in Bricks page settings (`customScriptsBodyFooter`) as a complete script block; Bricks `code` elements are not used for Stage B JavaScript.');
  lines.push('- Font imports are intentionally not emitted; `stage-b-font-system.json` remains the installer contract.');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function normalizeFlags(flags) {
  const aliases = {
    c: 'config',
    h: 'help',
    'site-url': 'siteUrl',
    'rest-namespace': 'restNamespace',
    'prompt-file': 'promptFile',
    'metadata-file': 'metadataFile',
    'source-id': 'sourceId',
    'run-id': 'runId',
    'handoff-file': 'handoffFile',
    'stage-a-workspace': 'stageAWorkspace',
    'workspace-dir': 'workspaceDir',
    'out-dir': 'outDir',
    'project-id': 'projectId',
    'result-file': 'resultFile',
    'qa-file': 'qaFile',
    'conversion-report-file': 'conversionReportFile',
    'page-title': 'pageTitle',
    'target-post-id': 'targetPostId',
    'replace-existing': 'replaceExisting',
    'post-status': 'postStatus',
    'include-header': 'includeHeader',
    'header-scope': 'headerScope',
    'header-title': 'headerTitle',
    'header-template-title': 'headerTemplateTitle',
    'include-footer': 'includeFooter',
    'footer-scope': 'footerScope',
    'footer-title': 'footerTitle',
    'footer-template-title': 'footerTemplateTitle',
    'route-id': 'routeId',
    'route-label': 'routeLabel',
    'framework-route': 'frameworkRoute',
    'style-mode': 'styleMode',
    'bridge-status-file': 'bridgeStatusFile',
    'style-status-file': 'styleStatusFile',
    'theme-style-state-file': 'themeStyleStateFile',
    'route-contract-file': 'routeContractFile',
    'theme-style-contract-file': 'themeStyleContractFile',
    'theme-style-health-file': 'themeStyleHealthFile',
    'create-theme-style-baseline': 'createThemeStyleBaseline',
    'theme-style-scope': 'themeStyleScope',
    'skip-status-preflight': 'skipStatusPreflight',
    'wp-cookie': 'wpCookie',
    'wp-cookies': 'wpCookie',
    'runner-command': 'runnerCommand',
    'repair-attempts': 'repairAttempts',
    'stage-b-min-score': 'stageBMinScore',
    'stage-b-allow-p1': 'stageBAllowP1',
    'allow-stage-b-p1': 'stageBAllowP1',
    'allow-low-stage-b-qa': 'allowLowStageBQa',
    'skip-stage-b-qa-gate': 'allowLowStageBQa',
    'daemon-url': 'daemonUrl',
    'data-dir': 'dataDir',
    'no-open': 'noOpen',
    'no-browser': 'noBrowser',
  };
  const normalized = {};
  for (const [key, value] of Object.entries(flags)) {
    normalized[aliases[key] || key] = value;
  }
  return normalized;
}

async function buildImportArtifactPayload(flags) {
  const htmlPath = firstString(flags.html, flags.file, flags.artifact);
  if (!htmlPath) {
    throw new CliError('Missing required --html <path> for import-artifact.');
  }

  const html = await readTextFile(htmlPath, 'HTML artifact');
  const prompt = flags.promptFile
    ? await readTextFile(flags.promptFile, 'prompt file')
    : firstString(flags.prompt);
  const metadata = await readMetadata(flags);
  const handoff = await readImportHandoff(flags, htmlPath, metadata);

  const fidelity = firstString(flags.fidelity, metadata.fidelity, 'high_fidelity');
  const sourceId = firstString(flags.sourceId, metadata.sourceId, metadata.source_id, path.basename(path.dirname(path.resolve(htmlPath))) || 'pixflow-cli-stage-a');
  const requestPayload = buildStageAImportRequestPayload({
    prompt,
    fidelity,
    sourceId,
    metadata,
    handoff,
  });

  return {
    artifact: {
      html,
      sourceId,
    },
    metadata: {
      ...metadata,
      sourceId,
      importedFrom: path.resolve(htmlPath),
    },
    request_payload: requestPayload,
    prompt,
    fidelity,
    sourceId,
  };
}

async function readImportHandoff(flags, htmlPath, metadata) {
  const explicitPath = firstString(flags.handoff, flags.handoffFile);
  if (explicitPath) {
    return await readOptionalJson(explicitPath);
  }

  const candidates = [];
  if (flags.metadataFile) {
    candidates.push(path.join(path.dirname(path.resolve(process.cwd(), flags.metadataFile)), 'handoff.json'));
  }
  candidates.push(path.join(path.dirname(path.resolve(process.cwd(), htmlPath)), '..', 'handoff.json'));
  candidates.push(path.join(path.dirname(path.resolve(process.cwd(), htmlPath)), 'handoff.json'));

  for (const candidate of candidates) {
    const handoff = await readOptionalJson(candidate);
    if (Object.keys(handoff).length > 0) {
      return handoff;
    }
  }

  return isPlainObject(metadata.handoff) ? metadata.handoff : {};
}

function buildStageAImportRequestPayload({ prompt, fidelity, sourceId, metadata, handoff }) {
  const selectedPrototype = firstPlainObject(
    metadata.selectedPrototype,
    metadata.selected_prototype,
    handoff?.selectedPrototype,
    handoff?.selected_prototype
  );
  const selectedTemplate = firstPlainObject(
    metadata.selectedTemplate,
    metadata.selected_template,
    handoff?.selectedTemplate,
    handoff?.selected_template
  );
  const selectedPixflowDesignSystem = firstPlainObject(
    metadata.selectedPixflowDesignSystem,
    metadata.selected_pixflow_design_system,
    metadata.pixflowDesignSystem,
    metadata.pixflow_design_system,
    handoff?.pixflowDesignSystem,
    handoff?.pixflow_design_system,
    handoff?.selectedPixflowDesignSystem,
    handoff?.selected_pixflow_design_system
  );
  const workflow = firstPlainObject(metadata.workflow, handoff?.workflow);
  const target = firstPlainObject(metadata.target, handoff?.target);
  const prototypeId = normalizeKey(firstString(
    selectedPrototype?.id,
    selectedPrototype?.slug,
    selectedPrototype?.key,
    sourceId
  ));
  const pluginId = normalizeKey(firstString(
    selectedPrototype?.pluginId,
    selectedPrototype?.plugin_id,
    selectedPrototype?.source,
    selectedPrototype?.id,
    sourceId
  ));
  const templateId = normalizeKey(firstString(
    selectedTemplate?.id,
    selectedTemplate?.slug,
    selectedTemplate?.key,
    prototypeId
  ));
  const systemId = normalizeKey(firstString(
    selectedPixflowDesignSystem?.key,
    selectedPixflowDesignSystem?.id,
    selectedPixflowDesignSystem?.slug,
    selectedPixflowDesignSystem?.name,
    handoff?.pixflowDesignSystemId,
    metadata.pixflowDesignSystemId
  ));
  const pageTitle = firstString(
    target?.pageTitle,
    target?.title,
    metadata.title,
    selectedPrototype?.title,
    selectedPrototype?.name,
    sourceId
  );
  const payload = {
    prompt,
    current_page_title: pageTitle,
    page_title: pageTitle,
    fidelity,
    prototype_fidelity: fidelity,
    direct_stage_a_artifact_first: true,
    directStageAArtifactFirst: true,
    direct_pixflow_design_mode: true,
    directPixflowDesignMode: true,
    direct_cli_bridge_import: true,
    directCliBridgeImport: true,
    direct_generation_stage: DEFAULT_STAGE,
    directGenerationStage: DEFAULT_STAGE,
    bricks_excluded: true,
    bricksExcluded: true,
  };

  if (Object.keys(selectedPrototype).length > 0) {
    payload.selectedPrototype = selectedPrototype;
    payload.selected_prototype = selectedPrototype;
    payload.direct_pixflow_design_example = selectedPrototype;
    payload.directPixflowDesignExample = selectedPrototype;
  }
  if (Object.keys(selectedTemplate).length > 0) {
    payload.selectedTemplate = selectedTemplate;
    payload.selected_template = selectedTemplate;
  }
  if (Object.keys(selectedPixflowDesignSystem).length > 0) {
    payload.selectedPixflowDesignSystem = selectedPixflowDesignSystem;
    payload.selected_pixflow_design_system = selectedPixflowDesignSystem;
  }
  if (Object.keys(workflow).length > 0) {
    payload.workflow = workflow;
  }
  if (Object.keys(target).length > 0) {
    payload.target = target;
  }
  if (pluginId) {
    payload.direct_pixflow_design_plugin_id = pluginId;
    payload.directPixflowDesignPluginId = pluginId;
  }
  if (prototypeId) {
    payload.direct_pixflow_design_skill = prototypeId;
    payload.pixflow_design_skill = prototypeId;
  }
  if (templateId) {
    payload.direct_pixflow_design_template = templateId;
    payload.pixflow_design_template = templateId;
  }
  if (systemId) {
    payload.direct_pixflow_design_system = systemId;
    payload.pixflow_design_system = systemId;
    payload.pixflowDesignSystemId = systemId;
  }

  return payload;
}

async function buildStageBImportPayload(flags) {
  const runId = firstString(flags.runId, flags.run, flags.run_id);
  if (!runId) {
    throw new CliError('Missing required --run-id <id> for Stage B import.');
  }

  const resultPath = resolveStageBResultPath(flags);
  const result = await readJsonFile(resultPath, 'Stage B Bricks result');
  const workspaceDir = path.dirname(path.resolve(process.cwd(), resultPath));
  const colorSystem = await readStageBColorSystem(flags, workspaceDir);
  const contracts = await readStageBContracts(flags, workspaceDir);
  const resultWithColorSystem = attachStageBContractsToResult(
    attachStageBColorSystemToResult(result, colorSystem),
    contracts
  );
  const metadataFile = firstString(flags.metadataFile, path.join(workspaceDir, 'metadata.json'));
  const metadata = await readOptionalJson(metadataFile);
  const qaFile = firstString(flags.qaFile, path.join(workspaceDir, 'stage-b-qa.json'));
  const qa = await readOptionalJson(qaFile);
  assertStageBRemoteQaReady(qa, qaFile, flags, 'Stage B import');
  const conversionReportFile = firstString(flags.conversionReportFile, path.join(workspaceDir, 'conversion-report.md'));
  const conversionReport = await readOptionalText(conversionReportFile);
  const title = firstString(flags.title, flags.pageTitle, metadata.title, result.page_title, result.pageTitle, metadata.sourceId, metadata.source_id);
  const titledResult = applyStageBPayloadTitle(resultWithColorSystem, title);
  const sourceId = firstString(flags.sourceId, flags.source_id, metadata.sourceId, metadata.source_id, result.source_id, result.sourceId, path.basename(workspaceDir));
  const headerOptions = buildStageBHeaderPayloadOptions(flags);
  const footerOptions = buildStageBFooterPayloadOptions(flags);
  const binaryAssets = await collectStageBPayloadBinaryAssets(workspaceDir, titledResult);

  const payload = {
    runId,
    result: titledResult,
    colorSystem,
    routeContract: contracts.routeContract,
    themeStyleContract: contracts.themeStyleContract,
    themeStyleHealth: contracts.themeStyleHealth,
    metadata: {
      ...metadata,
      sourceId,
      importedFrom: path.resolve(resultPath),
    },
    qa,
    conversionReport,
    title,
    pageTitle: title,
    page_title: title,
    sourceId,
  };
  if (binaryAssets.length > 0) {
    payload.workspace = { binary_assets: binaryAssets };
    payload.binary_assets = binaryAssets;
  }
  if (Object.keys(headerOptions).length > 0) {
    payload.stageBHeader = headerOptions;
  }
  if (Object.keys(footerOptions).length > 0) {
    payload.stageBFooter = footerOptions;
  }
  return payload;
}

async function buildStageBInsertPayload(flags) {
  const payload = {
    runId: firstString(flags.runId, flags.run, flags.run_id),
  };
  if (!payload.runId) {
    throw new CliError('Missing required --run-id <id> for Stage B insert.');
  }

  const resultPath = firstString(flags.resultFile, flags.result, flags.bricksResult, flags.file);
  if (resultPath) {
    const workspaceDir = path.dirname(path.resolve(process.cwd(), resultPath));
    const result = await readJsonFile(resultPath, 'Stage B Bricks result');
    const colorSystem = await readStageBColorSystem(flags, workspaceDir);
    const contracts = await readStageBContracts(flags, workspaceDir);
    const title = firstString(flags.title, flags.pageTitle);
    payload.result = applyStageBPayloadTitle(
      attachStageBContractsToResult(attachStageBColorSystemToResult(result, colorSystem), contracts),
      title
    );
    const binaryAssets = await collectStageBPayloadBinaryAssets(workspaceDir, payload.result);
    if (binaryAssets.length > 0) {
      payload.workspace = { binary_assets: binaryAssets };
      payload.binary_assets = binaryAssets;
    }
    payload.colorSystem = colorSystem;
    payload.routeContract = contracts.routeContract;
    payload.themeStyleContract = contracts.themeStyleContract;
    payload.themeStyleHealth = contracts.themeStyleHealth;
    const metadata = await readOptionalJson(firstString(flags.metadataFile, path.join(workspaceDir, 'metadata.json')));
    if (Object.keys(metadata).length > 0) {
      payload.metadata = metadata;
    }
    const qa = await readOptionalJson(firstString(flags.qaFile, path.join(workspaceDir, 'stage-b-qa.json')));
    assertStageBRemoteQaReady(qa, firstString(flags.qaFile, path.join(workspaceDir, 'stage-b-qa.json')), flags, 'Stage B insert');
    if (Object.keys(qa).length > 0) {
      payload.qa = qa;
    }
    const report = await readOptionalText(firstString(flags.conversionReportFile, path.join(workspaceDir, 'conversion-report.md')));
    if (report) {
      payload.conversionReport = report;
    }
  }

  const title = firstString(flags.title, flags.pageTitle);
  if (title) {
    payload.title = title;
    payload.pageTitle = title;
    payload.page_title = title;
    payload.postTitle = title;
  }
  const targetPostId = firstString(flags.targetPostId, flags.postId, flags.post_id);
  if (targetPostId) {
    payload.targetPostId = targetPostId;
  }
  const projectId = firstString(flags.projectId, flags.project_id);
  if (projectId) {
    payload.projectId = projectId;
  }
  const replaceExisting = firstString(flags.replaceExisting);
  if (replaceExisting) {
    payload.replaceExisting = replaceExisting;
  }
  const postStatus = firstString(flags.postStatus);
  if (postStatus) {
    payload.postStatus = postStatus;
  }
  const headerOptions = buildStageBHeaderPayloadOptions(flags);
  if (Object.keys(headerOptions).length > 0) {
    payload.stageBHeader = headerOptions;
  }
  const footerOptions = buildStageBFooterPayloadOptions(flags);
  if (Object.keys(footerOptions).length > 0) {
    payload.stageBFooter = footerOptions;
  }

  return payload;
}

function applyStageBPayloadTitle(result, title) {
  const normalizedTitle = firstString(title);
  if (!normalizedTitle || !isPlainObject(result)) {
    return result;
  }

  return {
    ...result,
    page_title: normalizedTitle,
    pageTitle: normalizedTitle,
  };
}

function buildStageBHeaderPayloadOptions(flags) {
  const options = {};
  if (Object.prototype.hasOwnProperty.call(flags, 'includeHeader')) {
    options.includeHeader = flags.includeHeader;
  }
  const scope = firstString(flags.headerScope);
  if (scope) {
    options.scope = scope;
  }
  const title = firstString(flags.headerTemplateTitle, flags.headerTitle);
  if (title) {
    options.templateTitle = title;
  }
  return options;
}

function buildStageBFooterPayloadOptions(flags) {
  const options = {};
  if (Object.prototype.hasOwnProperty.call(flags, 'includeFooter')) {
    options.includeFooter = flags.includeFooter;
  }
  const scope = firstString(flags.footerScope);
  if (scope) {
    options.scope = scope;
  }
  const title = firstString(flags.footerTemplateTitle, flags.footerTitle);
  if (title) {
    options.templateTitle = title;
  }
  return options;
}

async function collectStageBPayloadBinaryAssets(workspaceDir, result) {
  const refs = collectStageBLocalBinaryAssetRefs(result);
  const assets = [];
  const seenDestinations = new Set();
  for (const ref of refs) {
    const destination = stageBServerAssetDestination(ref);
    if (!destination || seenDestinations.has(destination)) {
      continue;
    }
    const sourcePath = await resolveStageBWorkspaceAssetPath(workspaceDir, ref, destination);
    if (!sourcePath) {
      continue;
    }
    const buffer = await fs.readFile(sourcePath);
    if (buffer.length <= 0 || buffer.length > 25 * 1024 * 1024) {
      continue;
    }
    seenDestinations.add(destination);
    assets.push({
      workspaceFile: destination,
      workspace_file: destination,
      contentBase64: buffer.toString('base64'),
      mimeType: mimeTypeForStageBAssetPath(destination),
      size: buffer.length,
    });
  }
  return assets;
}

function collectStageBLocalBinaryAssetRefs(value, refs = new Set()) {
  if (Array.isArray(value)) {
    for (const item of value) {
      collectStageBLocalBinaryAssetRefs(item, refs);
    }
    return [...refs];
  }
  if (isPlainObject(value)) {
    for (const item of Object.values(value)) {
      collectStageBLocalBinaryAssetRefs(item, refs);
    }
    return [...refs];
  }
  if (typeof value !== 'string') {
    return [...refs];
  }
  const ref = normalizeStageBLocalAssetRef(value);
  if (ref) {
    refs.add(ref);
  }
  return [...refs];
}

function normalizeStageBLocalAssetRef(value) {
  let ref = String(value || '').trim().replace(/\\/g, '/');
  if (!ref || /^(?:https?:\/\/|data:|blob:|\/|[a-z]:\/)/i.test(ref)) {
    return '';
  }
  ref = ref.replace(/^\.\/+/, '').replace(/\/+/g, '/');
  if (!/\.(?:png|jpe?g|webp|avif|gif|svg)$/i.test(ref)) {
    return '';
  }
  if (
    ref.startsWith('assets/')
    || ref.startsWith('drafts/assets/')
    || ref.startsWith('stage-a/drafts/assets/')
    || ref.startsWith('stage-a/assets/')
  ) {
    return ref;
  }
  return '';
}

function stageBServerAssetDestination(ref) {
  if (ref.startsWith('drafts/assets/')) {
    return ref;
  }
  if (ref.startsWith('assets/')) {
    return `drafts/${ref}`;
  }
  if (ref.startsWith('stage-a/drafts/assets/')) {
    return ref.slice('stage-a/'.length);
  }
  if (ref.startsWith('stage-a/assets/')) {
    return `drafts/assets/${ref.slice('stage-a/assets/'.length)}`;
  }
  return '';
}

async function resolveStageBWorkspaceAssetPath(workspaceDir, ref, destination) {
  const candidates = [
    path.join(workspaceDir, ref),
    path.join(workspaceDir, destination),
  ];
  if (destination.startsWith('drafts/assets/')) {
    const assetName = destination.slice('drafts/assets/'.length);
    candidates.push(path.join(workspaceDir, 'assets', assetName));
    candidates.push(path.join(workspaceDir, 'stage-a', 'drafts', 'assets', assetName));
  }
  for (const candidate of candidates) {
    try {
      const stat = await fs.stat(candidate);
      if (stat.isFile()) {
        return candidate;
      }
    } catch {
      // Keep trying candidates.
    }
  }
  return '';
}

function mimeTypeForStageBAssetPath(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.jpg' || ext === '.jpeg') return 'image/jpeg';
  if (ext === '.webp') return 'image/webp';
  if (ext === '.avif') return 'image/avif';
  if (ext === '.gif') return 'image/gif';
  if (ext === '.svg') return 'image/svg+xml';
  return 'image/png';
}

async function readStageBColorSystem(flags, workspaceDir) {
  const colorSystemFile = firstString(
    flags.colorSystemFile,
    flags.colorSystem,
    flags.color_system,
    path.join(workspaceDir, 'stage-b-color-system.json')
  );
  if (!colorSystemFile) {
    return {};
  }
  return await readOptionalJson(colorSystemFile);
}

async function readStageBContracts(flags, workspaceDir) {
  const routeContractFile = firstString(
    flags.routeContractFile,
    flags.routeContract,
    path.join(workspaceDir, 'stage-b-route-contract.json')
  );
  const themeStyleContractFile = firstString(
    flags.themeStyleContractFile,
    flags.themeStyleContract,
    path.join(workspaceDir, 'stage-b-theme-style-contract.json')
  );
  const themeStyleHealthFile = firstString(
    flags.themeStyleHealthFile,
    flags.themeStyleHealth,
    path.join(workspaceDir, 'stage-b-theme-style-health.json')
  );
  return {
    routeContract: await readOptionalJson(routeContractFile),
    themeStyleContract: await readOptionalJson(themeStyleContractFile),
    themeStyleHealth: await readOptionalJson(themeStyleHealthFile),
  };
}

function attachStageBColorSystemToResult(result, colorSystem) {
  if (!colorSystem || Object.keys(colorSystem).length === 0) {
    return result;
  }
  return {
    ...result,
    stage_b_color_system: colorSystem,
    color_system: result.color_system || colorSystem,
  };
}

function attachStageBContractsToResult(result, contracts) {
  const routeContract = objectValue(contracts?.routeContract);
  const themeStyleContract = objectValue(contracts?.themeStyleContract);
  const themeStyleHealth = objectValue(contracts?.themeStyleHealth);
  const next = { ...result };
  if (Object.keys(routeContract).length > 0 && !next.stage_b_route_contract) {
    next.stage_b_route_contract = routeContract;
  }
  if (Object.keys(themeStyleContract).length > 0 && !next.stage_b_theme_style_contract) {
    next.stage_b_theme_style_contract = themeStyleContract;
  }
  if (Object.keys(themeStyleHealth).length > 0 && !next.stage_b_theme_style_health) {
    next.stage_b_theme_style_health = themeStyleHealth;
  }
  return next;
}

function resolveStageBResultPath(flags) {
  const explicit = firstString(flags.resultFile, flags.result, flags.bricksResult, flags.file);
  if (explicit) {
    return explicit;
  }

  const workspaceDir = firstString(flags.workspace, flags.workspaceDir, flags.cwd, '.');
  return path.join(workspaceDir, 'bricks-result.json');
}

async function readTextFile(filePath, label) {
  const absolutePath = path.resolve(process.cwd(), filePath);
  try {
    return await fs.readFile(absolutePath, 'utf8');
  } catch (error) {
    throw new CliError(`Could not read ${label}: ${absolutePath}`);
  }
}

async function readMetadata(flags) {
  if (flags.metadataFile) {
    const raw = stripBom(await readTextFile(flags.metadataFile, 'metadata file'));
    try {
      return JSON.parse(raw);
    } catch (error) {
      throw new CliError(`Metadata file is not valid JSON: ${path.resolve(process.cwd(), flags.metadataFile)}`);
    }
  }

  if (typeof flags.metadata === 'string' && flags.metadata.trim() !== '') {
    try {
      return JSON.parse(flags.metadata);
    } catch (error) {
      throw new CliError('--metadata must be a JSON object string.');
    }
  }

  return {};
}

async function prepareStageAWorkspace(flags) {
  const handoffPath = firstString(flags.handoff, flags.handoffFile, flags.file);
  if (!handoffPath) {
    throw new CliError('Missing required --handoff <path> for prepare-stage-a.');
  }

  const handoff = await readJsonFile(handoffPath, 'Stage A handoff');
  const sourceId = inferStageASourceId(handoff, flags);
  const workspaceRoot = path.resolve(
    process.cwd(),
    firstString(flags.workspace, flags.workspaceDir, flags.outDir, './pixflow-stage-a-runs')
  );
  const workspaceDir = path.join(workspaceRoot, sourceId);
  await ensureStageAWorkspace(workspaceDir, Boolean(flags.force));

  const prompt = inferStageAPrompt(handoff);
  const userPrompt = firstString(handoff?.prompt?.userPrompt, prompt);
  const fidelity = firstString(
    flags.fidelity,
    handoff?.workflow?.fidelity,
    handoff?.workflow?.prototypeFidelity,
    handoff?.context?.prototype_fidelity,
    'high_fidelity'
  );
  const title = inferStageATitle(handoff, sourceId);
  const requiredModelReads = requiredModelReadsFromHandoff(handoff);
  const metadata = {
    sourceId,
    title,
    fidelity,
    stage: DEFAULT_STAGE,
    executionMode: 'local_cli',
    handoffType: firstString(handoff?.type, 'pixflow_design_cli_stage_a_handoff'),
    handoffVersion: handoff?.version || 1,
    generatedAt: new Date().toISOString(),
    target: handoff?.target || {},
    selectedPrototype: handoff?.selectedPrototype || null,
    selectedTemplate: handoff?.selectedTemplate || null,
    selectedPixflowDesignSystem: handoff?.pixflowDesignSystem || null,
    requiredModelReads,
  };

  const files = {
    handoff: path.join(workspaceDir, 'handoff.json'),
    prompt: path.join(workspaceDir, 'prompt.md'),
    userPrompt: path.join(workspaceDir, 'user-prompt.md'),
    brief: path.join(workspaceDir, 'brief.md'),
    context: path.join(workspaceDir, 'context.json'),
    instructions: path.join(workspaceDir, 'AGENTS.md'),
    todo: path.join(workspaceDir, 'TODO.md'),
    runnerPrompt: path.join(workspaceDir, 'codex-stage-a-prompt.txt'),
    metadata: path.join(workspaceDir, 'metadata.json'),
    artifact: path.join(workspaceDir, 'drafts', 'index.html'),
    screenshots: path.join(workspaceDir, 'screenshots'),
    qa: path.join(workspaceDir, 'stage-a-qa.json'),
  };

  await fs.mkdir(path.dirname(files.artifact), { recursive: true });
  await fs.mkdir(files.screenshots, { recursive: true });
  await Promise.all([
    writeTextFile(files.handoff, `${JSON.stringify(handoff, null, 2)}\n`),
    writeTextFile(files.prompt, renderPromptMarkdown(prompt)),
    writeTextFile(files.userPrompt, renderPromptMarkdown(userPrompt)),
    writeTextFile(files.brief, renderStageABrief(handoff, metadata)),
    writeTextFile(files.context, `${JSON.stringify(buildStageAContext(handoff), null, 2)}\n`),
    writeTextFile(files.instructions, renderStageAInstructions(handoff, metadata)),
    writeTextFile(files.todo, renderStageATodo(metadata)),
    writeTextFile(files.runnerPrompt, renderStageARunnerPrompt(metadata)),
    writeTextFile(files.metadata, `${JSON.stringify(metadata, null, 2)}\n`),
  ]);
  const preflightMaterialization = await materializeWorkspacePreflight(handoff, workspaceDir);
  const materializedSourceContract = await readOptionalJson(path.join(workspaceDir, 'source-contract.json'));
  const materializedRequiredReads = requiredModelReadsFromSourceContract(materializedSourceContract);
  if (materializedRequiredReads.length > 0 && !sameStringList(materializedRequiredReads, requiredModelReads)) {
    metadata.requiredModelReads = materializedRequiredReads;
    await Promise.all([
      writeTextFile(files.instructions, renderStageAInstructions(handoff, metadata)),
      writeTextFile(files.todo, renderStageATodo(metadata)),
      writeTextFile(files.metadata, `${JSON.stringify(metadata, null, 2)}\n`),
    ]);
  }

  const importCommand = [
    'node',
    'tools/pixflow-design-cli/pixflow-design-cli.mjs',
    'import-artifact',
    '--config',
    './pixflow-design-cli.config.json',
    '--html',
    quoteForShell(files.artifact),
    '--prompt-file',
    quoteForShell(files.prompt),
    '--metadata-file',
    quoteForShell(files.metadata),
  ].join(' ');
  const suggestedRunCommand = [
    'Get-Content',
    '-Raw',
    quoteForShell(files.runnerPrompt),
    '|',
    'codex',
    'exec',
    '--json',
    '--skip-git-repo-check',
    '--sandbox',
    'danger-full-access',
    '--cd',
    quoteForShell(workspaceDir),
    '-',
  ].join(' ');

  const result = {
    status: 'prepared',
    workspaceDir,
    sourceId,
    title,
    promptFile: files.prompt,
    instructionsFile: files.instructions,
    todoFile: files.todo,
    runnerPromptFile: files.runnerPrompt,
    metadataFile: files.metadata,
    artifactFile: files.artifact,
    screenshotsDir: files.screenshots,
    qaFile: files.qa,
    workspacePreflight: preflightMaterialization,
    suggestedRunCommand,
    importCommand,
  };

  await writeTextFile(path.join(workspaceDir, 'README.md'), renderStageAWorkspaceReadme(result));
  return result;
}

async function materializeWorkspacePreflight(handoff, workspaceDir) {
  const workspace = workspacePreflightFromHandoff(handoff);
  const result = {
    active: false,
    fileCount: 0,
    binaryAssetCount: 0,
    writtenFiles: [],
    writtenRuntimeSkillAliases: [],
    writtenBinaryAssets: [],
    skippedBinaryAssets: [],
  };

  if (!workspace) {
    return result;
  }

  result.active = true;
  const manifest = objectValue(workspace.manifest);
  const sourceContract = objectValue(workspace.source_contract || workspace.sourceContract);
  const diagnostics = objectValue(workspace.diagnostics);
  await Promise.all([
    writeJsonFile(path.join(workspaceDir, 'workspace-manifest.json'), manifest),
    writeJsonFile(path.join(workspaceDir, 'source-contract.json'), sourceContract),
    writeJsonFile(path.join(workspaceDir, 'workspace-diagnostics.json'), diagnostics),
  ]);
  result.writtenFiles.push('workspace-manifest.json', 'source-contract.json', 'workspace-diagnostics.json');

  const files = objectValue(workspace.files);
  for (const [relativePath, contents] of Object.entries(files)) {
    const safeRelativePath = normalizeWorkspaceRelativePath(relativePath);
    if (!safeRelativePath || typeof contents !== 'string') {
      continue;
    }
    await writeTextFile(path.join(workspaceDir, safeRelativePath), contents.endsWith('\n') ? contents : `${contents}\n`);
    result.writtenFiles.push(safeRelativePath);
  }

  const runtimeSkillAliases = await materializePixflowDesignRuntimeSkillAliases(files, workspaceDir);
  for (const aliasPath of runtimeSkillAliases.writtenFiles) {
    result.writtenRuntimeSkillAliases.push(aliasPath);
    result.writtenFiles.push(aliasPath);
    registerRuntimeSkillAliasInContracts({ manifest, sourceContract, aliasPath });
  }
  const runtimeRouteSlugs = runtimeRouteSlugsFromSources({
    runtimeSkillFiles: runtimeSkillAliases.writtenFiles,
    sourceContract,
    files,
    snapshotSkillSlug: runtimeSkillAliases.snapshotSkillSlug,
  });
  if (runtimeRouteSlugs.size > 0) {
    pruneSourceContractForRuntimeSkillRoute(sourceContract, runtimeRouteSlugs);
    pruneManifestForRuntimeSkillRoute(manifest, runtimeRouteSlugs);
    const prunedWorkspaceFiles = await pruneWorkspaceFilesForRuntimeRoute(files, workspaceDir, runtimeRouteSlugs);
    await pruneRuntimeRouteLegacyDirectories(workspaceDir);
    result.writtenFiles = result.writtenFiles.filter((file) => !prunedWorkspaceFiles.includes(file));
    await normalizeBriefForRuntimeSkillRoute(
      path.join(workspaceDir, 'brief.md'),
      runtimeSkillAliases.snapshotSkillSlug,
      runtimeSkillAliases.snapshotTitle
    );
    const brandSpecFile = await ensureBrandSpecFileForContract({ workspaceDir, sourceContract, manifest, diagnostics });
    if (brandSpecFile) {
      result.writtenFiles.push(brandSpecFile);
    }
    await Promise.all([
      writeJsonFile(path.join(workspaceDir, 'workspace-manifest.json'), manifest),
      writeJsonFile(path.join(workspaceDir, 'source-contract.json'), sourceContract),
    ]);
  }

  const binaryAssets = Array.isArray(workspace.binary_assets)
    ? workspace.binary_assets
    : Array.isArray(workspace.binaryAssets)
      ? workspace.binaryAssets
      : [];
  for (const asset of binaryAssets) {
    const written = await materializeWorkspaceBinaryAsset(asset, workspaceDir);
    if (written.ok) {
      result.writtenBinaryAssets.push(written.path);
    } else if (written.path || written.reason) {
      result.skippedBinaryAssets.push(written);
    }
  }

  result.fileCount = result.writtenFiles.length;
  result.binaryAssetCount = result.writtenBinaryAssets.length;
  return result;
}

async function materializePixflowDesignRuntimeSkillAliases(files, workspaceDir) {
  const writtenFiles = [];
  const aliases = new Map();
  const pluginFiles = objectValue(files);
  for (const [relativePath, contents] of Object.entries(pluginFiles)) {
    if (typeof contents !== 'string') continue;
    const safeRelativePath = normalizeWorkspaceRelativePath(relativePath);
    const match = safeRelativePath.match(/^\.od-plugins\/([^/]+)\/(.+)$/i);
    if (!match) continue;
    const skillSlug = normalizePixflowDesignRuntimeSkillSlug(match[1]);
    const assetPath = normalizeWorkspaceRelativePath(match[2]);
    if (!skillSlug || !assetPath) continue;
    aliases.set(`.od-skills/${skillSlug}/${assetPath}`, contents);
  }

  const snapshot = parseJsonText(pluginFiles['plugin-snapshot.json']);
  const snapshotSkillSlug = normalizePixflowDesignRuntimeSkillSlug(
    firstString(snapshot?.pluginId, snapshot?.plugin_id, snapshot?.pluginName, snapshot?.plugin_name)
  );
  const snapshotTitle = firstString(snapshot?.pluginTitle, snapshot?.plugin_title, snapshot?.title, snapshot?.pluginName, snapshot?.plugin_name);
  if (snapshotSkillSlug) {
    if (snapshot?.manifest && typeof snapshot.manifest === 'object' && !Array.isArray(snapshot.manifest)) {
      aliases.set(
        `.od-skills/${snapshotSkillSlug}/pixflow-design.json`,
        `${JSON.stringify(snapshot.manifest, null, 2)}\n`
      );
    }
    const selectedRoute = renderSelectedRuntimeSkillReadme(snapshot);
    if (selectedRoute) {
      aliases.set(`.od-skills/${snapshotSkillSlug}/selected-route.md`, selectedRoute);
    }
  }

  for (const [aliasPath, contents] of aliases.entries()) {
    if (pluginFiles[aliasPath]) continue;
    const safeAliasPath = normalizeWorkspaceRelativePath(aliasPath);
    if (!safeAliasPath || typeof contents !== 'string' || contents.trim() === '') continue;
    await writeTextFile(path.join(workspaceDir, safeAliasPath), contents.endsWith('\n') ? contents : `${contents}\n`);
    writtenFiles.push(safeAliasPath);
  }

  return { writtenFiles, snapshotSkillSlug, snapshotTitle };
}

function normalizePixflowDesignRuntimeSkillSlug(value) {
  const raw = firstString(value);
  if (!raw) {
    return '';
  }
  let slug = slugify(raw);
  if (slug.startsWith('example-')) {
    slug = slug.slice('example-'.length);
  }
  return slug;
}

function renderSelectedRuntimeSkillReadme(snapshot) {
  if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)) {
    return '';
  }
  const pluginId = firstString(snapshot.pluginId, snapshot.plugin_id);
  const title = firstString(snapshot.pluginTitle, snapshot.plugin_title, snapshot.pluginName, snapshot.plugin_name, pluginId);
  const description = firstString(snapshot.pluginDescription, snapshot.plugin_description, snapshot.manifest?.description);
  const stages = Array.isArray(snapshot.pipeline)
    ? snapshot.pipeline
      .map((stage) => `${firstString(stage?.id, stage?.label)}:${Array.isArray(stage?.atoms) ? stage.atoms.join(',') : ''}`)
      .filter(Boolean)
      .join('; ')
    : '';
  const lines = [
    `# ${title || 'Selected Pixflow Design Prototype'}`,
    '',
    'This file is generated by Pixflow to mirror Pixflow Design runtime skill staging.',
    'Read this route before authoring the Stage A artifact and treat it as the primary selected prototype skill.',
    '',
    `- Plugin id: ${pluginId || '-'}`,
    `- Pixflow Design runtime skill path: .od-skills/${normalizePixflowDesignRuntimeSkillSlug(pluginId) || '-'}`,
  ];
  if (description) lines.push(`- Description: ${description.replace(/\s+/g, ' ').trim()}`);
  if (stages) lines.push(`- Pipeline atoms: ${stages}`);
  return `${lines.join('\n')}\n`;
}

function registerRuntimeSkillAliasInContracts({ manifest, sourceContract, aliasPath }) {
  appendUniqueString(sourceContract, ['required_model_reads'], aliasPath);
  appendUniqueString(sourceContract, ['read_tracking', 'required_model_reads'], aliasPath);
  appendUniqueString(sourceContract, ['authoritative_files'], aliasPath);
  appendUniqueString(sourceContract, ['stage_a_resource_boundary', 'authoritative_files'], aliasPath);

  if (Array.isArray(manifest.files) && !manifest.files.some((file) => firstString(file?.name, file?.path) === aliasPath)) {
    manifest.files.push({
      name: aliasPath,
      path: aliasPath,
      role: 'pixflow_design_runtime_skill_alias',
      summary: 'Runtime-compatible selected prototype skill alias for Pixflow Design CLI parity.',
    });
  }
}

function pruneSourceContractForRuntimeSkillRoute(sourceContract, routeSlugs) {
  pruneStringArray(sourceContract, ['required_model_reads'], (value) => shouldPruneRuntimeRouteRead(value, routeSlugs));
  pruneStringArray(sourceContract, ['read_tracking', 'required_model_reads'], (value) => shouldPruneRuntimeRouteRead(value, routeSlugs));
  pruneStringArray(sourceContract, ['authoritative_files'], (value) => shouldPruneRuntimeRouteSource(value, routeSlugs));
  pruneStringArray(sourceContract, ['stage_a_resource_boundary', 'authoritative_files'], (value) => shouldPruneRuntimeRouteSource(value, routeSlugs));
}

function pruneManifestForRuntimeSkillRoute(manifest, routeSlugs) {
  if (!manifest || typeof manifest !== 'object' || !Array.isArray(manifest.files)) return;
  manifest.files = manifest.files.filter((file) => {
    const filePath = normalizeWorkspaceRelativePath(firstString(file?.name, file?.path));
    return filePath ? !shouldPruneRuntimeRouteSource(filePath, routeSlugs) : true;
  });
}

function runtimeRouteSlugsFromSources({ runtimeSkillFiles, sourceContract, files, snapshotSkillSlug }) {
  const snapshotSlug = normalizePixflowDesignRuntimeSkillSlug(snapshotSkillSlug);
  if (snapshotSlug) {
    return new Set([snapshotSlug]);
  }
  const routeSlugs = new Set();
  const addFromPath = (value) => {
    const match = firstString(value).match(/^\.od-skills\/([^/]+)\//i);
    if (match?.[1]) routeSlugs.add(match[1]);
  };
  for (const file of runtimeSkillFiles || []) addFromPath(file);
  for (const file of Object.keys(objectValue(files))) addFromPath(file);
  for (const file of [
    ...stringArrayFromUnknown(sourceContract?.required_model_reads),
    ...stringArrayFromUnknown(sourceContract?.authoritative_files),
    ...stringArrayFromUnknown(sourceContract?.read_tracking?.required_model_reads),
  ]) {
    addFromPath(file);
  }
  return routeSlugs;
}

async function pruneWorkspaceFilesForRuntimeRoute(files, workspaceDir, routeSlugs) {
  const pruned = [];
  for (const relativePath of Object.keys(objectValue(files))) {
    const safeRelativePath = normalizeWorkspaceRelativePath(relativePath);
    if (!safeRelativePath || !shouldPruneRuntimeRouteSource(safeRelativePath, routeSlugs)) continue;
    await deleteWorkspaceRelativeFile(workspaceDir, safeRelativePath);
    pruned.push(safeRelativePath);
  }
  return pruned;
}

async function pruneRuntimeRouteLegacyDirectories(workspaceDir) {
  for (const relativePath of ['.od-plugins', 'pixflow-design-stage-a']) {
    await deleteWorkspaceRelativeFile(workspaceDir, relativePath);
  }
}

async function normalizeBriefForRuntimeSkillRoute(briefPath, runtimeSkillSlug, runtimeSkillTitle) {
  const slug = normalizePixflowDesignRuntimeSkillSlug(runtimeSkillSlug);
  if (!slug) return;
  let contents = '';
  try {
    contents = await fs.readFile(briefPath, 'utf8');
  } catch {
    return;
  }
  const label = `${firstString(runtimeSkillTitle, slug)} (${slug})`;
  const normalized = contents
    .replace(/^Selected Pixflow Design skill:.*$/m, `Selected Pixflow Design skill: ${label}`)
    .replace(/^Selected Pixflow Design template:.*$/m, `Selected Pixflow Design template: ${label}`);
  if (normalized !== contents) {
    await writeTextFile(briefPath, normalized.endsWith('\n') ? normalized : `${normalized}\n`);
  }
}

async function ensureBrandSpecFileForContract({ workspaceDir, sourceContract, manifest, diagnostics }) {
  const expectsBrandSpec = [
    ...stringArrayFromUnknown(sourceContract?.authoritative_files),
    ...stringArrayFromUnknown(sourceContract?.required_model_reads),
    ...stringArrayFromUnknown(sourceContract?.read_tracking?.required_model_reads),
    ...stringArrayFromUnknown(manifest?.files?.map?.((file) => file?.name || file?.path)),
  ].some((file) => normalizeWorkspaceRelativePath(file) === 'brand-spec.md');
  if (!expectsBrandSpec) return '';
  const brandSpecPath = path.join(workspaceDir, 'brand-spec.md');
  if (existsSync(brandSpecPath)) return '';
  const status = firstString(diagnostics?.brand_spec_status, diagnostics?.brandSpecStatus, 'unavailable');
  const active = diagnostics?.brand_spec_active === true || diagnostics?.brandSpecActive === true;
  await writeTextFile(
    brandSpecPath,
    [
      '# Direct Generation Brand Spec',
      '',
      `Status: ${status}`,
      `Active: ${active ? 'true' : 'false'}`,
      '',
      'This compatibility file was generated because the workspace contract references `brand-spec.md` but the handoff did not include a standalone brand-spec file.',
      'Use the selected route skill, brief, design-system, and token/component channel as the primary Stage A source of truth.',
      '',
    ].join('\n')
  );
  return 'brand-spec.md';
}

function pruneStringArray(root, pathParts, predicate) {
  if (!root || typeof root !== 'object' || Array.isArray(root)) return;
  let target = root;
  for (const part of pathParts.slice(0, -1)) {
    if (!target[part] || typeof target[part] !== 'object' || Array.isArray(target[part])) {
      return;
    }
    target = target[part];
  }
  const key = pathParts[pathParts.length - 1];
  if (!Array.isArray(target[key])) return;
  target[key] = target[key].filter((value) => !predicate(firstString(value)));
}

function isPluginDiagnosticRead(value) {
  return /^\.od-plugins\/example-[^/]+\//i.test(firstString(value));
}

function shouldPruneRuntimeRouteRead(value, routeSlugs) {
  const text = firstString(value);
  if (!text) return false;
  if (isPluginDiagnosticRead(text)) return true;
  if (routeSlugs.size === 0) return false;
  if (text === 'skill.md' || text === 'layout-library.md') return true;
  const skillMatch = text.match(/^\.od-skills\/([^/]+)\//i);
  if (skillMatch && !routeSlugs.has(skillMatch[1])) return true;
  if (/^pixflow-design-stage-a\/pixflow-design-templates\//i.test(text)) return true;
  if (/^pixflow-design-stage-a\/pixflow-design-systems\//i.test(text)) return true;
  return false;
}

function shouldPruneRuntimeRouteSource(value, routeSlugs) {
  const text = firstString(value);
  if (!text) return false;
  if (isPluginDiagnosticRead(text)) return true;
  if (routeSlugs.size === 0) return false;
  if (text === 'skill.md' || text === 'layout-library.md') return true;
  const skillMatch = text.match(/^\.od-skills\/([^/]+)\//i);
  if (skillMatch && !routeSlugs.has(skillMatch[1])) return true;
  if (/^pixflow-design-stage-a\/pixflow-design-templates\//i.test(text)) return true;
  if (/^pixflow-design-stage-a\/pixflow-design-systems\//i.test(text)) return true;
  return false;
}

function appendUniqueString(root, pathParts, value) {
  if (!root || typeof root !== 'object' || Array.isArray(root) || !firstString(value)) {
    return;
  }
  let target = root;
  for (const part of pathParts.slice(0, -1)) {
    if (!target[part] || typeof target[part] !== 'object' || Array.isArray(target[part])) {
      target[part] = {};
    }
    target = target[part];
  }
  const key = pathParts[pathParts.length - 1];
  if (!Array.isArray(target[key])) {
    target[key] = [];
  }
  if (!target[key].includes(value)) {
    target[key].push(value);
  }
}

function parseJsonText(value) {
  if (typeof value !== 'string' || value.trim() === '') {
    return {};
  }
  try {
    return JSON.parse(value);
  } catch {
    return {};
  }
}

function workspacePreflightFromHandoff(handoff) {
  for (const key of ['workspacePreflight', 'workspace_preflight', 'workspace']) {
    const candidate = handoff?.[key];
    if (candidate && typeof candidate === 'object' && !Array.isArray(candidate)) {
      return candidate;
    }
  }
  return null;
}

async function materializeWorkspaceBinaryAsset(asset, workspaceDir) {
  if (!asset || typeof asset !== 'object' || Array.isArray(asset)) {
    return { ok: false, path: '', reason: 'invalid_asset' };
  }

  const relativePath = normalizeWorkspaceRelativePath(
    firstString(asset.workspaceFile, asset.workspace_file, asset.modelPath, asset.model_path, asset.path)
  );
  if (!relativePath) {
    return { ok: false, path: '', reason: 'missing_workspace_file' };
  }

  const targetPath = path.join(workspaceDir, relativePath);
  const base64 = firstString(asset.contentBase64, asset.content_base64, asset.base64);
  if (base64) {
    await fs.mkdir(path.dirname(targetPath), { recursive: true });
    await fs.writeFile(targetPath, Buffer.from(base64, 'base64'));
    return { ok: true, path: relativePath };
  }

  const downloadUrl = firstString(asset.downloadUrl, asset.download_url, asset.url);
  if (downloadUrl) {
    try {
      const response = await fetch(downloadUrl);
      if (!response.ok) {
        return { ok: false, path: relativePath, reason: `download_http_${response.status}` };
      }
      const bytes = Buffer.from(await response.arrayBuffer());
      await fs.mkdir(path.dirname(targetPath), { recursive: true });
      await fs.writeFile(targetPath, bytes);
      return { ok: true, path: relativePath };
    } catch (error) {
      return { ok: false, path: relativePath, reason: `download_failed:${error?.message || 'unknown'}` };
    }
  }

  const sourcePath = firstString(asset.sourcePath, asset.source_path);
  if (sourcePath) {
    try {
      await fs.mkdir(path.dirname(targetPath), { recursive: true });
      await fs.copyFile(sourcePath, targetPath);
      return { ok: true, path: relativePath };
    } catch (error) {
      return { ok: false, path: relativePath, reason: `copy_failed:${error?.message || 'unknown'}` };
    }
  }

  return { ok: false, path: relativePath, reason: 'no_asset_transport' };
}

async function writeJsonFile(filePath, value) {
  await writeTextFile(filePath, `${JSON.stringify(value || {}, null, 2)}\n`);
}

async function runStageAWorkspace(flags) {
  const prepared = await prepareStageAWorkspace(flags);
  const runnerInvocation = buildStageARunnerInvocation(prepared, flags);
  runnerInvocation.jsonOutput = Boolean(flags.json);
  const maxRepairAttempts = parseNonNegativeIntegerFlag(
    firstString(flags.repairAttempts, flags.repair_attempts),
    DEFAULT_STAGE_A_REPAIR_ATTEMPTS
  );
  const result = {
    ...prepared,
    status: 'running',
    runnerCommand: runnerInvocation.display,
    runner: runnerInvocation.kind,
    runnerExitCode: null,
    runnerEventsFile: runnerInvocation.eventsFile || null,
    runnerStderrFile: runnerInvocation.stderrFile || null,
    runnerEventSummary: null,
    repairAttempts: [],
    stageAQa: null,
    stageAToolTraceFile: null,
    imported: null,
  };

  const runnerResult = await runStageAInvocation(runnerInvocation, prepared.workspaceDir);
  result.runnerExitCode = runnerResult.code;
  result.runnerEventSummary = runnerResult.eventSummary;
  await assertStageAArtifactExists(prepared.artifactFile);
  const eventFiles = [runnerResult.eventsFile].filter(Boolean);
  let combinedEventsFile = await combineStageAEventLogs(prepared.workspaceDir, eventFiles);
  let activeRunnerResult = {
    ...runnerResult,
    eventsFile: combinedEventsFile || runnerResult.eventsFile,
    eventSummary: runnerResult.eventSummary,
  };
  result.stageAQa = await analyzeStageAArtifact(prepared, activeRunnerResult);
  await writeJsonFile(prepared.qaFile, result.stageAQa);
  result.stageAToolTraceFile = await writeStageAToolTrace(prepared.workspaceDir, activeRunnerResult, result.stageAQa);

  for (let attempt = 1; result.stageAQa?.blocking && attempt <= maxRepairAttempts; attempt += 1) {
    const repairPromptFile = path.join(prepared.workspaceDir, `codex-stage-a-repair-${attempt}.txt`);
    await writeTextFile(repairPromptFile, renderStageARepairPrompt(prepared, result.stageAQa, attempt, maxRepairAttempts));
    const repairInvocation = buildStageARunnerInvocation(prepared, flags, {
      stdinFile: repairPromptFile,
      eventsFile: path.join(prepared.workspaceDir, `stage-a-codex-repair-${attempt}-events.jsonl`),
      stderrFile: path.join(prepared.workspaceDir, `stage-a-codex-repair-${attempt}-stderr.log`),
    });
    repairInvocation.jsonOutput = Boolean(flags.json);
    const repairResult = await runStageAInvocation(repairInvocation, prepared.workspaceDir);
    eventFiles.push(repairResult.eventsFile);
    combinedEventsFile = await combineStageAEventLogs(prepared.workspaceDir, eventFiles);
    activeRunnerResult = {
      ...repairResult,
      eventsFile: combinedEventsFile || repairResult.eventsFile,
      eventSummary: mergeStageAEventSummaries(result.runnerEventSummary, repairResult.eventSummary),
    };
    result.runnerEventSummary = activeRunnerResult.eventSummary;
    result.repairAttempts.push({
      attempt,
      runnerCommand: repairInvocation.display,
      runnerExitCode: repairResult.code,
      runnerEventsFile: repairResult.eventsFile || null,
      runnerStderrFile: repairResult.stderrFile || null,
      qaBefore: summarizeStageAQa(result.stageAQa),
    });
    await assertStageAArtifactExists(prepared.artifactFile);
    result.stageAQa = await analyzeStageAArtifact(prepared, activeRunnerResult);
    await writeJsonFile(prepared.qaFile, result.stageAQa);
    result.stageAToolTraceFile = await writeStageAToolTrace(prepared.workspaceDir, activeRunnerResult, result.stageAQa);
    result.repairAttempts[result.repairAttempts.length - 1].qaAfter = summarizeStageAQa(result.stageAQa);
  }

  assertStageAQaPasses(result.stageAQa);
  result.status = 'artifact_ready';

  if (flags.import === true || flags.import === 'true') {
    const config = await loadConfig(flags);
    const client = createPixflowClient(config);
    const payload = await buildImportArtifactPayload({
      ...flags,
      html: prepared.artifactFile,
      promptFile: prepared.promptFile,
      metadataFile: prepared.metadataFile,
    });
    result.imported = await client.post('/cli-bridge/stage-a/import-artifact', payload);
    result.status = 'imported';
  }

  return result;
}

async function repairStageAWorkspace(flags) {
  const workspaceDir = path.resolve(
    process.cwd(),
    firstString(flags.workspace, flags.workspaceDir, flags.cwd, '.')
  );
  const prepared = buildPreparedStageAFromWorkspace(workspaceDir);
  const maxRepairAttempts = parseNonNegativeIntegerFlag(
    firstString(flags.repairAttempts, flags.repair_attempts),
    DEFAULT_STAGE_A_REPAIR_ATTEMPTS
  );
  const result = {
    ...prepared,
    status: 'repairing',
    runnerCommand: 'repair-stage-a',
    runner: firstString(flags.runner, flags.agent, 'codex'),
    runnerExitCode: null,
    runnerEventsFile: null,
    runnerStderrFile: null,
    runnerEventSummary: null,
    repairAttempts: [],
    stageAQa: null,
    stageAToolTraceFile: null,
    imported: null,
  };

  await assertStageAArtifactExists(prepared.artifactFile);
  const eventFiles = await collectStageAEventFiles(prepared.workspaceDir);
  const combinedEventsFile = await combineStageAEventLogs(prepared.workspaceDir, eventFiles);
  let activeRunnerResult = {
    code: 0,
    kind: 'codex',
    eventsFile: combinedEventsFile || eventFiles[0] || null,
    stderrFile: null,
    eventSummary: null,
  };
  result.stageAQa = await analyzeStageAArtifact(prepared, activeRunnerResult);
  await writeJsonFile(prepared.qaFile, result.stageAQa);
  result.stageAToolTraceFile = await writeStageAToolTrace(prepared.workspaceDir, activeRunnerResult, result.stageAQa);

  for (let attempt = 1; result.stageAQa?.blocking && attempt <= maxRepairAttempts; attempt += 1) {
    const repairPromptFile = path.join(prepared.workspaceDir, `codex-stage-a-repair-${attempt}.txt`);
    await writeTextFile(repairPromptFile, renderStageARepairPrompt(prepared, result.stageAQa, attempt, maxRepairAttempts));
    const repairInvocation = buildStageARunnerInvocation(prepared, flags, {
      stdinFile: repairPromptFile,
      eventsFile: path.join(prepared.workspaceDir, `stage-a-codex-repair-${attempt}-events.jsonl`),
      stderrFile: path.join(prepared.workspaceDir, `stage-a-codex-repair-${attempt}-stderr.log`),
    });
    repairInvocation.jsonOutput = Boolean(flags.json);
    const repairResult = await runStageAInvocation(repairInvocation, prepared.workspaceDir);
    eventFiles.push(repairResult.eventsFile);
    const repairedCombinedEventsFile = await combineStageAEventLogs(prepared.workspaceDir, eventFiles);
    activeRunnerResult = {
      ...repairResult,
      eventsFile: repairedCombinedEventsFile || repairResult.eventsFile,
      eventSummary: mergeStageAEventSummaries(result.runnerEventSummary, repairResult.eventSummary),
    };
    result.runnerExitCode = repairResult.code;
    result.runnerCommand = repairInvocation.display;
    result.runnerEventsFile = repairResult.eventsFile || null;
    result.runnerStderrFile = repairResult.stderrFile || null;
    result.runnerEventSummary = activeRunnerResult.eventSummary;
    result.repairAttempts.push({
      attempt,
      runnerCommand: repairInvocation.display,
      runnerExitCode: repairResult.code,
      runnerEventsFile: repairResult.eventsFile || null,
      runnerStderrFile: repairResult.stderrFile || null,
      qaBefore: summarizeStageAQa(result.stageAQa),
    });
    await assertStageAArtifactExists(prepared.artifactFile);
    result.stageAQa = await analyzeStageAArtifact(prepared, activeRunnerResult);
    await writeJsonFile(prepared.qaFile, result.stageAQa);
    result.stageAToolTraceFile = await writeStageAToolTrace(prepared.workspaceDir, activeRunnerResult, result.stageAQa);
    result.repairAttempts[result.repairAttempts.length - 1].qaAfter = summarizeStageAQa(result.stageAQa);
  }

  assertStageAQaPasses(result.stageAQa);
  result.status = 'artifact_ready';
  return result;
}

async function prepareStageBWorkspace(flags) {
  const stageAWorkspace = path.resolve(
    process.cwd(),
    firstString(flags.stageAWorkspace, flags.stage_a_workspace, flags.stageA, flags.stage_a, flags.from, flags.workspaceA)
  );
  if (!stageAWorkspace || stageAWorkspace === process.cwd()) {
    throw new CliError('Missing required --stage-a-workspace <path> for prepare-stage-b.');
  }

  const stageAArtifact = path.resolve(
    process.cwd(),
    firstString(flags.html, flags.artifact, path.join(stageAWorkspace, 'drafts', 'index.html'))
  );
  await assertFileExists(stageAArtifact, 'Stage A artifact');

  const stageAMetadataFile = path.join(stageAWorkspace, 'metadata.json');
  const stageAMetadata = await readOptionalJson(stageAMetadataFile);
  const sourceId = slugify(firstString(
    flags.projectId,
    flags.sourceId,
    flags.source_id,
    stageAMetadata.sourceId,
    path.basename(stageAWorkspace)
  ));
  const title = firstString(stageAMetadata.title, sourceId);
  const workspaceRoot = path.resolve(
    process.cwd(),
    firstString(flags.workspace, flags.workspaceDir, flags.outDir, './pixflow-stage-b-runs')
  );
  const workspaceDir = path.join(workspaceRoot, sourceId);
  await ensureStageBWorkspace(workspaceDir, Boolean(flags.force));

  const files = {
    stageAArtifact: path.join(workspaceDir, 'stage-a', 'drafts', 'index.html'),
    stageAMetadata: path.join(workspaceDir, 'stage-a', 'metadata.json'),
    stageAPrompt: path.join(workspaceDir, 'stage-a', 'prompt.md'),
    stageABrief: path.join(workspaceDir, 'stage-a', 'brief.md'),
    stageAComposition: path.join(workspaceDir, 'stage-a', 'composition-dna.md'),
    stageASelfCritique: path.join(workspaceDir, 'stage-a', 'stage-a-self-critique.md'),
    stageAQa: path.join(workspaceDir, 'stage-a', 'stage-a-qa.json'),
    stageADesignSystem: path.join(workspaceDir, 'stage-a', 'design-system.md'),
    stageATokens: path.join(workspaceDir, 'stage-a', 'tokens.css'),
    stageAComponentsManifest: path.join(workspaceDir, 'stage-a', 'components-manifest.md'),
    stageAComponentsHtml: path.join(workspaceDir, 'stage-a', 'components.html'),
    instructions: path.join(workspaceDir, 'AGENTS.md'),
    todo: path.join(workspaceDir, 'TODO.md'),
    runnerPrompt: path.join(workspaceDir, 'codex-stage-b-prompt.txt'),
    metadata: path.join(workspaceDir, 'metadata.json'),
    context: path.join(workspaceDir, 'stage-b-context.json'),
    bridgeStatus: path.join(workspaceDir, 'stage-b-bridge-status.json'),
    routeContract: path.join(workspaceDir, 'stage-b-route-contract.json'),
    themeStyleContract: path.join(workspaceDir, 'stage-b-theme-style-contract.json'),
    themeStyleHealth: path.join(workspaceDir, 'stage-b-theme-style-health.json'),
    sourceMap: path.join(workspaceDir, 'stage-b-source-map.json'),
    styleMap: path.join(workspaceDir, 'stage-b-style-map.json'),
    sectionMap: path.join(workspaceDir, 'stage-b-section-map.json'),
    conversionPlan: path.join(workspaceDir, 'stage-b-conversion-plan.json'),
    headerPlan: path.join(workspaceDir, 'stage-b-header-plan.json'),
    footerPlan: path.join(workspaceDir, 'stage-b-footer-plan.json'),
    classPlan: path.join(workspaceDir, 'stage-b-class-plan.json'),
    fidelityPlan: path.join(workspaceDir, 'stage-b-fidelity-plan.md'),
    colorSystem: path.join(workspaceDir, 'stage-b-color-system.json'),
    fontSystem: path.join(workspaceDir, 'stage-b-font-system.json'),
    iconSystem: path.join(workspaceDir, 'stage-b-icon-system.json'),
    colorUsage: path.join(workspaceDir, 'color-system-usage.json'),
    conversionReport: path.join(workspaceDir, 'conversion-report.md'),
    baselineResult: path.join(workspaceDir, 'bricks-baseline-result.json'),
    baselinePayload: path.join(workspaceDir, 'bricks-baseline-payload.json'),
    baselineHeaderPayload: path.join(workspaceDir, 'bricks-baseline-header-payload.json'),
    baselineFooterPayload: path.join(workspaceDir, 'bricks-baseline-footer-payload.json'),
    baselineGlobalClasses: path.join(workspaceDir, 'bricks-baseline-global-classes.json'),
    baselineReport: path.join(workspaceDir, 'stage-b-baseline-report.md'),
    bricksMcp: path.join(workspaceDir, 'pixflow-bricks-mcp.md'),
    pluginMcp: path.join(workspaceDir, 'pixflow-plugin-mcp.md'),
    result: path.join(workspaceDir, 'bricks-result.json'),
    payload: path.join(workspaceDir, 'bricks-payload.json'),
    headerPayload: path.join(workspaceDir, 'bricks-header-payload.json'),
    footerPayload: path.join(workspaceDir, 'bricks-footer-payload.json'),
    globalClasses: path.join(workspaceDir, 'global-classes.json'),
    qa: path.join(workspaceDir, 'stage-b-qa.json'),
  };

  const stageBMetadata = {
    sourceId,
    title,
    stage: 'stage_b',
    executionMode: 'local_cli',
    generatedAt: new Date().toISOString(),
    stageAWorkspace,
    stageAArtifact,
    stageAMetadata: summarizeStageAMetadataForStageB(stageAMetadata),
    outputContract: {
      result: 'bricks-result.json',
      content: 'bricks-payload.json',
      globalClasses: 'global-classes.json',
      bridgeStatus: 'stage-b-bridge-status.json',
      routeContract: 'stage-b-route-contract.json',
      themeStyleContract: 'stage-b-theme-style-contract.json',
      themeStyleHealth: 'stage-b-theme-style-health.json',
      sourceMap: 'stage-b-source-map.json',
      styleMap: 'stage-b-style-map.json',
      sectionMap: 'stage-b-section-map.json',
      headerPlan: 'stage-b-header-plan.json',
      footerPlan: 'stage-b-footer-plan.json',
      colorSystem: 'stage-b-color-system.json',
      fontSystem: 'stage-b-font-system.json',
      iconSystem: 'stage-b-icon-system.json',
      classPlan: 'stage-b-class-plan.json',
      fidelityPlan: 'stage-b-fidelity-plan.md',
      baselineResult: 'bricks-baseline-result.json',
      baselineContent: 'bricks-baseline-payload.json',
      baselineClasses: 'bricks-baseline-global-classes.json',
      baselineReport: 'stage-b-baseline-report.md',
      report: 'conversion-report.md',
    },
  };
  const stageBBridgeStatus = await resolveStageBBridgeStatus(flags);
  const stageBColorSystem = await buildStageBColorSystem(stageAWorkspace, stageAArtifact, title, stageAMetadata);
  const stageBFontSystem = await buildStageBFontSystem(stageAWorkspace, stageAArtifact, title, stageAMetadata);
  const stageBIconSystem = await buildStageBIconSystem(stageAWorkspace, stageAArtifact, title, stageAMetadata);
  const pixflowVariableInventory = await readPixflowFrameworkVariableInventory();
  const stageBRouteContract = buildStageBRouteContract({
    flags,
    stageAMetadata,
    bridgeStatus: stageBBridgeStatus,
    colorSystem: stageBColorSystem,
    pixflowVariableInventory,
  });
  const stageBThemeStyleHealth = buildStageBThemeStyleHealth(stageBBridgeStatus, stageBRouteContract, flags);
  const stageBThemeStyleContract = buildStageBThemeStyleContract(stageBRouteContract, stageBThemeStyleHealth, stageBBridgeStatus, flags);
  stageBMetadata.routeContract = summarizeStageBRouteContract(stageBRouteContract);
  stageBMetadata.themeStyleContract = summarizeStageBThemeStyleContract(stageBThemeStyleContract);
  const stageBContext = buildStageBContext(stageAWorkspace, stageAArtifact, stageAMetadata, {
    routeContract: stageBRouteContract,
    themeStyleContract: stageBThemeStyleContract,
    themeStyleHealth: stageBThemeStyleHealth,
    fontSystem: stageBFontSystem,
    iconSystem: stageBIconSystem,
  });
  const stageBSourceMap = await buildStageBSourceMap(stageAWorkspace, stageAArtifact, stageAMetadata);
  const stageBStyleMap = buildStageBStyleMap(stageBSourceMap, stageBColorSystem);
  const stageBSectionMap = buildStageBSectionMap(stageBSourceMap, stageBStyleMap);
  const stageBHeaderPlan = buildStageBHeaderPlan(stageBSourceMap, stageBSectionMap, flags, title);
  const stageBFooterPlan = buildStageBFooterPlan(stageBSourceMap, stageBSectionMap, flags, title);
  const stageBClassPlan = buildStageBClassPlan(stageBSourceMap, stageBStyleMap, stageBColorSystem);
  const stageBFidelityPlan = renderStageBFidelityPlan(stageBSourceMap, stageBStyleMap, stageBSectionMap, stageBClassPlan);
  const stageBConversionPlan = await buildStageBConversionPlan(stageAWorkspace, stageAArtifact, stageAMetadata, stageBColorSystem, {
    fontSystem: stageBFontSystem,
    iconSystem: stageBIconSystem,
    sourceMap: stageBSourceMap,
    styleMap: stageBStyleMap,
    sectionMap: stageBSectionMap,
    headerPlan: stageBHeaderPlan,
    footerPlan: stageBFooterPlan,
    classPlan: stageBClassPlan,
    routeContract: stageBRouteContract,
    themeStyleContract: stageBThemeStyleContract,
    themeStyleHealth: stageBThemeStyleHealth,
  });

  await Promise.all([
    copyExistingFile(stageAArtifact, files.stageAArtifact),
    copyExistingFile(stageAMetadataFile, files.stageAMetadata, '{}\n'),
    copyExistingFile(path.join(stageAWorkspace, 'prompt.md'), files.stageAPrompt, '\n'),
    copyExistingFile(path.join(stageAWorkspace, 'brief.md'), files.stageABrief, '\n'),
    copyExistingFile(path.join(stageAWorkspace, 'composition-dna.md'), files.stageAComposition, '\n'),
    copyExistingFile(path.join(stageAWorkspace, 'stage-a-self-critique.md'), files.stageASelfCritique, '\n'),
    copyExistingFile(path.join(stageAWorkspace, 'stage-a-qa.json'), files.stageAQa, '{}\n'),
    copyExistingFile(path.join(stageAWorkspace, 'design-system.md'), files.stageADesignSystem, '\n'),
    copyExistingFile(path.join(stageAWorkspace, 'tokens.css'), files.stageATokens, '\n'),
    copyExistingFile(path.join(stageAWorkspace, 'components-manifest.md'), files.stageAComponentsManifest, '\n'),
    copyExistingFile(path.join(stageAWorkspace, 'components.html'), files.stageAComponentsHtml, '\n'),
    writeJsonFile(files.metadata, stageBMetadata),
    writeJsonFile(files.context, stageBContext),
    writeJsonFile(files.bridgeStatus, stageBBridgeStatus),
    writeJsonFile(files.routeContract, stageBRouteContract),
    writeJsonFile(files.themeStyleContract, stageBThemeStyleContract),
    writeJsonFile(files.themeStyleHealth, stageBThemeStyleHealth),
    writeJsonFile(files.sourceMap, stageBSourceMap),
    writeJsonFile(files.styleMap, stageBStyleMap),
    writeJsonFile(files.sectionMap, stageBSectionMap),
    writeJsonFile(files.conversionPlan, stageBConversionPlan),
    writeJsonFile(files.headerPlan, stageBHeaderPlan),
    writeJsonFile(files.footerPlan, stageBFooterPlan),
    writeJsonFile(files.classPlan, stageBClassPlan),
    writeTextFile(files.fidelityPlan, stageBFidelityPlan),
    writeJsonFile(files.colorSystem, stageBColorSystem),
    writeJsonFile(files.fontSystem, stageBFontSystem),
    writeJsonFile(files.iconSystem, stageBIconSystem),
    writeTextFile(files.instructions, renderStageBInstructions(stageBMetadata)),
    writeTextFile(files.todo, renderStageBTodo(stageBMetadata)),
    writeTextFile(files.runnerPrompt, renderStageBRunnerPrompt(stageBMetadata)),
    writeTextFile(files.bricksMcp, renderPixflowBricksMcpMarkdown()),
    writeTextFile(files.pluginMcp, renderPixflowPluginMcpMarkdown()),
  ]);
  const stageAMedia = await materializeStageBStageAMedia(stageAWorkspace, workspaceDir);
  const skills = await materializeStageBBricksSkills(workspaceDir);
  const deterministicScaffold = await writeDeterministicStageBArtifacts({
    workspaceDir,
    sourceId,
    title,
    stageBMetadata,
    stageBColorSystem,
    stageBFontSystem,
    stageBIconSystem,
    stageBConversionPlan,
    files,
  });

  const suggestedRunCommand = [
    'Get-Content',
    '-Raw',
    quoteForShell(files.runnerPrompt),
    '|',
    'codex',
    'exec',
    '--json',
    '--skip-git-repo-check',
    '--sandbox',
    'danger-full-access',
    '--cd',
    quoteForShell(workspaceDir),
    '-',
  ].join(' ');

  const result = {
    status: 'prepared',
    workspaceDir,
    sourceId,
    title,
    stageAWorkspace,
    stageAArtifact,
    instructionsFile: files.instructions,
    todoFile: files.todo,
    runnerPromptFile: files.runnerPrompt,
    metadataFile: files.metadata,
    contextFile: files.context,
    bridgeStatusFile: files.bridgeStatus,
    routeContractFile: files.routeContract,
    themeStyleContractFile: files.themeStyleContract,
    themeStyleHealthFile: files.themeStyleHealth,
    sourceMapFile: files.sourceMap,
    styleMapFile: files.styleMap,
    sectionMapFile: files.sectionMap,
    conversionPlanFile: files.conversionPlan,
    headerPlanFile: files.headerPlan,
    footerPlanFile: files.footerPlan,
    classPlanFile: files.classPlan,
    fidelityPlanFile: files.fidelityPlan,
    colorSystemFile: files.colorSystem,
    fontSystemFile: files.fontSystem,
    iconSystemFile: files.iconSystem,
    bricksMcpFile: files.bricksMcp,
    pluginMcpFile: files.pluginMcp,
    resultFile: files.result,
    payloadFile: files.payload,
    headerPayloadFile: files.headerPayload,
    footerPayloadFile: files.footerPayload,
    globalClassesFile: files.globalClasses,
    baselineResultFile: files.baselineResult,
    baselinePayloadFile: files.baselinePayload,
    baselineHeaderPayloadFile: files.baselineHeaderPayload,
    baselineFooterPayloadFile: files.baselineFooterPayload,
    baselineGlobalClassesFile: files.baselineGlobalClasses,
    baselineReportFile: files.baselineReport,
    qaFile: files.qa,
    deterministicScaffold,
    stageAMedia,
    skills,
    suggestedRunCommand,
  };

  await writeTextFile(path.join(workspaceDir, 'README.md'), renderStageBWorkspaceReadme(result));
  return result;
}

async function runStageBWorkspace(flags) {
  const prepared = await prepareStageBWorkspace(flags);
  const maxRepairAttempts = parseNonNegativeIntegerFlag(
    firstString(flags.repairAttempts, flags.repair_attempts),
    DEFAULT_STAGE_B_REPAIR_ATTEMPTS
  );
  const qualityPolicy = parseStageBQualityPolicy(flags);

  if (shouldUseDeterministicStageB(flags)) {
    const deterministicMode = firstString(prepared?.deterministicScaffold?.mode, 'deterministic_scaffold');
    await normalizeStageBGeneratedArtifacts(prepared);
    const result = {
      ...prepared,
      status: 'bricks_result_ready',
      runnerCommand: deterministicMode === 'pixflow_html_baseline' ? 'pixflow-html-baseline' : 'deterministic-stage-b-scaffold',
      runner: deterministicMode,
      runnerExitCode: 0,
      runnerEventsFile: null,
      runnerStderrFile: null,
      runnerEventSummary: {
        mode: deterministicMode,
        skippedModelRunner: true,
      },
      repairAttempts: [],
      stageBQa: applyStageBQualityGate(await analyzeStageBResult(prepared), qualityPolicy),
    };
    await writeJsonFile(prepared.qaFile, result.stageBQa);
    assertStageBQaPasses(result.stageBQa, qualityPolicy);
    return await maybeImportAndInsertStageB(result, prepared, flags);
  }

  const runnerInvocation = buildStageBRunnerInvocation(prepared, flags);
  runnerInvocation.jsonOutput = Boolean(flags.json);
  const result = {
    ...prepared,
    status: 'running',
    runnerCommand: runnerInvocation.display,
    runner: runnerInvocation.kind,
    runnerExitCode: null,
    runnerEventsFile: runnerInvocation.eventsFile || null,
    runnerStderrFile: runnerInvocation.stderrFile || null,
    runnerEventSummary: null,
    repairAttempts: [],
    stageBQa: null,
  };

  const runnerResult = await runStageBInvocation(runnerInvocation, prepared.workspaceDir);
  result.runnerExitCode = runnerResult.code;
  result.runnerEventSummary = runnerResult.eventSummary;
  result.runnerEventsFile = runnerResult.eventsFile || result.runnerEventsFile;
  result.runnerStderrFile = runnerResult.stderrFile || result.runnerStderrFile;
  await assertStageBResultExists(prepared.resultFile);
  await normalizeStageBGeneratedArtifacts(prepared);
  result.stageBQa = applyStageBQualityGate(await analyzeStageBResult(prepared), qualityPolicy);
  await writeJsonFile(prepared.qaFile, result.stageBQa);

  for (let attempt = 1; stageBQaNeedsRepair(result.stageBQa, qualityPolicy) && attempt <= maxRepairAttempts; attempt += 1) {
    const repairPromptFile = path.join(prepared.workspaceDir, `codex-stage-b-repair-${attempt}.txt`);
    await writeTextFile(repairPromptFile, renderStageBRepairPrompt(prepared, result.stageBQa, attempt, maxRepairAttempts, qualityPolicy));
    const repairInvocation = buildStageBRunnerInvocation(prepared, flags, {
      stdinFile: repairPromptFile,
      eventsFile: path.join(prepared.workspaceDir, `stage-b-codex-repair-${attempt}-events.jsonl`),
      stderrFile: path.join(prepared.workspaceDir, `stage-b-codex-repair-${attempt}-stderr.log`),
    });
    repairInvocation.jsonOutput = Boolean(flags.json);
    const repairResult = await runStageBInvocation(repairInvocation, prepared.workspaceDir);
    result.runnerExitCode = repairResult.code;
    result.runnerCommand = repairInvocation.display;
    result.runnerEventsFile = repairResult.eventsFile || null;
    result.runnerStderrFile = repairResult.stderrFile || null;
    result.runnerEventSummary = mergeStageAEventSummaries(result.runnerEventSummary, repairResult.eventSummary);
    result.repairAttempts.push({
      attempt,
      runnerCommand: repairInvocation.display,
      runnerExitCode: repairResult.code,
      runnerEventsFile: repairResult.eventsFile || null,
      runnerStderrFile: repairResult.stderrFile || null,
      qaBefore: summarizeStageBQa(result.stageBQa),
    });
    await assertStageBResultExists(prepared.resultFile);
    await normalizeStageBGeneratedArtifacts(prepared);
    result.stageBQa = applyStageBQualityGate(await analyzeStageBResult(prepared), qualityPolicy);
    await writeJsonFile(prepared.qaFile, result.stageBQa);
    result.repairAttempts[result.repairAttempts.length - 1].qaAfter = summarizeStageBQa(result.stageBQa);
  }

  assertStageBQaPasses(result.stageBQa, qualityPolicy);
  result.status = 'bricks_result_ready';

  return await maybeImportAndInsertStageB(result, prepared, flags);
}

async function repairStageBWorkspace(flags) {
  const workspaceDir = path.resolve(
    process.cwd(),
    firstString(flags.workspace, flags.workspaceDir, flags.cwd, '.')
  );
  const prepared = buildPreparedStageBFromWorkspace(workspaceDir);
  const maxRepairAttempts = parseNonNegativeIntegerFlag(
    firstString(flags.repairAttempts, flags.repair_attempts),
    DEFAULT_STAGE_B_REPAIR_ATTEMPTS
  );
  const qualityPolicy = parseStageBQualityPolicy(flags);
  const result = {
    ...prepared,
    status: 'repairing',
    runnerCommand: 'repair-stage-b',
    runner: firstString(flags.runner, flags.agent, 'codex'),
    runnerExitCode: null,
    runnerEventsFile: null,
    runnerStderrFile: null,
    runnerEventSummary: null,
    repairAttempts: [],
    stageBQa: null,
  };

  await assertStageBResultExists(prepared.resultFile);
  await normalizeStageBGeneratedArtifacts(prepared);
  result.stageBQa = applyStageBQualityGate(await analyzeStageBResult(prepared), qualityPolicy);
  await writeJsonFile(prepared.qaFile, result.stageBQa);

  for (let attempt = 1; stageBQaNeedsRepair(result.stageBQa, qualityPolicy) && attempt <= maxRepairAttempts; attempt += 1) {
    const repairPromptFile = path.join(prepared.workspaceDir, `codex-stage-b-repair-${attempt}.txt`);
    await writeTextFile(repairPromptFile, renderStageBRepairPrompt(prepared, result.stageBQa, attempt, maxRepairAttempts, qualityPolicy));
    const repairInvocation = buildStageBRunnerInvocation(prepared, flags, {
      stdinFile: repairPromptFile,
      eventsFile: path.join(prepared.workspaceDir, `stage-b-codex-repair-${attempt}-events.jsonl`),
      stderrFile: path.join(prepared.workspaceDir, `stage-b-codex-repair-${attempt}-stderr.log`),
    });
    repairInvocation.jsonOutput = Boolean(flags.json);
    const repairResult = await runStageBInvocation(repairInvocation, prepared.workspaceDir);
    result.runnerExitCode = repairResult.code;
    result.runnerCommand = repairInvocation.display;
    result.runnerEventsFile = repairResult.eventsFile || null;
    result.runnerStderrFile = repairResult.stderrFile || null;
    result.runnerEventSummary = mergeStageAEventSummaries(result.runnerEventSummary, repairResult.eventSummary);
    result.repairAttempts.push({
      attempt,
      runnerCommand: repairInvocation.display,
      runnerExitCode: repairResult.code,
      runnerEventsFile: repairResult.eventsFile || null,
      runnerStderrFile: repairResult.stderrFile || null,
      qaBefore: summarizeStageBQa(result.stageBQa),
    });
    await assertStageBResultExists(prepared.resultFile);
    await normalizeStageBGeneratedArtifacts(prepared);
    result.stageBQa = applyStageBQualityGate(await analyzeStageBResult(prepared), qualityPolicy);
    await writeJsonFile(prepared.qaFile, result.stageBQa);
    result.repairAttempts[result.repairAttempts.length - 1].qaAfter = summarizeStageBQa(result.stageBQa);
  }

  assertStageBQaPasses(result.stageBQa, qualityPolicy);
  result.status = 'bricks_result_ready';
  return result;
}

function shouldUseDeterministicStageB(flags) {
  const runner = firstString(flags.runner, flags.stageBRunner, flags.stage_b_runner);
  return flags.deterministic === true
    || flags.deterministic === 'true'
    || flags.skipRunner === true
    || flags.skipRunner === 'true'
    || flags.skip_runner === true
    || flags.skip_runner === 'true'
    || runner === 'none'
    || runner === 'deterministic';
}

async function maybeImportAndInsertStageB(result, prepared, flags) {
  if (flags.import === true || flags.import === 'true' || flags.insert === true || flags.insert === 'true') {
    const config = await loadConfig(flags);
    const client = createPixflowClient(config);
    const importPayload = await buildStageBImportPayload({
      ...flags,
      resultFile: prepared.resultFile,
      qaFile: prepared.qaFile,
      conversionReportFile: path.join(prepared.workspaceDir, 'conversion-report.md'),
      metadataFile: prepared.metadataFile,
      title: firstString(flags.title, flags.pageTitle, prepared.title),
      sourceId: prepared.sourceId,
    });
    result.imported = await client.post('/cli-bridge/stage-b/import-result', importPayload);
    result.status = 'imported';

    if (flags.insert === true || flags.insert === 'true') {
      const insertPayload = await buildStageBInsertPayload({
        ...flags,
        resultFile: prepared.resultFile,
        qaFile: prepared.qaFile,
        conversionReportFile: path.join(prepared.workspaceDir, 'conversion-report.md'),
        metadataFile: prepared.metadataFile,
        title: firstString(flags.title, flags.pageTitle, prepared.title),
      });
      result.inserted = await client.post('/cli-bridge/stage-b/insert-page', insertPayload);
      result.status = 'inserted';
    }
  }

  return result;
}

function buildPreparedStageBFromWorkspace(workspaceDir) {
  return {
    status: 'prepared',
    workspaceDir,
    sourceId: path.basename(workspaceDir),
    title: path.basename(workspaceDir),
    runnerPromptFile: path.join(workspaceDir, 'codex-stage-b-prompt.txt'),
    routeContractFile: path.join(workspaceDir, 'stage-b-route-contract.json'),
    themeStyleContractFile: path.join(workspaceDir, 'stage-b-theme-style-contract.json'),
    themeStyleHealthFile: path.join(workspaceDir, 'stage-b-theme-style-health.json'),
    fontSystemFile: path.join(workspaceDir, 'stage-b-font-system.json'),
    iconSystemFile: path.join(workspaceDir, 'stage-b-icon-system.json'),
    headerPlanFile: path.join(workspaceDir, 'stage-b-header-plan.json'),
    footerPlanFile: path.join(workspaceDir, 'stage-b-footer-plan.json'),
    resultFile: path.join(workspaceDir, 'bricks-result.json'),
    payloadFile: path.join(workspaceDir, 'bricks-payload.json'),
    headerPayloadFile: path.join(workspaceDir, 'bricks-header-payload.json'),
    footerPayloadFile: path.join(workspaceDir, 'bricks-footer-payload.json'),
    globalClassesFile: path.join(workspaceDir, 'global-classes.json'),
    qaFile: path.join(workspaceDir, 'stage-b-qa.json'),
  };
}

function buildStageBRunnerInvocation(prepared, flags, overrides = {}) {
  const customCommand = firstString(flags.runnerCommand);
  if (customCommand) {
    const command = customCommand
      .replace(/\{workspace\}/g, prepared.workspaceDir)
      .replace(/\{prompt\}/g, prepared.runnerPromptFile)
      .replace(/\{artifact\}/g, prepared.resultFile)
      .replace(/\{result\}/g, prepared.resultFile);
    return {
      kind: 'custom_shell',
      display: command,
      command,
      shell: true,
      stdin: null,
      eventsFile: overrides.eventsFile || path.join(prepared.workspaceDir, 'stage-b-runner-events.log'),
      stderrFile: overrides.stderrFile || path.join(prepared.workspaceDir, 'stage-b-runner-stderr.log'),
    };
  }

  return buildBridgeStageRunnerInvocation('stage-b', prepared, flags, overrides);
}

async function runStageBInvocation(invocation, cwd) {
  return runLocalInvocation(invocation, cwd, 'Stage B');
}

function buildStageBContext(stageAWorkspace, stageAArtifact, stageAMetadata, contracts = {}) {
  return {
    type: 'pixflow_design_cli_stage_b_context',
    stage: 'stage_b',
    stageA: {
      workspaceDir: stageAWorkspace,
      artifactFile: stageAArtifact,
      promptFile: path.join(stageAWorkspace, 'prompt.md'),
      briefFile: path.join(stageAWorkspace, 'brief.md'),
      compositionDnaFile: path.join(stageAWorkspace, 'composition-dna.md'),
      selfCritiqueFile: path.join(stageAWorkspace, 'stage-a-self-critique.md'),
      qaFile: path.join(stageAWorkspace, 'stage-a-qa.json'),
      metadata: summarizeStageAMetadataForStageB(stageAMetadata || {}),
    },
    output: {
      resultFile: 'bricks-result.json',
      payloadFile: 'bricks-payload.json',
      headerPayloadFile: 'bricks-header-payload.json',
      footerPayloadFile: 'bricks-footer-payload.json',
      globalClassesFile: 'global-classes.json',
      reportFile: 'conversion-report.md',
      routeContractFile: 'stage-b-route-contract.json',
      themeStyleContractFile: 'stage-b-theme-style-contract.json',
      themeStyleHealthFile: 'stage-b-theme-style-health.json',
      fontSystemFile: 'stage-b-font-system.json',
      iconSystemFile: 'stage-b-icon-system.json',
    },
    routeContract: summarizeStageBRouteContract(contracts.routeContract || {}),
    themeStyleContract: summarizeStageBThemeStyleContract(contracts.themeStyleContract || {}),
    themeStyleHealth: summarizeStageBThemeStyleHealth(contracts.themeStyleHealth || {}),
    fontSystem: summarizeStageBFontSystem(contracts.fontSystem || {}),
    iconSystem: summarizeStageBIconSystem(contracts.iconSystem || {}),
    resourceBoundary: {
      stageAPixflowDesignSkills: 'read_only_source_evidence',
      stageBBricksSkills: 'active',
      pixflowBricksMcp: 'active',
      pixflowPluginMcp: 'active',
      finalTarget: 'editable_bricks_json',
    },
  };
}

function summarizeStageAMetadataForStageB(metadata) {
  const selectedPrototype = firstPlainObject(metadata?.selectedPrototype, metadata?.selected_prototype);
  const selectedSystem = firstPlainObject(
    metadata?.selectedPixflowDesignSystem,
    metadata?.selected_pixflow_design_system,
    metadata?.pixflowDesignSystem,
    metadata?.pixflow_design_system
  );
  const target = firstPlainObject(metadata?.target);

  return {
    title: firstString(metadata?.title, target?.title, target?.pageTitle),
    sourceId: firstString(metadata?.sourceId, metadata?.source_id),
    fidelity: firstString(metadata?.fidelity),
    selectedPrototype: pickObjectKeys(selectedPrototype, ['id', 'source', 'title', 'category', 'surface', 'official']),
    selectedPixflowDesignSystem: pickObjectKeys(selectedSystem, ['key', 'id', 'label', 'title', 'packId', 'packVersion']),
    target: pickObjectKeys(target, ['title', 'pageTitle', 'postType']),
  };
}

async function resolveStageBBridgeStatus(flags) {
  const explicitStatusFile = firstString(flags.bridgeStatusFile, flags.styleStatusFile, flags.themeStyleStateFile);
  if (explicitStatusFile) {
    const status = await readOptionalJson(explicitStatusFile);
    return Object.keys(status).length > 0
      ? {
        type: 'pixflow_stage_b_bridge_status',
        source: 'file',
        file: path.resolve(process.cwd(), explicitStatusFile),
        available: true,
        status,
      }
      : {
        type: 'pixflow_stage_b_bridge_status',
        source: 'file',
        file: path.resolve(process.cwd(), explicitStatusFile),
        available: false,
        reason: 'file_missing_or_invalid',
      };
  }

  if (flags.skipStatusPreflight === true || flags.skipStatusPreflight === 'true') {
    return {
      type: 'pixflow_stage_b_bridge_status',
      source: 'skipped',
      available: false,
      reason: 'skip_status_preflight_flag',
    };
  }

  const hasRemoteHint = Boolean(
    firstString(flags.config, flags.site, flags.siteUrl, process.env.PIXFLOW_SITE_URL)
    || firstString(process.env.PIXFLOW_CLI_TOKEN, process.env.PIXFLOW_EDITOR_TOKEN)
  );
  if (!hasRemoteHint) {
    return {
      type: 'pixflow_stage_b_bridge_status',
      source: 'offline',
      available: false,
      reason: 'no_remote_config_supplied',
    };
  }

  try {
    const config = await loadConfig(flags);
    const client = createPixflowClient(config);
    const status = await client.post('/cli-bridge/status', {});
    return {
      type: 'pixflow_stage_b_bridge_status',
      source: 'cli_bridge_status',
      available: true,
      status,
    };
  } catch (error) {
    return {
      type: 'pixflow_stage_b_bridge_status',
      source: 'cli_bridge_status',
      available: false,
      reason: 'status_request_failed',
      message: error instanceof Error ? error.message : String(error),
    };
  }
}

async function readPixflowFrameworkVariableInventory() {
  const filePath = path.join(process.cwd(), 'assets', 'framework-bootstrap', 'bricks', 'bricks-variables.json');
  const payload = await readOptionalJson(filePath);
  const variables = Array.isArray(payload.variables) ? payload.variables : [];
  const categories = Array.isArray(payload.categories) ? payload.categories : [];
  return {
    type: 'pixflow_framework_variable_inventory',
    sourceFile: 'assets/framework-bootstrap/bricks/bricks-variables.json',
    variableCount: variables.length,
    categoryCount: categories.length,
    variables: variables
      .filter((variable) => variable && typeof variable === 'object' && firstString(variable.name))
      .map((variable) => ({
        id: firstString(variable.id),
        name: firstString(variable.name),
        cssName: `--${firstString(variable.name).replace(/^--/, '')}`,
        value: firstString(variable.value),
        category: firstString(variable.category),
      })),
    categories: categories
      .filter((category) => category && typeof category === 'object' && firstString(category.id, category.name))
      .map((category) => ({
        id: firstString(category.id),
        name: firstString(category.name),
      })),
  };
}

function buildStageBRouteContract({ flags, stageAMetadata, bridgeStatus, colorSystem, pixflowVariableInventory }) {
  const styleStatus = extractStageBStyleStatus(bridgeStatus);
  const styleContext = objectValue(styleStatus.styleContext);
  const routeId = firstString(
    flags.routeId,
    flags.route,
    flags.frameworkRoute,
    styleStatus.activeRouteId,
    styleContext.active_route_id,
    stageAMetadata?.style_context?.direct_style_context?.active_route_id,
    'pixflow-native-bricks'
  );
  const routeLabel = firstString(
    flags.routeLabel,
    styleStatus.routeLabel,
    styleContext.route_label,
    stageBRouteLabel(routeId)
  );
  const pixflowFrameworkRoute = isStageBPixflowFrameworkRoute(routeId);
  const detectedMode = firstString(flags.styleMode, styleStatus.mode, styleContext.mode);
  const styleMode = normalizeStageBStyleMode(detectedMode, routeId);
  const directTokenInventory = extractStageBTokenInventory(styleContext);
  const pixflowVariables = Array.isArray(pixflowVariableInventory?.variables)
    ? pixflowVariableInventory.variables
    : [];

  return {
    type: 'pixflow_stage_b_route_contract',
    version: 1,
    generatedAt: new Date().toISOString(),
    routeId,
    routeLabel,
    routeFamily: pixflowFrameworkRoute ? 'pixflow_framework' : 'direct',
    styleMode,
    inference: {
      source: firstString(flags.routeId, flags.route, flags.frameworkRoute)
        ? 'cli_flag'
        : (styleStatus.available ? 'remote_bridge_status' : 'default_pixflow_framework'),
      confidence: firstString(flags.routeId, flags.route, flags.frameworkRoute) || styleStatus.available ? 'high' : 'low',
      remoteStatusAvailable: Boolean(styleStatus.available),
      remoteStatusReason: firstString(bridgeStatus?.reason),
    },
    bricksColorScheme: {
      mustEmitBricksColorScheme: true,
      sourceRef: 'stage-b-color-system.json',
      systemKey: firstString(colorSystem?.systemKey),
      systemName: firstString(colorSystem?.systemName, colorSystem?.title),
      paletteId: firstString(colorSystem?.palette?.id),
      paletteMustUseLiteralColors: true,
    },
    variableAuthority: buildStageBVariableAuthority({
      routeId,
      styleMode,
      pixflowFrameworkRoute,
      pixflowVariables,
      directTokenInventory,
    }),
    globalClassPolicy: {
      mayCreateGlobalClasses: true,
      mustUseClassIdsInElements: true,
      mustReuseExistingClassIds: styleMode === 'token_inventory',
      classNameStyle: 'short_bem',
    },
    policies: {
      mustEmitBricksColorScheme: true,
      paletteMustUseLiteralColors: true,
      mayCreatePixflowSemanticVariables: pixflowFrameworkRoute,
      mayCreateRouteVariables: pixflowFrameworkRoute || styleMode === 'token_inventory',
      mayUseRawFallbackValues: !pixflowFrameworkRoute || styleMode === 'vanilla',
      mayCreateGlobalClasses: true,
      routeRewriteRequired: ['pixflow-core', 'pixflow-at', 'direct-core', 'direct-at', 'direct-acss'].includes(routeId),
      themeStyleContractRequired: true,
    },
    forbiddenOutput: [
      '.od-root',
      'all-section token wrapper class',
      '--od-* tokens',
      'Bricks palette raw values that are var(...) references',
      'copied Bricks metadata: source, sourceUrl, version',
      pixflowFrameworkRoute ? '' : 'Pixflow Framework scheme variables/classes unless detected in inventory',
    ].filter(Boolean),
    references: {
      routeContract: 'stage-b-route-contract.json',
      themeStyleContract: 'stage-b-theme-style-contract.json',
      themeStyleHealth: 'stage-b-theme-style-health.json',
      colorSystem: 'stage-b-color-system.json',
    },
  };
}

function buildStageBVariableAuthority({ routeId, styleMode, pixflowFrameworkRoute, pixflowVariables, directTokenInventory }) {
  if (pixflowFrameworkRoute) {
    return {
      mode: 'pixflow_framework_variables',
      routeId,
      source: 'assets/framework-bootstrap/bricks/bricks-variables.json',
      allowedVariableNames: pixflowVariables.map((variable) => variable.name),
      allowedCssVariables: pixflowVariables.map((variable) => variable.cssName),
      allowedFamilies: [
        'site_layout',
        'spacing',
        'typography',
        'grid',
        'radius',
        'border',
        'shadow',
        'transition',
        'motion',
      ],
      modelRules: [
        'Use Pixflow Framework variables for systemic layout, spacing, typography, grid, radius, border, shadow, and motion roles.',
        'Do not invent route variables outside this inventory during first-pass Stage B.',
        'Use Bricks element/class settings for one-off aspect ratios, object fit, z-index, transforms, clip paths, filters, and decorative exceptions.',
      ],
    };
  }

  if (styleMode === 'token_inventory') {
    return {
      mode: 'detected_token_inventory',
      routeId,
      source: 'remote_bricks_token_inventory',
      allowedVariableNames: directTokenInventory.variableNames,
      allowedCssVariables: directTokenInventory.cssVariables,
      allowedClassIds: directTokenInventory.globalClassIds,
      modelRules: [
        'Use only detected route variables/classes from inventory.',
        'Do not create Pixflow Framework variables or scheme classes on direct routes.',
        'Fall back to explicit Bricks settings when no suitable route token exists.',
      ],
    };
  }

  return {
    mode: 'explicit_bricks_settings',
    routeId,
    source: 'vanilla_or_unknown_route',
    allowedVariableNames: [],
    allowedCssVariables: [],
    allowedClassIds: [],
    modelRules: [
      'Use explicit Bricks settings and generated page-scoped global classes.',
      'Do not invent framework variables or utility classes.',
      'Use literal colors from the accepted Bricks color scheme where variables are not available.',
    ],
  };
}

function buildStageBThemeStyleHealth(bridgeStatus, routeContract, flags = {}) {
  const styleStatus = extractStageBStyleStatus(bridgeStatus);
  const themeStyles = extractStageBThemeStyles(styleStatus);
  const activeIds = stringArrayFromUnknown(styleStatus.themeStyleActiveIds);
  const targetStyle = selectStageBThemeStyle(themeStyles, activeIds);
  const essentials = inspectStageBThemeStyleEssentials(targetStyle?.settings || {});
  const missingEssentials = Object.entries(essentials)
    .filter(([, present]) => !present)
    .map(([key]) => key);
  const presentCount = Object.values(essentials).filter(Boolean).length;
  const totalCount = Object.keys(essentials).length;
  const routeFamily = firstString(routeContract?.routeFamily);
  const conditionConfidence = targetStyle
    ? (targetStyle.activeGlobal ? 'global' : 'unknown')
    : (styleStatus.available ? 'none' : 'unavailable');
  const appliesToTarget = targetStyle?.activeGlobal === true
    ? true
    : (targetStyle ? 'unknown' : false);
  const available = Boolean(styleStatus.available);
  const status = !available
    ? 'unknown'
    : (!targetStyle
      ? 'bad'
      : (appliesToTarget !== true
        ? 'unknown'
        : (presentCount >= 8 ? 'good' : (presentCount >= 5 ? 'partial' : 'bad'))));
  const safeToLeanOnThemeStyles = status === 'good' && appliesToTarget === true;
  const recommendedAction = safeToLeanOnThemeStyles
    ? 'lean_on_theme_styles'
    : (routeFamily === 'pixflow_framework'
      ? 'use_explicit_stage_b_fallback_until_pixflow_theme_style_is_confirmed'
      : (status === 'partial' ? 'ask_improve_theme_style_or_use_page_fallback' : 'ask_create_theme_style_or_use_page_fallback'));

  return {
    type: 'pixflow_stage_b_theme_style_health',
    version: 1,
    generatedAt: new Date().toISOString(),
    routeId: firstString(routeContract?.routeId),
    routeFamily,
    status,
    source: firstString(styleStatus.source, bridgeStatus?.source, 'unknown'),
    remoteStatusAvailable: available,
    activeThemeStyleIds: activeIds,
    selectedThemeStyleId: firstString(targetStyle?.id),
    selectedThemeStyleLabel: firstString(targetStyle?.label),
    detectedScopes: targetStyle ? [targetStyle.activeGlobal ? 'sitewide' : 'unknown_or_condition_scoped'] : [],
    appliesToTarget,
    conditionConfidence,
    safeToLeanOnThemeStyles,
    essentials,
    presentEssentialCount: presentCount,
    totalEssentialCount: totalCount,
    missingEssentials,
    riskyEssentials: [],
    recommendedAction,
    userQuestions: buildStageBThemeStyleUserQuestions(routeFamily, status, safeToLeanOnThemeStyles, flags),
    explanation: buildStageBThemeStyleHealthExplanation(status, routeFamily, missingEssentials, available),
  };
}

function buildStageBThemeStyleContract(routeContract, health, bridgeStatus, flags = {}) {
  const safeToLeanOnThemeStyles = health.safeToLeanOnThemeStyles === true;
  const ownedDefaults = {
    sectionPadding: safeToLeanOnThemeStyles && Boolean(health.essentials?.sectionPadding),
    containerWidth: safeToLeanOnThemeStyles && Boolean(health.essentials?.containerWidth),
    containerPadding: safeToLeanOnThemeStyles && Boolean(health.essentials?.containerPadding),
    containerRowGap: safeToLeanOnThemeStyles && Boolean(health.essentials?.containerRowGap),
    bodyTypography: safeToLeanOnThemeStyles && Boolean(health.essentials?.bodyTypography),
    headingTypography: safeToLeanOnThemeStyles && Boolean(health.essentials?.headingTypography),
    buttonDefaults: safeToLeanOnThemeStyles && Boolean(health.essentials?.buttonBaseline),
    formDefaults: safeToLeanOnThemeStyles && Boolean(health.essentials?.formBaseline),
    dividerDefaults: safeToLeanOnThemeStyles && Boolean(health.essentials?.dividerBaseline),
    siteBackground: safeToLeanOnThemeStyles && Boolean(health.essentials?.siteBackground),
  };
  const mustEmitExplicit = Object.entries(ownedDefaults)
    .filter(([, owned]) => !owned)
    .map(([key]) => key);

  return {
    type: 'pixflow_stage_b_theme_style_contract',
    version: 1,
    generatedAt: new Date().toISOString(),
    routeId: firstString(routeContract?.routeId),
    routeFamily: firstString(routeContract?.routeFamily),
    mode: safeToLeanOnThemeStyles ? 'theme_style_defaults_available' : 'explicit_page_scoped_fallback_required',
    source: health.source,
    activeThemeStyleIds: health.activeThemeStyleIds || [],
    selectedThemeStyleId: firstString(health.selectedThemeStyleId),
    pixflowThemeStyleActive: firstString(routeContract?.routeFamily) === 'pixflow_framework' && safeToLeanOnThemeStyles,
    appliesToTarget: health.appliesToTarget,
    conditionConfidence: health.conditionConfidence,
    safeToLeanOnThemeStyles,
    ownedDefaults,
    mustEmitExplicit,
    mutationPolicy: {
      mayCreateOrMutateThemeStyles: false,
      requiresUserApproval: true,
      approvedByFlags: false,
      currentPageOnlyConditionVerified: false,
      notes: [
        'Do not create or mutate Bricks theme styles during first-pass Stage B unless a future explicit approval flow records scope.',
        'When theme style confidence is low, emit page-scoped Bricks settings/global classes instead.',
      ],
    },
    questionFlow: health.userQuestions || [],
    healthRef: 'stage-b-theme-style-health.json',
    bridgeStatusAvailable: Boolean(bridgeStatus?.available),
  };
}

function extractStageBStyleStatus(bridgeStatus) {
  const status = objectValue(bridgeStatus?.status);
  const style = objectValue(status.style || bridgeStatus?.style || status);
  return {
    available: bridgeStatus?.available === true && (style.available !== false),
    source: firstString(bridgeStatus?.source),
    styleContext: objectValue(style.styleContext || style.direct_style_context || status.styleContext),
    activeRouteId: firstString(style.activeRouteId, style.active_route_id, style.styleContext?.active_route_id),
    routeLabel: firstString(style.routeLabel, style.route_label, style.styleContext?.route_label),
    mode: firstString(style.mode, style.styleContext?.mode),
    themeStyles: objectValue(style.themeStyles || style.theme_styles),
    themeStyleActiveIds: style.themeStyleActiveIds || style.theme_style_active_ids || [],
    themeStyleActiveId: firstString(style.themeStyleActiveId, style.theme_style_active_id),
  };
}

function extractStageBThemeStyles(styleStatus) {
  const styles = objectValue(styleStatus.themeStyles);
  return Object.entries(styles)
    .filter(([, style]) => style && typeof style === 'object' && !Array.isArray(style))
    .map(([id, style]) => ({
      id: firstString(style.id, id),
      label: firstString(style.label, id),
      activeGlobal: style.activeGlobal === true || hasStageBGlobalThemeStyleCondition(style.conditions),
      conditions: Array.isArray(style.conditions) ? style.conditions : [],
      settings: objectValue(style.settings),
    }));
}

function selectStageBThemeStyle(themeStyles, activeIds) {
  if (!Array.isArray(themeStyles) || themeStyles.length === 0) {
    return null;
  }
  for (const id of activeIds) {
    const match = themeStyles.find((style) => style.id === id);
    if (match) return match;
  }
  return themeStyles.find((style) => style.activeGlobal) || themeStyles[0] || null;
}

function inspectStageBThemeStyleEssentials(settings) {
  const typography = objectValue(settings.typography);
  const section = objectValue(settings.section);
  const container = objectValue(settings.container);
  const general = objectValue(settings.general);
  const button = objectValue(settings.button);
  const form = objectValue(settings.form);
  const divider = objectValue(settings.divider);
  const bodyTypography = objectValue(typography.typographyBody || typography.body);
  const headingTypography = objectValue(typography.typographyHeadings || typography.heading || typography.typographyHeadingH1);
  const sectionPadding = objectValue(section.padding);
  const containerPadding = objectValue(container.padding);
  const mobilePadding = objectValue(container['padding:mobile_portrait'] || container['padding:tablet_portrait']);

  return {
    bodyTypography: Boolean(firstString(bodyTypography['font-size'], bodyTypography['font-family'], bodyTypography.color?.raw, bodyTypography.color?.hex)),
    headingTypography: Boolean(firstString(headingTypography['font-size'], headingTypography['font-family'], headingTypography.color?.raw, headingTypography.color?.hex)),
    siteBackground: Boolean(firstString(general.siteBackground?.color?.raw, general.siteBackground?.color?.hex, general.siteBackground?.color)),
    sectionPadding: Boolean(firstString(sectionPadding.top, sectionPadding.bottom)),
    containerWidth: Boolean(firstString(container.widthMax, container._widthMax, container._maxWidth, container.width)),
    containerPadding: Boolean(firstString(containerPadding.left, containerPadding.right)),
    containerRowGap: Boolean(firstString(container._rowGap, container.rowGap)),
    mobileGutters: Boolean(firstString(mobilePadding.left, mobilePadding.right)),
    buttonBaseline: Boolean(firstString(button.sizeDefaultPadding?.top, button.typography?.['font-size'], button.border?.radius?.top, button.border?.radius)),
    formBaseline: Boolean(firstString(form.fieldPadding?.top, form.fieldBorder?.style, form.fieldTypography?.color?.raw, form.fieldBackgroundColor?.raw)),
    dividerBaseline: Boolean(firstString(divider.color?.raw, divider.height)),
  };
}

function buildStageBThemeStyleUserQuestions(routeFamily, status, safeToLeanOnThemeStyles, flags = {}) {
  if (routeFamily === 'pixflow_framework' || safeToLeanOnThemeStyles) {
    return [];
  }
  if (!['partial', 'bad', 'unknown'].includes(status)) {
    return [];
  }
  return [
    {
      id: 'create_theme_style_baseline',
      question: 'Your Bricks theme style is missing important defaults. Create a Pixflow baseline Bricks theme style?',
      choices: ['yes', 'no'],
      default: firstString(flags.createThemeStyleBaseline, ''),
      stage: 'stage_b_preflight',
    },
    {
      id: 'theme_style_scope',
      question: 'If created, should the theme style apply site-wide or only to this new page?',
      choices: ['sitewide', 'current_page'],
      default: firstString(flags.themeStyleScope, 'current_page'),
      stage: 'stage_b_preflight',
      requires: 'create_theme_style_baseline=yes',
    },
  ];
}

function buildStageBThemeStyleHealthExplanation(status, routeFamily, missingEssentials, available) {
  if (!available) {
    return 'No remote Bricks theme-style state was available, so Stage B must assume theme defaults may be missing.';
  }
  if (status === 'good') {
    return 'The active Bricks theme style has the essential defaults needed for Stage B to lean on it.';
  }
  const missing = missingEssentials.length > 0 ? missingEssentials.join(', ') : 'condition confidence';
  if (routeFamily === 'pixflow_framework') {
    return `Pixflow Framework route was detected, but the active theme-style contract is not fully confirmed. Missing or uncertain: ${missing}.`;
  }
  return `The active Bricks theme style is not a complete beginner-safe baseline. Missing or uncertain: ${missing}.`;
}

function extractStageBTokenInventory(styleContext) {
  const inventory = objectValue(styleContext.token_inventory);
  const variables = Array.isArray(inventory.variables) ? inventory.variables : [];
  const globalClasses = Array.isArray(inventory.global_classes) ? inventory.global_classes : [];
  return {
    variableNames: variables.map((variable) => firstString(variable.name)).filter(Boolean),
    cssVariables: variables.map((variable) => `--${firstString(variable.name).replace(/^--/, '')}`).filter((name) => name !== '--'),
    globalClassIds: globalClasses.map((item) => firstString(item.id)).filter(Boolean),
  };
}

function hasStageBGlobalThemeStyleCondition(conditions) {
  if (!Array.isArray(conditions)) {
    return false;
  }
  return conditions.some((condition) => (
    condition
    && typeof condition === 'object'
    && condition.main === 'any'
    && !condition.exclude
  ));
}

function normalizeStageBStyleMode(mode, routeId) {
  const normalized = firstString(mode).trim().toLowerCase();
  if (['pixflow_framework', 'token_inventory', 'vanilla'].includes(normalized)) {
    return normalized;
  }
  if (isStageBPixflowFrameworkRoute(routeId)) {
    return 'pixflow_framework';
  }
  return 'vanilla';
}

function isStageBPixflowFrameworkRoute(routeId) {
  return ['pixflow-native-bricks', 'pixflow-core', 'pixflow-at'].includes(firstString(routeId));
}

function stageBRouteLabel(routeId) {
  const labels = {
    'pixflow-native-bricks': 'Pixflow Framework via Native Bricks',
    'pixflow-core': 'Pixflow Framework via Core Framework',
    'pixflow-at': 'Pixflow Framework via Advanced Themer',
    'direct-bricks': 'Direct Native Bricks',
    'direct-core': 'Direct Core Framework',
    'direct-at': 'Direct Advanced Themer',
    'direct-acss': 'Direct ACSS',
  };
  return labels[firstString(routeId)] || firstString(routeId, 'Pixflow Framework via Native Bricks');
}

function summarizeStageBRouteContract(contract) {
  return {
    routeId: firstString(contract?.routeId),
    routeLabel: firstString(contract?.routeLabel),
    routeFamily: firstString(contract?.routeFamily),
    styleMode: firstString(contract?.styleMode),
    inference: contract?.inference || {},
    variableAuthorityMode: firstString(contract?.variableAuthority?.mode),
    variableCount: Array.isArray(contract?.variableAuthority?.allowedVariableNames)
      ? contract.variableAuthority.allowedVariableNames.length
      : 0,
    themeStyleContractRef: firstString(contract?.references?.themeStyleContract, 'stage-b-theme-style-contract.json'),
  };
}

function summarizeStageBThemeStyleContract(contract) {
  return {
    mode: firstString(contract?.mode),
    routeFamily: firstString(contract?.routeFamily),
    selectedThemeStyleId: firstString(contract?.selectedThemeStyleId),
    safeToLeanOnThemeStyles: contract?.safeToLeanOnThemeStyles === true,
    mustEmitExplicit: Array.isArray(contract?.mustEmitExplicit) ? contract.mustEmitExplicit : [],
    healthRef: firstString(contract?.healthRef, 'stage-b-theme-style-health.json'),
  };
}

function summarizeStageBThemeStyleHealth(health) {
  return {
    status: firstString(health?.status),
    safeToLeanOnThemeStyles: health?.safeToLeanOnThemeStyles === true,
    selectedThemeStyleId: firstString(health?.selectedThemeStyleId),
    missingEssentials: Array.isArray(health?.missingEssentials) ? health.missingEssentials : [],
    recommendedAction: firstString(health?.recommendedAction),
  };
}

function summarizeStageBFontSystem(fontSystem) {
  const fonts = Array.isArray(fontSystem?.fonts) ? fontSystem.fonts : [];
  return {
    type: firstString(fontSystem?.type),
    installStrategy: firstString(fontSystem?.installStrategy),
    fontCount: fonts.length,
    googleFontCount: fonts.filter((font) => firstString(font?.provider) === 'google_fonts').length,
    families: fonts.map((font) => ({
      family: firstString(font?.family),
      familyId: firstString(font?.familyId),
      roles: Array.isArray(font?.roles) ? font.roles : [],
      variableVariants: Array.isArray(font?.variableVariants) ? font.variableVariants : [],
      staticVariants: Array.isArray(font?.staticVariants) ? font.staticVariants : [],
    })),
  };
}

function summarizeStageBIconSystem(iconSystem) {
  const iconSets = Array.isArray(iconSystem?.iconSets) ? iconSystem.iconSets : [];
  const icons = Array.isArray(iconSystem?.icons)
    ? iconSystem.icons
    : iconSets.flatMap((set) => Array.isArray(set?.icons)
      ? set.icons.map((icon) => ({ ...icon, setId: firstString(set?.setId) }))
      : []);
  return {
    type: firstString(iconSystem?.type),
    installStrategy: firstString(iconSystem?.installStrategy),
    defaultSetId: firstString(iconSystem?.defaultSetId),
    iconSetCount: iconSets.length,
    iconCount: icons.length,
    iconIds: icons.map((icon) => firstString(icon?.id)).filter(Boolean).slice(0, 24),
  };
}

function pickObjectKeys(source, keys) {
  const result = {};
  if (!source || typeof source !== 'object' || Array.isArray(source)) {
    return result;
  }
  for (const key of keys) {
    if (source[key] !== undefined && source[key] !== null && source[key] !== '') {
      result[key] = source[key];
    }
  }
  return result;
}

async function buildStageBSourceMap(stageAWorkspace, stageAArtifact, stageAMetadata) {
  const html = await readTextFile(stageAArtifact, 'Stage A artifact');
  const assetsDir = path.join(stageAWorkspace, 'drafts', 'assets');
  const assetFiles = await listStageBAssetFiles(assetsDir);
  const sections = extractStageBSectionsFromHtml(html);
  const imageRefs = extractStageBImageRefs(html);
  const cssText = extractStageBStyleText(html);
  const visibleText = normalizeWhitespace(stripHtmlTags(stripStageBIgnoredHtml(html)));
  const dataAttributeElements = extractStageBDataAttributeElements(html);

  return {
    type: 'pixflow_stage_b_source_map',
    version: 1,
    generatedAt: new Date().toISOString(),
    source: {
      stageAWorkspace,
      artifactFile: stageAArtifact,
      title: firstString(stageAMetadata?.title, 'Pixflow Design Landing'),
      sourceId: firstString(stageAMetadata?.sourceId, stageAMetadata?.source_id, 'pixflow-design-landing'),
    },
    document: {
      title: extractFirstHtmlText(html, /<title\b[^>]*>([\s\S]*?)<\/title>/i),
      htmlLength: html.length,
      visibleTextLength: visibleText.length,
      visibleWordCount: countStageBWords(visibleText),
      sectionCount: sections.length,
      headingCount: countMatches(html, /<h[1-6]\b/gi),
      imageCount: imageRefs.length,
      linkCount: countMatches(html, /<a\b/gi),
      buttonCount: countMatches(html, /<button\b/gi),
      scriptCount: countMatches(html, /<script\b/gi),
      styleBlockCount: countMatches(html, /<style\b/gi),
      dataOdIdCount: countMatches(html, /\bdata-od-id\s*=/gi),
      dataAttributeElementCount: dataAttributeElements.length,
      bodyClass: extractStageBBodyClass(html),
    },
    styles: {
      cssText,
      cssTextLength: cssText.length,
      cssTextHash: cssText ? createHash('sha256').update(cssText).digest('hex') : '',
      mediaQueryCount: countMatches(cssText, /@media\b/gi),
      pseudoElementCount: countMatches(cssText, /::(?:before|after)\b/gi),
      cssVariableDeclarationCount: extractCssVariableDeclarations(cssText).length,
    },
    sections,
    assets: assetFiles,
    images: imageRefs,
    classUsage: extractStageBClassUsage(html),
    dataOdIds: extractStageBDataOdIds(html),
    dataAttributeElements,
    scripts: extractStageBScripts(html),
  };
}

function buildStageBStyleMap(sourceMap, stageBColorSystem = {}) {
  const cssText = firstString(sourceMap?.styles?.cssText);
  const rules = extractStageBCssRuleSummaries(cssText);
  const customProperties = extractCssVariableDeclarations(cssText);
  const pseudoSelectors = uniqueStrings(
    rules
      .map((rule) => rule.selector)
      .filter((selector) => /::(?:before|after)\b/i.test(selector))
  );
  const mediaQueries = extractStageBMediaQueries(cssText);

  return {
    type: 'pixflow_stage_b_style_map',
    version: 1,
    generatedAt: new Date().toISOString(),
    sourceMapRef: 'stage-b-source-map.json',
    summary: {
      cssTextLength: cssText.length,
      ruleCount: rules.length,
      mediaQueryCount: mediaQueries.length,
      pseudoSelectorCount: pseudoSelectors.length,
      customPropertyCount: customProperties.length,
      colorSystemTokenCount: Array.isArray(stageBColorSystem?.variables) ? stageBColorSystem.variables.length : 0,
    },
    customProperties,
    mediaQueries,
    pseudoSelectors,
    rules,
    classBuckets: bucketStageBClassRules(rules),
  };
}

function buildStageBSectionMap(sourceMap, styleMap) {
  const sections = Array.isArray(sourceMap?.sections) ? sourceMap.sections : [];

  return {
    type: 'pixflow_stage_b_section_map',
    version: 1,
    generatedAt: new Date().toISOString(),
    sourceMapRef: 'stage-b-source-map.json',
    styleMapRef: 'stage-b-style-map.json',
    sectionCount: sections.length,
    sections: sections.map((section, index) => {
      const role = inferStageBSectionRole(section, index, sections.length);
      const cssClassNames = uniqueStrings([
        ...stringArrayFromUnknown(section.classList),
        ...stringArrayFromUnknown(section.dataOdIds).map((value) => slugify(value)),
      ]).filter(Boolean);
      const cssRuleRefs = findStageBCssRulesForClasses(styleMap, cssClassNames);
      return {
        index: index + 1,
        sourceTag: section.tag,
        odId: section.odId,
        htmlId: section.htmlId,
        role,
        heading: section.heading,
        lead: section.lead,
        wordCount: section.wordCount,
        imageCount: section.imageCount,
        buttonCount: section.buttons.length,
        linkCount: section.links.length,
        images: section.images,
        headings: section.headings,
        buttons: section.buttons,
        links: section.links,
        classList: section.classList,
        dataAttributeElements: section.dataAttributeElements,
        cssRuleRefs,
        recommendedBricksSectionId: section.recommendedBricksSectionId,
        recommendedClassName: section.recommendedClassName,
        layoutIntent: inferStageBSectionLayoutIntent(section, role),
        elementPlan: buildStageBSectionElementPlan(section, role),
        preservationNotes: buildStageBSectionPreservationNotes(section, role, cssRuleRefs),
      };
    }),
  };
}

function buildStageBClassPlan(sourceMap, styleMap, stageBColorSystem) {
  const sectionClasses = (Array.isArray(sourceMap?.sections) ? sourceMap.sections : []).map((section) => ({
    name: section.recommendedClassName,
    sourceOdId: section.odId,
    responsibility: 'section-specific rhythm, visual accent, and responsive exceptions',
  }));
  const baseClasses = [
    ['pfod-section', 'section band background and vertical rhythm'],
    ['pfod-section-tight', 'smaller utility section spacing'],
    ['pfod-container', 'page-width container and default stack'],
    ['pfod-rule', 'editorial section index/rule row'],
    ['pfod-label', 'eyebrow and metadata labels'],
    ['pfod-display', 'hero display heading'],
    ['pfod-heading', 'section heading scale'],
    ['pfod-copy', 'body copy rhythm'],
    ['pfod-button-main', 'primary action styling'],
    ['pfod-button-alt', 'secondary action styling'],
    ['pfod-header', 'Bricks header template shell when Stage A header is included'],
    ['pfod-header-inner', 'header template width, alignment, and nav rhythm'],
    ['pfod-header-brand', 'header brand mark/text'],
    ['pfod-header-nav', 'fallback header navigation/action row when nav-menu is not available'],
    ['pfod-header-link', 'fallback header navigation item styling'],
    ['pfod-footer', 'Bricks footer template shell when Stage A footer is included'],
    ['pfod-footer-inner', 'footer template width, columns, and closing rhythm'],
    ['pfod-footer-brand', 'footer brand/summary text'],
    ['pfod-footer-nav', 'footer navigation/action row'],
    ['pfod-footer-link', 'footer navigation item styling'],
    ['pfod-card', 'standard elevated content card'],
    ['pfod-dark-panel', 'dark editorial panel'],
    ['pfod-media', 'image/media treatment'],
    ['pfod-stat-ring', 'separate circular stat number ring'],
  ].map(([name, responsibility]) => ({ name, responsibility, source: 'stage_b_compiler' }));

  return {
    type: 'pixflow_stage_b_class_plan',
    version: 1,
    generatedAt: new Date().toISOString(),
    sourceMapRef: 'stage-b-source-map.json',
    styleMapRef: 'stage-b-style-map.json',
    colorSystemRef: 'stage-b-color-system.json',
    colorSystem: {
      systemKey: firstString(stageBColorSystem?.systemKey),
      systemName: firstString(stageBColorSystem?.systemName, stageBColorSystem?.title),
      variableCount: Array.isArray(stageBColorSystem?.variables) ? stageBColorSystem.variables.length : 0,
      paletteColorCount: Array.isArray(stageBColorSystem?.palette?.colors) ? stageBColorSystem.palette.colors.length : 0,
    },
    baseClasses,
    sectionClasses,
    cssBuckets: styleMap?.classBuckets || {},
    customCssPolicy: [
      'Use Bricks settings for routine layout, spacing, type, color, radius, and media sizing.',
      'Use _cssCustom only for selector details or Bricks-unsupported effects from Stage A; rebuild visible pseudo-element dividers/marks as editable Bricks children when practical.',
      'Never use a root class as a token declaration bucket; native Bricks variables and palette are handled by stage-b-color-system.json.',
    ],
  };
}

function renderStageBFidelityPlan(sourceMap, styleMap, sectionMap, classPlan) {
  const lines = [];
  const document = sourceMap?.document || {};
  const styleSummary = styleMap?.summary || {};
  lines.push('# Stage B Fidelity Plan');
  lines.push('');
  lines.push('Stage B is a compiler pass. It must preserve the accepted Stage A artifact; it must not redesign the page.');
  lines.push('');
  lines.push('## Source Snapshot');
  lines.push('');
  lines.push(`- Title: ${safe(sourceMap?.source?.title)}`);
  lines.push(`- Sections: ${Number(document.sectionCount || 0)}`);
  lines.push(`- Visible words: ${Number(document.visibleWordCount || 0)}`);
  lines.push(`- Images: ${Number(document.imageCount || 0)}`);
  lines.push(`- data-od-id attributes: ${Number(document.dataOdIdCount || 0)}`);
  lines.push(`- CSS rules: ${Number(styleSummary.ruleCount || 0)}`);
  lines.push(`- Media queries: ${Number(styleSummary.mediaQueryCount || 0)}`);
  lines.push(`- Pseudo selectors: ${Number(styleSummary.pseudoSelectorCount || 0)}`);
  lines.push(`- Color variables: ${Number(styleSummary.customPropertyCount || 0)}`);
  lines.push('');
  lines.push('## Section Preservation');
  lines.push('');
  for (const section of sectionMap.sections || []) {
    lines.push(`- ${section.index}. ${safe(section.odId)} (${safe(section.role)}): ${safe(section.heading)}; ${section.imageCount} image(s), ${section.buttonCount} button(s).`);
  }
  lines.push('');
  lines.push('## Class Ownership');
  lines.push('');
  lines.push(`- Base global classes: ${(classPlan.baseClasses || []).map((item) => item.name).join(', ')}`);
  lines.push(`- Section-specific classes: ${(classPlan.sectionClasses || []).map((item) => item.name).join(', ') || '-'}`);
  lines.push('');
  lines.push('## Known Conversion Risks');
  lines.push('');
  if (Number(document.scriptCount || 0) > 0) {
    lines.push('- Stage A includes script behavior. Convert structural content to static visible Bricks output and record unsupported interaction details in the conversion report.');
  }
  if (Number(styleSummary.pseudoSelectorCount || 0) > 0) {
    lines.push('- Stage A includes pseudo-elements. Recreate visible pseudo-element details with Bricks-safe structure first; use scoped _cssCustom only for non-structural effects, not page-wide wrapper overlays or token buckets.');
  }
  if (Number(styleSummary.mediaQueryCount || 0) > 0) {
    lines.push('- Stage A includes responsive rules. Bricks output must keep mobile column collapse and readable lower-section rhythm.');
  }
  lines.push('- Preserve Atelier/native color variables through stage-b-color-system.json; do not emit .od-root or token declaration classes.');
  lines.push('- Preserve stat rings as separate circular number elements plus labels; do not use dashed stat container borders.');
  lines.push('- Preserve image wrappers exactly; do not add solid borders unless the source map proves they existed.');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

async function buildStageBConversionPlan(stageAWorkspace, stageAArtifact, stageAMetadata, stageBColorSystem, maps = {}) {
  const sourceMap = maps.sourceMap || await buildStageBSourceMap(stageAWorkspace, stageAArtifact, stageAMetadata);
  const styleMap = maps.styleMap || buildStageBStyleMap(sourceMap, stageBColorSystem);
  const sectionMap = maps.sectionMap || buildStageBSectionMap(sourceMap, styleMap);
  const headerPlan = maps.headerPlan || buildStageBHeaderPlan(sourceMap, sectionMap, {}, firstString(stageAMetadata?.title, sourceMap?.source?.title));
  const footerPlan = maps.footerPlan || buildStageBFooterPlan(sourceMap, sectionMap, {}, firstString(stageAMetadata?.title, sourceMap?.source?.title));
  const classPlan = maps.classPlan || buildStageBClassPlan(sourceMap, styleMap, stageBColorSystem);
  const routeContract = maps.routeContract || {};
  const themeStyleContract = maps.themeStyleContract || {};
  const themeStyleHealth = maps.themeStyleHealth || {};
  const fontSystem = maps.fontSystem || {};
  const iconSystem = maps.iconSystem || {};
  const allSections = Array.isArray(sectionMap.sections) ? sectionMap.sections : [];
  const pageSectionIndexes = new Set(
    Array.isArray(headerPlan?.pageSectionIndexes)
      ? headerPlan.pageSectionIndexes.map((value) => Number(value)).filter((value) => Number.isFinite(value))
      : []
  );
  if (Array.isArray(footerPlan?.pageSectionIndexes)) {
    const footerPageIndexes = new Set(footerPlan.pageSectionIndexes.map((value) => Number(value)).filter((value) => Number.isFinite(value)));
    if (pageSectionIndexes.size > 0) {
      for (const index of [...pageSectionIndexes]) {
        if (!footerPageIndexes.has(index)) {
          pageSectionIndexes.delete(index);
        }
      }
    } else {
      for (const index of footerPageIndexes) {
        pageSectionIndexes.add(index);
      }
    }
  }
  const sections = pageSectionIndexes.size > 0
    ? allSections.filter((section) => pageSectionIndexes.has(Number(section.index)))
    : allSections;
  const imageRefs = Array.isArray(sourceMap.images) ? sourceMap.images : [];

  return {
    type: 'pixflow_stage_b_conversion_plan',
    version: 2,
    generatedAt: new Date().toISOString(),
    source: sourceMap.source,
    colorSystem: {
      systemKey: firstString(stageBColorSystem?.systemKey),
      systemName: firstString(stageBColorSystem?.systemName, stageBColorSystem?.title),
      variableCategory: stageBColorSystem?.variableCategory || {},
      palette: stageBColorSystem?.palette || {},
    },
    fontSystem: summarizeStageBFontSystem(fontSystem),
    iconSystem: summarizeStageBIconSystem(iconSystem),
    maps: {
      sourceMap: 'stage-b-source-map.json',
      styleMap: 'stage-b-style-map.json',
      sectionMap: 'stage-b-section-map.json',
      headerPlan: 'stage-b-header-plan.json',
      footerPlan: 'stage-b-footer-plan.json',
      classPlan: 'stage-b-class-plan.json',
      routeContract: 'stage-b-route-contract.json',
      themeStyleContract: 'stage-b-theme-style-contract.json',
      themeStyleHealth: 'stage-b-theme-style-health.json',
      fontSystem: 'stage-b-font-system.json',
      iconSystem: 'stage-b-icon-system.json',
      fidelityPlan: 'stage-b-fidelity-plan.md',
    },
    routeContract,
    themeStyleContract,
    themeStyleHealth,
    htmlStats: sourceMap.document,
    headerPlan,
    footerPlan,
    sections,
    omittedHeaderSections: Array.isArray(headerPlan?.omittedPageSectionIndexes) ? headerPlan.omittedPageSectionIndexes : [],
    omittedFooterSections: Array.isArray(footerPlan?.omittedPageSectionIndexes) ? footerPlan.omittedPageSectionIndexes : [],
    assets: sourceMap.assets || [],
    imageRefs,
    scripts: sourceMap.scripts || [],
    dataAttributeElements: sourceMap.dataAttributeElements || [],
    recommendedGlobalClasses: (classPlan.baseClasses || []).map((item) => item.name),
    sectionClassPlan: classPlan.sectionClasses || [],
    conversionNotes: [
      `Route contract: ${firstString(routeContract.routeId, 'unknown')} / ${firstString(routeContract.styleMode, 'unknown')}.`,
      themeStyleContract.safeToLeanOnThemeStyles
        ? 'Theme-style contract allows routine Bricks theme-style defaults.'
        : 'Theme-style contract requires explicit page-scoped section/container/control defaults.',
      'Use native Bricks color variables from stage-b-color-system.json.',
      'Use installed/available font families from stage-b-font-system.json; do not import Google Fonts in Bricks payload CSS or code.',
      'Use Pixflow-installed Tabler SVG icons from stage-b-icon-system.json for CTA/action/card/proof affordances; do not use Bricks Font Awesome font icons for Stage B page icons.',
      'Preserve source border radius and corner rhythm with Bricks _border.radius or Pixflow radius variables instead of dropping rounded corners.',
      'Set explicit _display flex and _direction row on row wrappers/action groups that were horizontal in Stage A.',
      'Preserve marquee rows as readable repeated editable items with the same direction/rhythm; do not flatten them into malformed plain text.',
      'Keep stat rings as separate circle number elements plus label text.',
      'Do not create od-root or a root token declaration class.',
      'Preserve script-backed reveal polish with Bricks _attributes and Bricks page settings, not code elements.',
      'If stage-b-header-plan.json includes a header, keep header elements in stage_b_header.content and omit the header section from page content.',
      'Header template root sections must set source-accurate compact padding explicitly; do not let Pixflow Framework page section padding inflate topbar/nav/header bands.',
      'If stage-b-footer-plan.json includes a footer, keep footer elements in stage_b_footer.content and omit the footer section from page content.',
      'Footer template root sections must set their own source-accurate padding explicitly instead of inheriting routine page section padding.',
      'Use stage-b-source-map.json, stage-b-style-map.json, and stage-b-section-map.json before rereading the full Stage A HTML.',
    ],
  };
}

function buildStageBFooterPlan(sourceMap, sectionMap, flags = {}, title = '') {
  const sections = Array.isArray(sectionMap?.sections) ? sectionMap.sections : [];
  const candidates = sections.filter((section) => isStageBFooterSection(section));
  const selected = candidates.find((section) => section.sourceTag === 'footer' || section.tag === 'footer') || candidates[0] || null;
  const detected = Boolean(selected);
  const includeChoice = normalizeStageBFooterIncludeChoice(flags.includeFooter, detected);
  const scope = includeChoice.includeFooter
    ? normalizeStageBHeaderScope(firstString(flags.footerScope), 'current_page')
    : '';
  const selectedIndex = detected ? Number(selected.index) : 0;
  const pageSections = detected
    ? sections.filter((section) => Number(section.index) !== selectedIndex)
    : sections;
  const status = !detected
    ? 'not_detected'
    : (includeChoice.explicit ? 'selected' : 'requires_user_choice');
  const templateTitle = firstString(flags.footerTemplateTitle, flags.footerTitle, title ? `${title} Footer` : 'Pixflow Stage B Footer');

  return {
    type: 'pixflow_stage_b_footer_plan',
    version: 1,
    generatedAt: new Date().toISOString(),
    detected,
    status,
    includeFooter: includeChoice.includeFooter,
    includeSource: includeChoice.source,
    scope,
    templateType: 'footer',
    templateTitle,
    selectedSectionIndex: selectedIndex || null,
    selectedSectionOdId: detected ? firstString(selected.odId, selected.htmlId) : '',
    selectedSection: detected ? selected : null,
    candidates: candidates.map((section) => ({
      index: section.index,
      odId: section.odId,
      htmlId: section.htmlId,
      sourceTag: section.sourceTag || section.tag,
      role: section.role,
      heading: section.heading,
      linkCount: Array.isArray(section.links) ? section.links.length : 0,
      buttonCount: Number(section.buttonCount || 0),
    })),
    pageSectionIndexes: pageSections.map((section) => Number(section.index)).filter((value) => Number.isFinite(value)),
    pageSectionOdIds: pageSections.map((section) => firstString(section.odId, section.htmlId)).filter(Boolean),
    omittedPageSectionIndexes: detected ? [selectedIndex] : [],
    conditionsPreview: includeChoice.includeFooter
      ? (scope === 'sitewide'
        ? [{ main: 'any' }]
        : [{ main: 'ids', ids: ['<created-page-id>'], idsIncludeChildren: false }])
      : [],
    userQuestions: detected ? [
      {
        id: 'include_footer',
        question: 'Include the Stage A footer as a Bricks footer template?',
        choices: ['yes', 'no'],
        default: includeChoice.explicit ? (includeChoice.includeFooter ? 'yes' : 'no') : '',
      },
      {
        id: 'footer_scope',
        question: 'If included, should the footer be sitewide or only this page?',
        choices: ['current_page', 'sitewide'],
        default: scope || 'current_page',
      },
    ] : [],
    notes: detected
      ? [
        'Stage B must not write header/footer areas to normal page posts.',
        'If includeFooter is false or no explicit choice has been made, omit the footer from page content.',
        'If includeFooter is true, output footer elements separately in stage_b_footer.content.',
      ]
      : ['No distinct Stage A footer landmark was detected.'],
    sourceDocument: sourceMap?.document || {},
  };
}

function buildStageBHeaderPlan(sourceMap, sectionMap, flags = {}, title = '') {
  const sections = Array.isArray(sectionMap?.sections) ? sectionMap.sections : [];
  const candidates = sections.filter((section) => isStageBHeaderSection(section));
  const selected = candidates.find((section) => section.sourceTag === 'header' || section.tag === 'header') || candidates[0] || null;
  const detected = Boolean(selected);
  const includeChoice = normalizeStageBHeaderIncludeChoice(flags.includeHeader, detected);
  const scope = includeChoice.includeHeader
    ? normalizeStageBHeaderScope(firstString(flags.headerScope), 'current_page')
    : '';
  const selectedIndex = detected ? Number(selected.index) : 0;
  const pageSections = detected
    ? sections.filter((section) => Number(section.index) !== selectedIndex)
    : sections;
  const status = !detected
    ? 'not_detected'
    : (includeChoice.explicit ? 'selected' : 'requires_user_choice');
  const templateTitle = firstString(flags.headerTemplateTitle, flags.headerTitle, title ? `${title} Header` : 'Pixflow Stage B Header');

  return {
    type: 'pixflow_stage_b_header_plan',
    version: 1,
    generatedAt: new Date().toISOString(),
    detected,
    status,
    includeHeader: includeChoice.includeHeader,
    includeSource: includeChoice.source,
    scope,
    templateType: 'header',
    templateTitle,
    selectedSectionIndex: selectedIndex || null,
    selectedSectionOdId: detected ? firstString(selected.odId, selected.htmlId) : '',
    selectedSection: detected ? selected : null,
    candidates: candidates.map((section) => ({
      index: section.index,
      odId: section.odId,
      htmlId: section.htmlId,
      sourceTag: section.sourceTag || section.tag,
      role: section.role,
      heading: section.heading,
      linkCount: Array.isArray(section.links) ? section.links.length : 0,
      buttonCount: Number(section.buttonCount || 0),
    })),
    pageSectionIndexes: pageSections.map((section) => Number(section.index)).filter((value) => Number.isFinite(value)),
    pageSectionOdIds: pageSections.map((section) => firstString(section.odId, section.htmlId)).filter(Boolean),
    omittedPageSectionIndexes: detected ? [selectedIndex] : [],
    conditionsPreview: includeChoice.includeHeader
      ? (scope === 'sitewide'
        ? [{ main: 'any' }]
        : [{ main: 'ids', ids: ['<created-page-id>'], idsIncludeChildren: false }])
      : [],
    userQuestions: detected ? [
      {
        id: 'include_header',
        question: 'Include the Stage A header as a Bricks header template?',
        choices: ['yes', 'no'],
        default: includeChoice.explicit ? (includeChoice.includeHeader ? 'yes' : 'no') : '',
      },
      {
        id: 'header_scope',
        question: 'If included, should the header be sitewide or only this page?',
        choices: ['current_page', 'sitewide'],
        default: scope || 'current_page',
      },
    ] : [],
    notes: detected
      ? [
        'Stage B must not write header/footer areas to normal page posts.',
        'If includeHeader is false or no explicit choice has been made, omit the header from page content.',
        'If includeHeader is true, output header elements separately in stage_b_header.content.',
      ]
      : ['No distinct Stage A header landmark was detected.'],
    sourceDocument: sourceMap?.document || {},
  };
}

function isStageBFooterSection(section) {
  const tag = firstString(section?.sourceTag, section?.tag).toLowerCase();
  const haystack = [
    section?.odId,
    section?.htmlId,
    section?.role,
    section?.classes,
    ...(Array.isArray(section?.classList) ? section.classList : []),
  ].join(' ').toLowerCase();
  return tag === 'footer'
    || /\b(footer|site-footer|closing)\b/.test(haystack);
}

function isStageBHeaderSection(section) {
  const tag = firstString(section?.sourceTag, section?.tag).toLowerCase();
  const haystack = [
    section?.odId,
    section?.htmlId,
    section?.role,
    section?.classes,
    ...(Array.isArray(section?.classList) ? section.classList : []),
  ].join(' ').toLowerCase();
  return tag === 'header'
    || /\b(header|nav|navigation|navbar|masthead)\b/.test(haystack);
}

function normalizeStageBFooterIncludeChoice(value, detected) {
  if (!detected) {
    return { includeFooter: false, explicit: true, source: 'not_detected' };
  }
  if (value === true) {
    return { includeFooter: true, explicit: true, source: 'cli_flag' };
  }
  if (value === false) {
    return { includeFooter: false, explicit: true, source: 'cli_flag' };
  }
  const normalized = firstString(value).trim().toLowerCase();
  if (['1', 'yes', 'y', 'true', 'include', 'included', 'on'].includes(normalized)) {
    return { includeFooter: true, explicit: true, source: 'cli_flag' };
  }
  if (['0', 'no', 'n', 'false', 'omit', 'exclude', 'off'].includes(normalized)) {
    return { includeFooter: false, explicit: true, source: 'cli_flag' };
  }
  return { includeFooter: false, explicit: false, source: 'awaiting_user_choice' };
}

function normalizeStageBHeaderIncludeChoice(value, detected) {
  if (!detected) {
    return { includeHeader: false, explicit: true, source: 'not_detected' };
  }
  if (value === true) {
    return { includeHeader: true, explicit: true, source: 'cli_flag' };
  }
  if (value === false) {
    return { includeHeader: false, explicit: true, source: 'cli_flag' };
  }
  const normalized = firstString(value).trim().toLowerCase();
  if (['1', 'yes', 'y', 'true', 'include', 'included', 'on'].includes(normalized)) {
    return { includeHeader: true, explicit: true, source: 'cli_flag' };
  }
  if (['0', 'no', 'n', 'false', 'omit', 'exclude', 'off'].includes(normalized)) {
    return { includeHeader: false, explicit: true, source: 'cli_flag' };
  }
  return { includeHeader: false, explicit: false, source: 'awaiting_user_choice' };
}

function normalizeStageBHeaderScope(value, fallback = 'current_page') {
  const normalized = firstString(value).trim().toLowerCase().replace(/[-\s]+/g, '_');
  if (['sitewide', 'site_wide', 'entire_site', 'entire_website', 'global', 'all'].includes(normalized)) {
    return 'sitewide';
  }
  if (['current', 'current_page', 'this_page', 'page', 'single_page', 'individual'].includes(normalized)) {
    return 'current_page';
  }
  return fallback;
}

async function listStageBAssetFiles(assetsDir) {
  try {
    const entries = await fs.readdir(assetsDir, { withFileTypes: true });
    return entries
      .filter((entry) => entry.isFile() && /\.(?:avif|gif|jpe?g|png|svg|webp)$/i.test(entry.name))
      .map((entry) => ({
        file: `assets/${entry.name}`,
        name: entry.name,
        role: slugify(entry.name.replace(/\.[^.]+$/, '')),
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  } catch {
    return [];
  }
}

function extractStageBSectionsFromHtml(html) {
  const matches = [];
  const landmarkPattern = /<(header|section|footer)\b([^>]*)>/gi;
  let match;
  while ((match = landmarkPattern.exec(html)) !== null) {
    matches.push({
      tag: match[1].toLowerCase(),
      attrs: match[2] || '',
      index: match.index,
      openTag: match[0],
    });
  }

  return matches.map((entry, index) => {
    const next = matches[index + 1]?.index || html.length;
    const chunk = html.slice(entry.index, next);
    const odId = getHtmlAttr(entry.attrs, 'data-od-id') || getHtmlAttr(entry.attrs, 'id') || `${entry.tag}-${index + 1}`;
    const classes = getHtmlAttr(entry.attrs, 'class');
    const classList = classListFromAttr(classes);
    const heading = extractFirstHtmlText(chunk, /<h[1-3]\b[^>]*>([\s\S]*?)<\/h[1-3]>/i);
    const lead = extractFirstHtmlText(chunk, /<(?:p|blockquote)\b[^>]*>([\s\S]*?)<\/(?:p|blockquote)>/i);
    const images = extractStageBImageRefs(chunk);
    const visibleText = normalizeWhitespace(stripHtmlTags(stripStageBIgnoredHtml(chunk)));
    const headings = extractStageBHeadings(chunk);
    const buttons = extractStageBButtons(chunk);
    const links = extractStageBLinks(chunk);
    const dataAttributeElements = extractStageBDataAttributeElements(chunk);
    return {
      index: index + 1,
      tag: entry.tag,
      odId,
      htmlId: getHtmlAttr(entry.attrs, 'id'),
      classes,
      classList,
      dataOdIds: extractStageBDataOdIds(chunk),
      heading,
      lead,
      headings,
      buttons,
      links,
      dataAttributeElements,
      textSample: visibleText.slice(0, 500),
      textLength: visibleText.length,
      wordCount: countStageBWords(visibleText),
      htmlLength: chunk.length,
      imageCount: images.length,
      images,
      recommendedBricksSectionId: deterministicBricksId(`stage-b-section:${odId}:${index}`),
      recommendedClassName: `pfod-${slugify(odId)}`,
    };
  });
}

function extractStageBImageRefs(html) {
  const refs = [];
  const pattern = /<img\b([^>]*)>/gi;
  let match;
  while ((match = pattern.exec(html)) !== null) {
    const attrs = match[1] || '';
    const src = getHtmlAttr(attrs, 'src');
    if (!src) continue;
    refs.push({
      src,
      alt: getHtmlAttr(attrs, 'alt'),
      role: slugify(path.basename(src).replace(/\.[^.]+$/, '')),
    });
  }
  return refs;
}

function extractStageBStyleText(html) {
  const chunks = [];
  const pattern = /<style\b[^>]*>([\s\S]*?)<\/style>/gi;
  let match;
  while ((match = pattern.exec(String(html || ''))) !== null) {
    const css = String(match[1] || '').trim();
    if (css) {
      chunks.push(css);
    }
  }
  return chunks.join('\n\n');
}

function stripStageBIgnoredHtml(html) {
  return String(html || '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ');
}

function extractStageBBodyClass(html) {
  const match = String(html || '').match(/<body\b([^>]*)>/i);
  return match ? getHtmlAttr(match[1] || '', 'class') : '';
}

function extractStageBDataOdIds(html) {
  const ids = [];
  const pattern = /\bdata-od-id\s*=\s*(["'])(.*?)\1/gi;
  let match;
  while ((match = pattern.exec(String(html || ''))) !== null) {
    ids.push(decodeHtmlEntities(match[2]));
  }
  return uniqueStrings(ids);
}

function extractStageBScripts(html) {
  const scripts = [];
  const pattern = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
  let match;
  while ((match = pattern.exec(String(html || ''))) !== null) {
    const body = String(match[2] || '').trim();
    scripts.push({
      index: scripts.length + 1,
      attrs: normalizeWhitespace(match[1] || ''),
      length: body.length,
      javascriptCode: body,
      preview: body.slice(0, 500),
    });
  }
  return scripts;
}

function extractStageBHeadings(html) {
  const headings = [];
  const pattern = /<h([1-6])\b([^>]*)>([\s\S]*?)<\/h\1>/gi;
  let match;
  while ((match = pattern.exec(String(html || ''))) !== null) {
    headings.push({
      level: Number(match[1]),
      text: normalizeWhitespace(decodeHtmlEntities(stripHtmlTags(match[3]))).slice(0, 260),
      classList: classListFromAttr(getHtmlAttr(match[2] || '', 'class')),
    });
  }
  return headings;
}

function extractStageBButtons(html) {
  const buttons = [];
  const patterns = [
    /<button\b([^>]*)>([\s\S]*?)<\/button>/gi,
    /<a\b([^>]*class\s*=\s*["'][^"']*(?:button|btn|cta|action)[^"']*["'][^>]*)>([\s\S]*?)<\/a>/gi,
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(String(html || ''))) !== null) {
      buttons.push({
        text: normalizeWhitespace(decodeHtmlEntities(stripHtmlTags(match[2]))).slice(0, 160),
        href: getHtmlAttr(match[1] || '', 'href'),
        classList: classListFromAttr(getHtmlAttr(match[1] || '', 'class')),
      });
    }
  }
  return buttons;
}

function extractStageBLinks(html) {
  const links = [];
  const pattern = /<a\b([^>]*)>([\s\S]*?)<\/a>/gi;
  let match;
  while ((match = pattern.exec(String(html || ''))) !== null) {
    const text = normalizeWhitespace(decodeHtmlEntities(stripHtmlTags(match[2]))).slice(0, 160);
    if (!text) continue;
    links.push({
      text,
      href: getHtmlAttr(match[1] || '', 'href'),
      classList: classListFromAttr(getHtmlAttr(match[1] || '', 'class')),
    });
  }
  return links.slice(0, 24);
}

function extractStageBClassUsage(html) {
  const usage = new Map();
  const pattern = /<([a-z][a-z0-9-]*)\b([^>]*)>/gi;
  let match;
  while ((match = pattern.exec(String(html || ''))) !== null) {
    const tag = String(match[1] || '').toLowerCase();
    const attrs = match[2] || '';
    for (const className of classListFromAttr(getHtmlAttr(attrs, 'class'))) {
      const current = usage.get(className) || { name: className, count: 0, tags: new Set() };
      current.count += 1;
      if (tag) {
        current.tags.add(tag);
      }
      usage.set(className, current);
    }
  }
  return [...usage.values()]
    .map((item) => ({ name: item.name, count: item.count, tags: [...item.tags].sort() }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}

function extractPixflowStageBNestedInlineClassesByClass(html) {
  const result = new Map();
  const textElementPattern = /<(h[1-6]|p|blockquote|label|a|button)\b([^>]*)>([\s\S]*?)<\/\1>/gi;
  let match;
  while ((match = textElementPattern.exec(String(html || ''))) !== null) {
    const outerClasses = classListFromAttr(getHtmlAttr(match[2] || '', 'class'));
    if (outerClasses.length === 0) {
      continue;
    }
    const nestedClasses = uniqueStrings([...String(match[3] || '').matchAll(/\bclass\s*=\s*(["'])(.*?)\1/gi)]
      .flatMap((classMatch) => classListFromAttr(classMatch[2])));
    if (nestedClasses.length === 0) {
      continue;
    }
    for (const outerClass of outerClasses) {
      const current = result.get(outerClass) || new Set();
      for (const nestedClass of nestedClasses) {
        if (nestedClass && nestedClass !== outerClass) {
          current.add(nestedClass);
        }
      }
      if (current.size > 0) {
        result.set(outerClass, current);
      }
    }
  }
  return result;
}

function buildPixflowStageBNestedInlineClassCustomRules(className, nestedClasses, declarationsByClass, cssVariables) {
  if (!nestedClasses || typeof nestedClasses[Symbol.iterator] !== 'function') {
    return [];
  }
  const rules = [];
  for (const nestedClass of nestedClasses) {
    const declarations = objectValue(declarationsByClass.get(nestedClass));
    if (Object.keys(declarations).length === 0) {
      continue;
    }
    const body = serializePixflowCssDeclarations(declarations, { cssVariables });
    if (!body) {
      continue;
    }
    rules.push(`%root% ${buildPixflowStageBCssClassSelector(nestedClass)} { ${body} }`);
  }
  return rules;
}

function buildPixflowStageBCssClassSelector(className) {
  const source = firstString(className);
  if (/^-?[_a-zA-Z][_a-zA-Z0-9-]*$/.test(source)) {
    return `.${source}`;
  }
  return `.${source.replace(/([^_a-zA-Z0-9-])/g, '\\$1')}`;
}

function extractStageBDataAttributeElements(html) {
  const elements = [];
  const pattern = /<([a-z][a-z0-9-]*)\b([^>]*)>/gi;
  let match;
  while ((match = pattern.exec(String(html || ''))) !== null) {
    const tag = String(match[1] || '').toLowerCase();
    if (['script', 'style', 'meta', 'link'].includes(tag)) {
      continue;
    }
    const attrs = match[2] || '';
    const dataAttributes = extractStageBDataAttributes(attrs);
    if (dataAttributes.length === 0) {
      continue;
    }
    const tail = String(html || '').slice(match.index, Math.min(String(html || '').length, match.index + 600));
    elements.push({
      index: elements.length + 1,
      tag,
      htmlId: getHtmlAttr(attrs, 'id'),
      classList: classListFromAttr(getHtmlAttr(attrs, 'class')),
      dataAttributes,
      textSample: extractFirstHtmlText(tail, new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i')),
    });
  }
  return elements;
}

function extractStageBDataAttributes(attrs) {
  const attributes = [];
  const pattern = /\b(data-[A-Za-z0-9_-]+)(?:\s*=\s*(?:(["'])(.*?)\2|([^\s>]+)))?/gi;
  let match;
  while ((match = pattern.exec(String(attrs || ''))) !== null) {
    const name = String(match[1] || '').trim();
    if (!name || name.toLowerCase() === 'data-od-id') {
      continue;
    }
    const rawValue = match[3] !== undefined ? match[3] : (match[4] !== undefined ? match[4] : '');
    const value = decodeHtmlEntities(String(rawValue || ''));
    const attribute = { name };
    if (value !== '') {
      attribute.value = value;
    }
    attributes.push(attribute);
  }
  return attributes;
}

function findStageBDataAttributesForElement(section, matcher) {
  const elements = Array.isArray(section?.dataAttributeElements) ? section.dataAttributeElements : [];
  const found = elements.find((element) => {
    try {
      return matcher(element);
    } catch {
      return false;
    }
  });
  return found && Array.isArray(found.dataAttributes) ? found.dataAttributes : [];
}

function classListFromAttr(value) {
  return uniqueStrings(String(value || '').split(/\s+/).map((item) => item.trim()).filter(Boolean));
}

function countStageBWords(value) {
  const words = String(value || '').match(/[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)?/g);
  return Array.isArray(words) ? words.length : 0;
}

function getHtmlAttr(attrs, name) {
  const pattern = new RegExp(`${escapeRegExp(name)}\\s*=\\s*(["'])(.*?)\\1`, 'i');
  const match = String(attrs || '').match(pattern);
  return match ? decodeHtmlEntities(match[2]) : '';
}

function extractFirstHtmlText(html, pattern) {
  const match = String(html || '').match(pattern);
  if (!match) return '';
  return normalizeWhitespace(decodeHtmlEntities(stripHtmlTags(match[1]))).slice(0, 220);
}

function stripHtmlTags(value) {
  return String(value || '').replace(/<[^>]*>/g, ' ');
}

function normalizeWhitespace(value) {
  return String(value || '').replace(/\s+/g, ' ').trim();
}

function decodeHtmlEntities(value) {
  return String(value || '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&apos;/gi, "'")
    .replace(/&middot;/gi, '.')
    .replace(/&bull;/gi, '.')
    .replace(/&deg;/gi, 'deg')
    .replace(/&nearr;/gi, 'up-right')
    .replace(/&Oslash;/gi, 'O')
    .replace(/&ordm;/gi, 'o')
    .replace(/&#(\d+);/g, (_, code) => {
      const value = Number(code);
      return Number.isFinite(value) ? String.fromCharCode(value) : _;
    });
}

function escapeRegExp(value) {
  return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function extractStageBCssRuleSummaries(cssText) {
  const rules = [];
  const css = stripStageBCssComments(cssText);
  const pattern = /([^{}@][^{}]*)\{([^{}]*)\}/g;
  let match;
  while ((match = pattern.exec(css)) !== null) {
    const selector = normalizeWhitespace(match[1] || '');
    const body = String(match[2] || '').trim();
    if (!selector || !body || selector.startsWith('@')) {
      continue;
    }
    const declarations = parseStageBCssDeclarations(body);
    const classNames = uniqueStrings([...selector.matchAll(/\.([A-Za-z0-9_-]+)/g)].map((item) => item[1]));
    rules.push({
      index: rules.length + 1,
      selector,
      classNames,
      declarationCount: Object.keys(declarations).length,
      declarations,
      hasPseudoElement: /::(?:before|after)\b/i.test(selector),
      hasPseudoState: /:(?:hover|focus|active|visited|not|nth-|first-|last-)/i.test(selector),
      customPropertyCount: Object.keys(declarations).filter((key) => key.startsWith('--')).length,
    });
  }
  return rules;
}

function stripStageBCssComments(cssText) {
  return String(cssText || '').replace(/\/\*[\s\S]*?\*\//g, ' ');
}

function parseStageBCssDeclarations(body) {
  const declarations = {};
  for (const rawDeclaration of String(body || '').split(';')) {
    const separatorIndex = rawDeclaration.indexOf(':');
    if (separatorIndex <= 0) {
      continue;
    }
    const key = rawDeclaration.slice(0, separatorIndex).trim();
    const value = normalizeCssDeclarationValue(rawDeclaration.slice(separatorIndex + 1));
    if (key && value) {
      declarations[key] = value;
    }
  }
  return declarations;
}

function extractStageBMediaQueries(cssText) {
  const queries = [];
  const pattern = /@media\s*([^{]+)\{/gi;
  let match;
  while ((match = pattern.exec(String(cssText || ''))) !== null) {
    queries.push({
      index: queries.length + 1,
      condition: normalizeWhitespace(match[1] || ''),
    });
  }
  return queries;
}

function bucketStageBClassRules(rules) {
  const buckets = {
    layout: [],
    typography: [],
    media: [],
    decoration: [],
    interaction: [],
    tokenRoot: [],
  };
  for (const rule of Array.isArray(rules) ? rules : []) {
    const declarations = objectValue(rule.declarations);
    const keys = Object.keys(declarations);
    const record = {
      selector: rule.selector,
      classNames: rule.classNames,
      declarationCount: rule.declarationCount,
    };
    if (keys.some((key) => /^(display|grid|grid-|flex|align-|justify-|gap|column-gap|row-gap|position|inset|top|right|bottom|left|width|height|max-|min-|aspect-ratio|overflow)$/i.test(key))) {
      buckets.layout.push(record);
    }
    if (keys.some((key) => /^(font|font-|line-height|letter-spacing|text-|color)$/i.test(key))) {
      buckets.typography.push(record);
    }
    if (keys.some((key) => /^(object-fit|object-position|background|background-|clip-path|filter)$/i.test(key))) {
      buckets.media.push(record);
    }
    if (rule.hasPseudoElement || keys.some((key) => /^(border|border-|box-shadow|transform|opacity|mix-blend-mode)$/i.test(key))) {
      buckets.decoration.push(record);
    }
    if (rule.hasPseudoState || keys.some((key) => /^(transition|animation|cursor)$/i.test(key))) {
      buckets.interaction.push(record);
    }
    if (rule.customPropertyCount >= 4 || /:root|\.od-root|[-_]root\b/i.test(rule.selector)) {
      buckets.tokenRoot.push(record);
    }
  }
  return buckets;
}

function findStageBCssRulesForClasses(styleMap, classNames) {
  const names = new Set(stringArrayFromUnknown(classNames));
  if (names.size === 0) {
    return [];
  }
  return (Array.isArray(styleMap?.rules) ? styleMap.rules : [])
    .filter((rule) => stringArrayFromUnknown(rule.classNames).some((name) => names.has(name)))
    .slice(0, 24)
    .map((rule) => ({
      index: rule.index,
      selector: rule.selector,
      declarationCount: rule.declarationCount,
    }));
}

function inferStageBSectionRole(section, index, total) {
  const haystack = [
    section?.odId,
    section?.htmlId,
    section?.classes,
    section?.heading,
    section?.lead,
    ...(Array.isArray(section?.classList) ? section.classList : []),
  ].join(' ').toLowerCase();
  if (/\b(hero|masthead)\b/.test(haystack)) {
    return 'hero_or_header';
  }
  if (section?.tag === 'header' || /\b(nav|navigation|topbar|navbar)\b/.test(haystack)) {
    return 'header_navigation';
  }
  if (section?.tag === 'footer' || /\b(footer|closing)\b/.test(haystack)) {
    return 'footer_or_closing';
  }
  if (/\b(intro|overview|lead)\b/.test(haystack)) {
    return 'intro_section';
  }
  if (/\b(work|case|gallery|selected|showcase|project)\b/.test(haystack)) {
    return 'work_showcase';
  }
  if (/\b(testimonial|quote|proof|signal|metric|stat)\b/.test(haystack)) {
    return 'proof_or_stats';
  }
  if (/\b(feature|benefit|tool|capability|system)\b/.test(haystack)) {
    return 'feature_system';
  }
  if (/\b(process|step|workflow|timeline|how)\b/.test(haystack)) {
    return 'process';
  }
  if (/\b(cta|call|start|download|github)\b/.test(haystack)) {
    return 'cta';
  }
  return 'content_section';
}

function inferStageBSectionLayoutIntent(section, role) {
  if ((section?.imageCount || 0) >= 3) {
    return 'collage_or_media_grid';
  }
  if ((section?.imageCount || 0) >= 1) {
    return 'media_split';
  }
  if ((section?.buttonCount || 0) >= 2 || role === 'cta') {
    return 'action_band';
  }
  if ((section?.headings || []).length > 2 || (section?.links || []).length > 5) {
    return 'dense_editorial_list';
  }
  if (role === 'proof_or_stats') {
    return 'stat_or_quote_panel';
  }
  return 'editorial_stack';
}

function buildStageBSectionElementPlan(section, role) {
  const plan = [
    { name: 'section', purpose: 'root editable Bricks section' },
    { name: 'container', purpose: 'width and internal rhythm' },
    { name: 'block', purpose: 'section rule/metadata row' },
    { name: 'block', purpose: 'main section layout group' },
    { name: 'heading', purpose: 'primary section heading' },
    { name: 'text-basic', purpose: 'lead/body copy and metadata' },
  ];
  if ((section?.buttonCount || 0) > 0 || role === 'cta' || role === 'hero_or_header') {
    plan.push({ name: 'button', purpose: 'editable CTA/action links' });
  }
  if (role === 'header_navigation') {
    plan.push({ name: 'nav-menu', purpose: 'dedicated Bricks navigation element when a real menu source is available' });
  }
  if ((section?.imageCount || 0) > 0) {
    plan.push({ name: 'image', purpose: 'mapped Stage A media roles' });
  }
  if (role === 'proof_or_stats') {
    plan.push({ name: 'text-basic', purpose: 'separate circular stat number rings plus labels' });
  }
  return plan;
}

function buildStageBSectionPreservationNotes(section, role, cssRuleRefs) {
  const notes = [];
  notes.push(`Preserve ${safe(section?.odId)} as a distinct editable Bricks section.`);
  if ((section?.imageCount || 0) > 0) {
    notes.push('Map source image elements to Bricks image elements with local asset refs.');
  }
  if ((section?.buttonCount || 0) > 0) {
    notes.push('Keep CTA text editable and preserve button hierarchy.');
  }
  if (role === 'header_navigation') {
    notes.push('Use Bricks nav-menu for real menu navigation when a menu source is available; keep CTAs as buttons.');
  }
  if (role === 'proof_or_stats') {
    notes.push('Keep stats as separated number/ring and label elements.');
  }
  if ((cssRuleRefs || []).some((rule) => /::(?:before|after)\b/i.test(rule.selector))) {
    notes.push('Recreate visible pseudo-element details with editable Bricks child elements first; reserve scoped _cssCustom for non-structural effects.');
  }
  return notes;
}

function uniqueStrings(values) {
  const seen = new Set();
  const result = [];
  for (const value of Array.isArray(values) ? values : []) {
    const text = firstString(value);
    if (!text || seen.has(text)) {
      continue;
    }
    seen.add(text);
    result.push(text);
  }
  return result;
}

async function writeDeterministicStageBArtifacts({ workspaceDir, sourceId, title, stageBMetadata, stageBColorSystem, stageBFontSystem, stageBIconSystem, stageBConversionPlan, files }) {
  const htmlBaseline = await buildPixflowStageBHtmlBaseline({
    htmlFile: files.stageAArtifact,
    plan: stageBConversionPlan,
    iconSystem: stageBIconSystem,
  });
  const usedHtmlBaseline = Array.isArray(htmlBaseline.content) && htmlBaseline.content.length > 0;
  const globalClasses = usedHtmlBaseline && htmlBaseline.globalClasses.length > 0
    ? htmlBaseline.globalClasses
    : buildDeterministicStageBGlobalClasses(stageBConversionPlan);
  const content = usedHtmlBaseline
    ? htmlBaseline.content
    : buildDeterministicStageBContent(stageBConversionPlan, globalClasses, stageBIconSystem);
  const headerContent = usedHtmlBaseline
    ? htmlBaseline.headerContent
    : buildDeterministicStageBHeaderContent(stageBConversionPlan, globalClasses);
  const headerResult = buildDeterministicStageBHeaderResult(stageBConversionPlan, headerContent);
  const footerContent = usedHtmlBaseline
    ? htmlBaseline.footerContent
    : buildDeterministicStageBFooterContent(stageBConversionPlan, globalClasses);
  const footerResult = buildDeterministicStageBFooterResult(stageBConversionPlan, footerContent);
  const pageSettings = usedHtmlBaseline
    ? objectValue(htmlBaseline.pageSettings)
    : buildPixflowStageBPageSettings(buildStageBJavaScriptCode(stageBConversionPlan.scripts));
  const mode = usedHtmlBaseline ? 'pixflow_html_baseline' : 'deterministic_scaffold';
  const result = {
    type: 'direct_page_generation',
    generation_mode: 'direct_page',
    source_request_id: sourceId,
    prompt: firstString(stageBMetadata?.stageAMetadata?.selectedPrototype?.title, title),
    page_title: title,
    page_goal: 'preserve accepted Stage A artifact in editable Bricks',
    plan: {
      source: mode,
      sectionMap: stageBConversionPlan.sections.map((section) => ({
        odId: section.odId,
        heading: section.heading,
        images: section.images.map((image) => image.src),
      })),
    },
    section_specs: stageBConversionPlan.sections,
    section_count: stageBConversionPlan.sections.length,
    stage_b_header: headerResult,
    stage_b_footer: footerResult,
    header_content: headerContent,
    footer_content: footerContent,
    page_settings: pageSettings,
    pageSettings,
    stage_b_page_settings: pageSettings,
    payload_included: true,
    payload_status: 'insertable_with_payload',
    payload_format: 'bricks_json',
    payload_source: `pixflow_cli_stage_b_${mode}`,
    content,
    global_classes: globalClasses,
    stage_b_color_system: stageBColorSystem,
    stage_b_font_system: stageBFontSystem,
    stage_b_icon_system: stageBIconSystem,
    stage_b_route_contract: stageBConversionPlan.routeContract || {},
    stage_b_theme_style_contract: stageBConversionPlan.themeStyleContract || {},
    stage_b_theme_style_health: stageBConversionPlan.themeStyleHealth || {},
    color_system: stageBColorSystem,
    font_system: stageBFontSystem,
    icon_system: stageBIconSystem,
    classes_included: true,
    classes_status: 'generated_bem_classes_included',
    components: [],
    components_included: false,
    components_status: 'components_missing',
    diagnostics: {
      direct_generation_path: 'pixflow_design_artifact_to_bricks_cli',
      stage_b_mode: mode,
      route_contract: summarizeStageBRouteContract(stageBConversionPlan.routeContract || {}),
      theme_style_contract: summarizeStageBThemeStyleContract(stageBConversionPlan.themeStyleContract || {}),
      htmlBaseline: htmlBaseline.summary || null,
      scaffoldGeneratedAt: new Date().toISOString(),
    },
  };

  const colorUsage = {
    type: 'pixflow_stage_b_color_usage',
    mode,
    systemKey: firstString(stageBColorSystem?.systemKey),
    variableCategory: stageBColorSystem?.variableCategory || {},
    palette: stageBColorSystem?.palette || {},
    tokensUsed: usedHtmlBaseline && htmlBaseline.tokensUsed.length > 0
      ? htmlBaseline.tokensUsed
      : ['--paper', '--paper-warm', '--bone', '--ink', '--ink-soft', '--ink-mute', '--ink-faint', '--coral', '--mustard', '--olive', '--inverse'],
    rawFallbacks: usedHtmlBaseline ? htmlBaseline.rawColorFallbacks : [],
  };

  const report = usedHtmlBaseline
    ? renderPixflowStageBHtmlBaselineReport(stageBConversionPlan, htmlBaseline, globalClasses, content)
    : renderDeterministicStageBConversionReport(stageBConversionPlan, globalClasses, content);

  await Promise.all([
    writeJsonFile(files.result, result),
    writeJsonFile(files.payload, content),
    writeJsonFile(files.headerPayload, headerContent),
    writeJsonFile(files.footerPayload, footerContent),
    writeJsonFile(files.globalClasses, globalClasses),
    writeJsonFile(files.baselineResult, result),
    writeJsonFile(files.baselinePayload, content),
    writeJsonFile(files.baselineHeaderPayload, headerContent),
    writeJsonFile(files.baselineFooterPayload, footerContent),
    writeJsonFile(files.baselineGlobalClasses, globalClasses),
    writeJsonFile(files.colorUsage, colorUsage),
    writeTextFile(files.conversionReport, report),
    writeTextFile(files.baselineReport, report),
  ]);

  return {
    mode,
    elementCount: content.length,
    headerElementCount: headerContent.length,
    footerElementCount: footerContent.length,
    globalClassCount: globalClasses.length,
    baselineElementCount: usedHtmlBaseline ? htmlBaseline.content.length : 0,
    baselineGlobalClassCount: usedHtmlBaseline ? htmlBaseline.globalClasses.length : 0,
    sectionCount: stageBConversionPlan.sections.length,
    workspaceDir,
  };
}

function buildDeterministicStageBGlobalClasses(plan) {
  const cls = (name, settings) => ({
    id: deterministicBricksId(`stage-b-class:${name}`),
    name,
    settings,
  });

  return [
    cls('pfod-section', {
      _background: { color: { raw: 'var(--paper)' } },
      _padding: { top: 'clamp(72px, 8vw, 130px)', right: '24px', bottom: 'clamp(72px, 8vw, 130px)', left: '24px' },
      _cssCustom: [
        '%root% { position: relative; overflow: hidden; }',
        '%root% * { box-sizing: border-box; }',
        '%root% [data-reveal] { opacity: 0; transform: translateY(22px); transition: opacity 620ms cubic-bezier(0.2, 0, 0, 1), transform 620ms cubic-bezier(0.2, 0, 0, 1); }',
        '%root% [data-reveal="left"] { transform: translateX(-24px); }',
        '%root% [data-reveal="right"] { transform: translateX(24px); }',
        '%root% [data-reveal="scale"] { transform: scale(0.96); }',
        '%root% [data-reveal][data-revealed="true"] { opacity: 1; transform: none; }',
        '@media (prefers-reduced-motion: reduce) { %root% [data-reveal] { opacity: 1; transform: none; transition: none; } }',
      ].join('\n'),
    }),
    cls('pfod-section-tight', {
      _padding: { top: 'clamp(48px, 6vw, 90px)', right: '24px', bottom: 'clamp(48px, 6vw, 90px)', left: '24px' },
    }),
    cls('pfod-container', {
      _widthMax: '1360px',
      _margin: { right: 'auto', left: 'auto' },
      _display: 'flex',
      _direction: 'column',
      _rowGap: '32px',
    }),
    cls('pfod-rule', {
      _display: 'flex',
      _justifyContent: 'space-between',
      _alignItems: 'center',
      _columnGap: '18px',
      _padding: { top: '14px', bottom: '14px' },
      _border: { width: { top: '1px' }, style: 'solid', color: { raw: 'var(--line)' } },
      _typography: { color: { raw: 'var(--ink-faint)' }, 'font-size': '11px', 'letter-spacing': '0.12em', 'text-transform': 'uppercase' },
    }),
    cls('pfod-label', {
      _typography: { color: { raw: 'var(--coral)' }, 'font-size': '11px', 'font-weight': '700', 'letter-spacing': '0.22em', 'text-transform': 'uppercase' },
    }),
    cls('pfod-display', {
      _typography: { color: { raw: 'var(--ink)' }, 'font-size': 'clamp(42px, 7vw, 90px)', 'font-weight': '800', 'line-height': '0.96', 'letter-spacing': '-0.035em' },
      _cssCustom: '%root% em { font-family: "Playfair Display", serif; font-weight: 500; }',
    }),
    cls('pfod-heading', {
      _typography: { color: { raw: 'var(--ink)' }, 'font-size': 'clamp(28px, 4vw, 54px)', 'font-weight': '800', 'line-height': '1.02', 'letter-spacing': '-0.03em' },
    }),
    cls('pfod-copy', {
      _typography: { color: { raw: 'var(--ink-soft)' }, 'font-size': '16px', 'line-height': '1.62' },
      _widthMax: '66ch',
    }),
    cls('pfod-button-main', {
      _background: { color: { raw: 'var(--coral)' } },
      _typography: { color: { raw: 'var(--inverse)' }, 'font-weight': '800' },
      _border: { radius: '999px' },
      _padding: { top: '13px', right: '22px', bottom: '13px', left: '22px' },
    }),
    cls('pfod-button-alt', {
      _background: { color: { raw: 'transparent' } },
      _typography: { color: { raw: 'var(--ink)' }, 'font-weight': '800' },
      _border: { width: '1px', style: 'solid', color: { raw: 'var(--line)' }, radius: '999px' },
      _padding: { top: '13px', right: '22px', bottom: '13px', left: '22px' },
    }),
    cls('pfod-header', {
      _background: { color: { raw: 'var(--paper)' } },
      _border: { width: { bottom: '1px' }, style: 'solid', color: { raw: 'var(--line)' } },
      _padding: { top: '14px', right: '24px', bottom: '14px', left: '24px' },
      _cssCustom: '%root% { position: sticky; top: 0; z-index: 40; backdrop-filter: blur(18px); }',
    }),
    cls('pfod-header-inner', {
      _widthMax: '1360px',
      _margin: { right: 'auto', left: 'auto' },
      _display: 'flex',
      _direction: 'row',
      '_direction:mobile_portrait': 'column',
      _alignItems: 'center',
      '_alignItems:mobile_portrait': 'flex-start',
      _justifyContent: 'space-between',
      _columnGap: '24px',
      _rowGap: '12px',
      _cssCustom: '@media (max-width: 760px) { %root% { align-items: flex-start; flex-direction: column; } }',
    }),
    cls('pfod-header-brand', {
      _typography: { color: { raw: 'var(--ink)' }, 'font-size': '15px', 'font-weight': '850', 'letter-spacing': '0' },
    }),
    cls('pfod-header-nav', {
      _display: 'flex',
      _direction: 'row',
      _flexWrap: 'wrap',
      _alignItems: 'center',
      _justifyContent: 'flex-end',
      _columnGap: '18px',
      _rowGap: '10px',
      _cssCustom: '%root% { flex-wrap: wrap; }',
    }),
    cls('pfod-header-link', {
      _background: { color: { raw: 'transparent' } },
      _typography: { color: { raw: 'var(--ink-soft)' }, 'font-size': '13px', 'font-weight': '750' },
      _border: { radius: '999px' },
      _padding: { top: '8px', right: '10px', bottom: '8px', left: '10px' },
      _cssCustom: '%root%:hover { color: var(--ink); background: color-mix(in oklab, var(--bone), transparent 28%); }',
    }),
    cls('pfod-footer', {
      _background: { color: { raw: 'var(--ink)' } },
      _padding: { top: '42px', right: '24px', bottom: '42px', left: '24px' },
      _cssCustom: '%root% { color: var(--inverse); }',
    }),
    cls('pfod-footer-inner', {
      _widthMax: '1360px',
      _margin: { right: 'auto', left: 'auto' },
      _display: 'flex',
      _direction: 'row',
      '_direction:mobile_portrait': 'column',
      _alignItems: 'flex-start',
      _justifyContent: 'space-between',
      _columnGap: '24px',
      _rowGap: '18px',
    }),
    cls('pfod-footer-brand', {
      _typography: { color: { raw: 'var(--inverse)' }, 'font-size': '14px', 'font-weight': '800', 'line-height': '1.4' },
      _widthMax: '36ch',
    }),
    cls('pfod-footer-nav', {
      _display: 'flex',
      _direction: 'row',
      _flexWrap: 'wrap',
      _alignItems: 'center',
      _justifyContent: 'flex-end',
      _columnGap: '16px',
      _rowGap: '10px',
    }),
    cls('pfod-footer-link', {
      _background: { color: { raw: 'transparent' } },
      _typography: { color: { raw: 'var(--paper-dark)' }, 'font-size': '13px', 'font-weight': '700' },
      _border: { radius: '999px' },
      _padding: { top: '8px', right: '10px', bottom: '8px', left: '10px' },
      _cssCustom: '%root%:hover { color: var(--inverse); }',
    }),
    cls('pfod-card', {
      _background: { color: { raw: 'var(--bone)' } },
      _border: { radius: '18px' },
      _padding: { top: '26px', right: '26px', bottom: '26px', left: '26px' },
      _cssCustom: '%root% { box-shadow: 0 30px 60px -30px color-mix(in oklab, var(--ink), transparent 82%); }',
    }),
    cls('pfod-dark-panel', {
      _background: { color: { raw: 'var(--ink)' } },
      _typography: { color: { raw: 'var(--inverse)' } },
      _border: { radius: '28px' },
      _padding: { top: 'clamp(42px, 7vw, 86px)', right: 'clamp(24px, 5vw, 64px)', bottom: 'clamp(42px, 7vw, 86px)', left: 'clamp(24px, 5vw, 64px)' },
    }),
    cls('pfod-media', {
      _overflow: 'hidden',
      _border: { radius: '18px' },
      _aspectRatio: '4 / 3',
      _objectFit: 'cover',
      _cssCustom: '%root% img { width: 100%; height: 100%; object-fit: cover; display: block; }',
    }),
    cls('pfod-stat-ring', {
      _width: '34px',
      _height: '34px',
      _display: 'flex',
      _alignItems: 'center',
      _justifyContent: 'center',
      _border: { width: '2px', style: 'solid', color: { raw: 'var(--ink)' }, radius: '999px' },
      _typography: { color: { raw: 'var(--ink)' }, 'font-size': '11px', 'font-weight': '800' },
    }),
  ];
}

function buildDeterministicStageBContent(plan, globalClasses, iconSystem = {}) {
  const classId = (name) => globalClasses.find((item) => item.name === name)?.id;
  const iconRef = (iconId, setId = firstString(iconSystem?.defaultSetId, 'tabler-outline')) => ({
    library: 'pixflowSvg',
    icon: buildStageBIconPlaceholder(setId, iconId),
  });
  const content = [];

  const add = (seed, name, settings = {}, parent = '', children = []) => {
    const id = deterministicBricksId(`stage-b-element:${seed}`);
    const element = { id, name, settings, children };
    if (parent) element.parent = parent;
    content.push(element);
    if (parent) {
      const parentElement = content.find((item) => item.id === parent);
      if (parentElement && !parentElement.children.includes(id)) {
        parentElement.children.push(id);
      }
    }
    return id;
  };

  const addSourceAttributes = (settings, seed, dataAttributes) => {
    const attributes = buildStageBBricksAttributes(dataAttributes, seed);
    if (attributes.length === 0) {
      return settings;
    }
    return {
      ...settings,
      _attributes: attributes,
    };
  };

  const addText = (seed, parent, text, extra = {}) => {
    if (!text) return '';
    return add(seed, 'text-basic', { text, ...extra }, parent);
  };

  const sections = plan.sections.length > 0 ? plan.sections : [{
    odId: 'pixflow-design-landing',
    heading: firstString(plan.source?.title, 'Pixflow Design Landing'),
    lead: 'Accepted Stage A artifact converted to editable Bricks JSON.',
    images: plan.imageRefs || [],
  }];

  sections.forEach((section, index) => {
    const odId = slugify(section.odId || `section-${index + 1}`);
    const sectionClasses = [classId('pfod-section')].filter(Boolean);
    if (['nav', 'wire', 'footer'].includes(odId)) {
      sectionClasses.push(classId('pfod-section-tight'));
    }
    if (odId.includes('work')) {
      sectionClasses.push(classId('pfod-dark-panel'));
    }

    const sectionAttrs = findStageBDataAttributesForElement(section, (element) => (
      element.tag === section.sourceTag
        && firstString(element.htmlId) === firstString(section.htmlId)
        && element.classList.some((className) => stringArrayFromUnknown(section.classList).includes(className))
    ));
    const sectionRuntimeAttrs = [...sectionAttrs];
    if (firstString(section.htmlId)) {
      sectionRuntimeAttrs.push({ name: 'id', value: firstString(section.htmlId) });
    }
    const sectionId = add(`${odId}:section`, 'section', addSourceAttributes({
      _cssGlobalClasses: sectionClasses.filter(Boolean),
    }, `${odId}:section`, sectionRuntimeAttrs));
    const containerId = add(`${odId}:container`, 'container', {
      _cssGlobalClasses: [classId('pfod-container')].filter(Boolean),
    }, sectionId);
    const ruleId = add(`${odId}:rule`, 'block', {
      _cssGlobalClasses: [classId('pfod-rule')].filter(Boolean),
    }, containerId);
    addText(`${odId}:rule-left`, ruleId, `${romanNumeral(index + 1)}.`);
    addText(`${odId}:rule-mid`, ruleId, firstString(section.odId, section.htmlId, `Section ${index + 1}`));
    addText(`${odId}:rule-right`, ruleId, `${String(index + 1).padStart(3, '0')} / ${String(sections.length).padStart(3, '0')}`);

    const bodyId = add(`${odId}:body`, 'block', {
      _display: 'grid',
      _gridTemplateColumns: section.images?.length ? 'minmax(0, 0.92fr) minmax(320px, 1.08fr)' : 'minmax(0, 1fr)',
      '_gridTemplateColumns:mobile_portrait': '1fr',
      _columnGap: 'clamp(28px, 6vw, 76px)',
      _rowGap: '28px',
      _alignItems: 'center',
      _cssCustom: '@media (max-width: 860px) { %root% { grid-template-columns: 1fr; } }',
    }, containerId);
    const copyId = add(`${odId}:copy`, 'block', {
      _display: 'flex',
      _direction: 'column',
      _rowGap: '18px',
    }, bodyId);
    const labelAttrs = findStageBDataAttributesForElement(section, (element) => element.classList.includes('label') || element.tag === 'span');
    addText(`${odId}:label`, copyId, firstString(section.classes, section.tag, 'Pixflow Design'), addSourceAttributes({
      _cssGlobalClasses: [classId('pfod-label')].filter(Boolean),
    }, `${odId}:label`, labelAttrs));
    const headingAttrs = findStageBDataAttributesForElement(section, (element) => /^h[1-6]$/.test(element.tag));
    add(`${odId}:heading`, index === 0 ? 'heading' : 'heading', addSourceAttributes({
      text: firstString(section.heading, section.odId, 'Pixflow Design'),
      tag: index === 0 ? 'h1' : 'h2',
      _cssGlobalClasses: [index === 0 ? classId('pfod-display') : classId('pfod-heading')].filter(Boolean),
    }, `${odId}:heading`, headingAttrs), copyId);
    const leadAttrs = findStageBDataAttributesForElement(section, (element) => element.tag === 'p' || element.classList.includes('lead'));
    addText(`${odId}:lead`, copyId, firstString(section.lead, 'Preserved from the accepted Stage A Pixflow Design artifact.'), addSourceAttributes({
      _cssGlobalClasses: [classId('pfod-copy')].filter(Boolean),
    }, `${odId}:lead`, leadAttrs));

    if (odId.includes('hero') || (Array.isArray(section.buttons) && section.buttons.length > 0)) {
      const actionAttrs = findStageBDataAttributesForElement(section, (element) => element.classList.includes('hero-actions') || element.classList.includes('actions') || element.classList.includes('nav-actions'));
      const actionsId = add(`${odId}:actions`, 'block', addSourceAttributes({
        _display: 'flex',
        _direction: 'row',
        _flexWrap: 'wrap',
        _alignItems: 'center',
        _columnGap: '12px',
        _rowGap: '12px',
        _cssCustom: '%root% { flex-wrap: wrap; }',
      }, `${odId}:actions`, actionAttrs), copyId);
      add(`${odId}:button-main`, 'button', {
        text: firstString(section.buttons?.[0]?.text, 'Star us on GitHub'),
        link: section.buttons?.[0]?.href ? { type: 'external', url: section.buttons[0].href } : undefined,
        icon: iconRef(/github/i.test(firstString(section.buttons?.[0]?.href, section.buttons?.[0]?.text)) ? 'brand-github' : 'arrow-up-right'),
        iconPosition: 'left',
        _cssGlobalClasses: [classId('pfod-button-main')].filter(Boolean),
      }, actionsId);
      add(`${odId}:button-alt`, 'button', {
        text: firstString(section.buttons?.[1]?.text, 'Download desktop'),
        link: section.buttons?.[1]?.href ? { type: 'external', url: section.buttons[1].href } : undefined,
        icon: iconRef(/download|release/i.test(firstString(section.buttons?.[1]?.text, section.buttons?.[1]?.href)) ? 'download' : 'arrow-up-right'),
        iconPosition: 'left',
        _cssGlobalClasses: [classId('pfod-button-alt')].filter(Boolean),
      }, actionsId);
    }

    if (section.images?.length) {
      const mediaWrapAttrs = findStageBDataAttributesForElement(section, (element) => element.classList.includes('plate') || element.classList.includes('media') || element.classList.includes('hero-art'));
      const mediaWrapId = add(`${odId}:media-wrap`, 'block', addSourceAttributes({
        _display: 'grid',
        _gridTemplateColumns: section.images.length > 2 ? 'repeat(2, minmax(0, 1fr))' : '1fr',
        '_gridTemplateColumns:mobile_portrait': '1fr',
        _columnGap: '16px',
        _rowGap: '16px',
      }, `${odId}:media-wrap`, mediaWrapAttrs), bodyId);
      section.images.slice(0, 6).forEach((image, imageIndex) => {
        add(`${odId}:image:${imageIndex}`, 'image', {
          image: { url: image.src },
          alt: image.alt || section.heading || image.role,
          _cssGlobalClasses: [classId('pfod-media')].filter(Boolean),
        }, mediaWrapId);
      });
    }

    if (odId.includes('hero')) {
      const statsId = add(`${odId}:stats`, 'block', {
        _display: 'flex',
        _columnGap: '18px',
        _rowGap: '14px',
      }, copyId);
      for (const value of ['31', '72', '16']) {
        add(`${odId}:stat-ring:${value}`, 'text-basic', {
          text: value,
          _cssGlobalClasses: [classId('pfod-stat-ring')].filter(Boolean),
        }, statsId);
      }
    }
  });

  return content;
}

function buildDeterministicStageBHeaderResult(plan, headerContent) {
  const headerPlan = objectValue(plan?.headerPlan);
  if (!headerPlan.includeHeader || headerContent.length === 0) {
    return {
      type: 'pixflow_stage_b_header_template',
      version: 1,
      detected: Boolean(headerPlan.detected),
      includeHeader: false,
      status: headerPlan.status || (headerPlan.detected ? 'requires_user_choice' : 'not_detected'),
      scope: '',
      templateType: 'header',
      templateTitle: firstString(headerPlan.templateTitle),
      content: [],
    };
  }

  return {
    type: 'pixflow_stage_b_header_template',
    version: 1,
    detected: true,
    includeHeader: true,
    status: 'included',
    scope: normalizeStageBHeaderScope(headerPlan.scope, 'current_page'),
    templateType: 'header',
    templateTitle: firstString(headerPlan.templateTitle, 'Pixflow Stage B Header'),
    sourceSectionOdId: firstString(headerPlan.selectedSectionOdId),
    sourceSectionIndex: headerPlan.selectedSectionIndex || null,
    conditionsPreview: Array.isArray(headerPlan.conditionsPreview) ? headerPlan.conditionsPreview : [],
    content: headerContent,
  };
}

function buildDeterministicStageBFooterResult(plan, footerContent) {
  const footerPlan = objectValue(plan?.footerPlan);
  if (!footerPlan.includeFooter || footerContent.length === 0) {
    return {
      type: 'pixflow_stage_b_footer_template',
      version: 1,
      detected: Boolean(footerPlan.detected),
      includeFooter: false,
      status: footerPlan.status || (footerPlan.detected ? 'requires_user_choice' : 'not_detected'),
      scope: '',
      templateType: 'footer',
      templateTitle: firstString(footerPlan.templateTitle),
      content: [],
    };
  }

  return {
    type: 'pixflow_stage_b_footer_template',
    version: 1,
    detected: true,
    includeFooter: true,
    status: 'selected',
    scope: normalizeStageBHeaderScope(footerPlan.scope, 'current_page'),
    templateType: 'footer',
    templateTitle: firstString(footerPlan.templateTitle, 'Pixflow Stage B Footer'),
    sourceSectionOdId: firstString(footerPlan.selectedSectionOdId),
    sourceSectionIndex: footerPlan.selectedSectionIndex || null,
    conditionsPreview: Array.isArray(footerPlan.conditionsPreview) ? footerPlan.conditionsPreview : [],
    content: footerContent,
  };
}

function buildDeterministicStageBHeaderContent(plan, globalClasses) {
  const headerPlan = objectValue(plan?.headerPlan);
  const section = objectValue(headerPlan.selectedSection);
  if (!headerPlan.includeHeader || Object.keys(section).length === 0) {
    return [];
  }

  const classId = (name) => globalClasses.find((item) => item.name === name)?.id;
  const content = [];
  const add = (seed, name, settings = {}, parent = '', children = []) => {
    const id = deterministicBricksId(`stage-b-header-element:${seed}`);
    const element = { id, name, settings, children };
    if (parent) element.parent = parent;
    content.push(element);
    if (parent) {
      const parentElement = content.find((item) => item.id === parent);
      if (parentElement && !parentElement.children.includes(id)) {
        parentElement.children.push(id);
      }
    }
    return id;
  };
  const withAttrs = (settings, seed, dataAttributes) => {
    const attributes = buildStageBBricksAttributes(dataAttributes, `header:${seed}`);
    return attributes.length > 0 ? { ...settings, _attributes: attributes } : settings;
  };

  const odId = slugify(firstString(section.odId, section.htmlId, 'header'));
  const rootAttrs = findStageBDataAttributesForElement(section, (element) => (
    element.tag === firstString(section.sourceTag, 'header')
      && stringArrayFromUnknown(element.classList).some((className) => stringArrayFromUnknown(section.classList).includes(className))
  ));
  const rootRuntimeAttrs = [...rootAttrs];
  if (firstString(section.htmlId)) {
    rootRuntimeAttrs.push({ name: 'id', value: firstString(section.htmlId) });
  }
  const rootId = add(`${odId}:root`, 'section', withAttrs({
    _cssGlobalClasses: [classId('pfod-header')].filter(Boolean),
  }, `${odId}:root`, rootRuntimeAttrs));
  const innerId = add(`${odId}:inner`, 'container', {
    _cssGlobalClasses: [classId('pfod-header-inner')].filter(Boolean),
    _display: 'flex',
    _direction: 'row',
    '_direction:mobile_portrait': 'column',
    _alignItems: 'center',
    '_alignItems:mobile_portrait': 'flex-start',
    _justifyContent: 'space-between',
    _columnGap: '24px',
    _rowGap: '12px',
  }, rootId);

  const links = Array.isArray(section.links) ? section.links.filter((link) => firstString(link.text)) : [];
  const buttons = Array.isArray(section.buttons) ? section.buttons.filter((button) => firstString(button.text)) : [];
  const brandText = firstString(
    links.find((link) => /brand|logo|home/i.test(stringArrayFromUnknown(link.classList).join(' ')))?.text,
    section.heading,
    links[0]?.text,
    plan?.source?.title,
    'Pixflow Design'
  );
  add(`${odId}:brand`, 'text-basic', {
    text: brandText,
    _cssGlobalClasses: [classId('pfod-header-brand')].filter(Boolean),
  }, innerId);

  const navId = add(`${odId}:nav`, 'block', {
    _cssGlobalClasses: [classId('pfod-header-nav')].filter(Boolean),
    _display: 'flex',
    _direction: 'row',
    _flexWrap: 'wrap',
    _alignItems: 'center',
    _justifyContent: 'flex-end',
    _columnGap: '18px',
    _rowGap: '10px',
  }, innerId);
  const navLinks = uniqueStageBHeaderLinks([...links, ...buttons])
    .filter((link) => firstString(link.text) !== brandText)
    .slice(0, 7);
  for (const [index, link] of navLinks.entries()) {
    const isAction = /github|download|start|try|contact|book|get/i.test(firstString(link.text));
    add(`${odId}:link:${index}`, 'button', {
      text: firstString(link.text),
      link: firstString(link.href) ? { type: 'external', url: firstString(link.href) } : undefined,
      _cssGlobalClasses: [classId(isAction ? 'pfod-button-main' : 'pfod-header-link')].filter(Boolean),
    }, navId);
  }

  return content;
}

function buildDeterministicStageBFooterContent(plan, globalClasses) {
  const footerPlan = objectValue(plan?.footerPlan);
  const section = objectValue(footerPlan.selectedSection);
  if (!footerPlan.includeFooter || Object.keys(section).length === 0) {
    return [];
  }

  const classId = (name) => globalClasses.find((item) => item.name === name)?.id;
  const content = [];
  const add = (seed, name, settings = {}, parent = '', children = []) => {
    const id = deterministicBricksId(`stage-b-footer-element:${seed}`);
    const element = { id, name, settings, children };
    if (parent) element.parent = parent;
    content.push(element);
    if (parent) {
      const parentElement = content.find((item) => item.id === parent);
      if (parentElement && !parentElement.children.includes(id)) {
        parentElement.children.push(id);
      }
    }
    return id;
  };
  const withAttrs = (settings, seed, dataAttributes) => {
    const attributes = buildStageBBricksAttributes(dataAttributes, `footer:${seed}`);
    return attributes.length > 0 ? { ...settings, _attributes: attributes } : settings;
  };

  const odId = slugify(firstString(section.odId, section.htmlId, 'footer'));
  const rootAttrs = findStageBDataAttributesForElement(section, (element) => (
    element.tag === firstString(section.sourceTag, 'footer')
      && stringArrayFromUnknown(element.classList).some((className) => stringArrayFromUnknown(section.classList).includes(className))
  ));
  const rootRuntimeAttrs = [...rootAttrs];
  if (firstString(section.htmlId)) {
    rootRuntimeAttrs.push({ name: 'id', value: firstString(section.htmlId) });
  }
  const rootId = add(`${odId}:root`, 'section', withAttrs({
    _cssGlobalClasses: [classId('pfod-footer')].filter(Boolean),
  }, `${odId}:root`, rootRuntimeAttrs));
  const innerId = add(`${odId}:inner`, 'container', {
    _cssGlobalClasses: [classId('pfod-footer-inner')].filter(Boolean),
    _display: 'flex',
    _direction: 'row',
    '_direction:mobile_portrait': 'column',
    _alignItems: 'flex-start',
    _justifyContent: 'space-between',
    _columnGap: '24px',
    _rowGap: '18px',
  }, rootId);

  const links = Array.isArray(section.links) ? section.links.filter((link) => firstString(link.text)) : [];
  const buttons = Array.isArray(section.buttons) ? section.buttons.filter((button) => firstString(button.text)) : [];
  const brandText = firstString(
    section.heading,
    links.find((link) => /brand|logo|home/i.test(stringArrayFromUnknown(link.classList).join(' ')))?.text,
    plan?.source?.title,
    'Pixflow Design'
  );
  add(`${odId}:brand`, 'text-basic', {
    text: brandText,
    _cssGlobalClasses: [classId('pfod-footer-brand')].filter(Boolean),
  }, innerId);

  const navId = add(`${odId}:nav`, 'block', {
    _cssGlobalClasses: [classId('pfod-footer-nav')].filter(Boolean),
    _display: 'flex',
    _direction: 'row',
    _flexWrap: 'wrap',
    _alignItems: 'center',
    _justifyContent: 'flex-end',
    _columnGap: '16px',
    _rowGap: '10px',
  }, innerId);
  const navLinks = uniqueStageBHeaderLinks([...links, ...buttons])
    .filter((link) => firstString(link.text) !== brandText)
    .slice(0, 8);
  for (const [index, link] of navLinks.entries()) {
    const isAction = /github|download|start|try|contact|book|get|subscribe/i.test(firstString(link.text));
    add(`${odId}:link:${index}`, 'button', {
      text: firstString(link.text),
      link: firstString(link.href) ? { type: 'external', url: firstString(link.href) } : undefined,
      _cssGlobalClasses: [classId(isAction ? 'pfod-button-alt' : 'pfod-footer-link')].filter(Boolean),
    }, navId);
  }

  return content;
}

function uniqueStageBHeaderLinks(links) {
  const seen = new Set();
  const result = [];
  for (const link of Array.isArray(links) ? links : []) {
    const text = firstString(link?.text);
    if (!text) continue;
    const href = firstString(link?.href);
    const key = `${text.toLowerCase()}|${href}`;
    if (seen.has(key)) continue;
    seen.add(key);
    result.push({ ...link, text, href });
  }
  return result;
}

function buildStageBBricksAttributes(dataAttributes, seed) {
  return (Array.isArray(dataAttributes) ? dataAttributes : [])
    .filter((attribute) => firstString(attribute?.name))
    .map((attribute) => {
      const name = firstString(attribute.name);
      const value = firstString(attribute.value);
      const result = {
        id: deterministicBricksId(`stage-b-attribute:${seed}:${name}:${value}`),
        name,
      };
      if (value) {
        result.value = value;
      }
      return result;
    });
}

function buildStageBJavaScriptCode(scripts) {
  const bodies = (Array.isArray(scripts) ? scripts : [])
    .map((script) => firstString(script?.javascriptCode))
    .filter(Boolean);
  if (bodies.length === 0) {
    return '';
  }
  return bodies.join('\n\n');
}

function romanNumeral(value) {
  const numerals = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
  return numerals[Math.max(0, Math.min(numerals.length - 1, Number(value || 1) - 1))] || String(value || '');
}

function renderDeterministicStageBConversionReport(plan, globalClasses, content) {
  const lines = [];
  lines.push('# Stage B Conversion Report');
  lines.push('');
  lines.push('Mode: deterministic scaffold. This run intentionally avoids the long model-authored Bricks conversion path so Stage B can complete reliably while preserving the accepted Stage A section order, media roles, and token handoff.');
  lines.push('');
  lines.push('## Summary');
  lines.push('');
  lines.push(`- Source title: ${safe(plan.source?.title)}`);
  lines.push(`- Sections mapped: ${plan.sections.length}`);
  lines.push(`- Elements generated: ${content.length}`);
  if (plan.headerPlan?.detected) {
    lines.push(`- Header detected: ${plan.headerPlan.includeHeader ? `included as ${plan.headerPlan.scope || 'current_page'} template` : 'omitted from page content'}`);
  }
  if (plan.footerPlan?.detected) {
    lines.push(`- Footer detected: ${plan.footerPlan.includeFooter ? `included as ${plan.footerPlan.scope || 'current_page'} template` : 'omitted from page content'}`);
  }
  lines.push(`- Global classes generated: ${globalClasses.length}`);
  lines.push(`- Color system: ${safe(plan.colorSystem?.systemName || plan.colorSystem?.systemKey)}`);
  lines.push('');
  lines.push('## Section Mapping');
  lines.push('');
  for (const section of plan.sections) {
    lines.push(`- ${section.index}. ${safe(section.odId)} -> ${safe(section.heading)} (${section.imageCount} image refs)`);
  }
  lines.push('');
  lines.push('## Preservation Notes');
  lines.push('');
  lines.push('- Native Bricks variables/palette are supplied via `stage_b_color_system`; no `.od-root` token bucket is generated.');
  lines.push('- Stat rings are emitted as separate circular text elements, not dashed stat container borders.');
  lines.push('- Stage A reveal attributes are preserved as Bricks `_attributes`; Stage A JavaScript is carried in Bricks page settings when present, not in Bricks `code` elements.');
  lines.push('- Stage A header landmarks are split from page content. When included, the header is emitted as `stage_b_header.content` for a Bricks header template.');
  lines.push('- Stage A footer landmarks are split from page content. When included, the footer is emitted as `stage_b_footer.content` for a Bricks footer template.');
  lines.push('- This scaffold is designed to be a fast, reliable baseline for insertion. A later model refinement pass can increase per-element craft once timing is stable.');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

async function materializeStageBBricksSkills(workspaceDir) {
  const sourceDir = path.resolve(process.cwd(), 'src', 'AI', 'DirectSkills', 'bricks-web-prototype');
  const targetDir = path.join(workspaceDir, '.pixflow-skills', 'bricks-web-prototype');
  const result = {
    active: false,
    sourceDir,
    targetDir,
    fileCount: 0,
    files: [],
  };
  try {
    await fs.stat(sourceDir);
  } catch {
    return result;
  }
  await copyDirectoryRecursive(sourceDir, targetDir);
  const copied = await listFilesRecursive(targetDir);
  result.active = true;
  result.fileCount = copied.length;
  result.files = copied.map((file) => path.relative(workspaceDir, file).replace(/\\/g, '/'));
  return result;
}

async function materializeStageBStageAMedia(stageAWorkspace, workspaceDir) {
  const candidates = [
    {
      sourceDir: path.join(stageAWorkspace, 'drafts', 'assets'),
      targetDir: path.join(workspaceDir, 'stage-a', 'drafts', 'assets'),
      label: 'draft_assets',
    },
    {
      sourceDir: path.join(stageAWorkspace, 'drafts', 'assets'),
      targetDir: path.join(workspaceDir, 'assets'),
      label: 'workspace_assets',
    },
    {
      sourceDir: path.join(stageAWorkspace, 'assets'),
      targetDir: path.join(workspaceDir, 'stage-a', 'assets'),
      label: 'root_assets',
    },
    {
      sourceDir: path.join(stageAWorkspace, 'screenshots'),
      targetDir: path.join(workspaceDir, 'stage-a', 'screenshots'),
      label: 'screenshots',
    },
  ];
  const result = {
    copied: [],
    fileCount: 0,
    files: [],
  };

  for (const candidate of candidates) {
    try {
      const stat = await fs.stat(candidate.sourceDir);
      if (!stat.isDirectory()) {
        continue;
      }
    } catch {
      continue;
    }
    await copyDirectoryRecursive(candidate.sourceDir, candidate.targetDir);
    const copiedFiles = await listFilesRecursive(candidate.targetDir);
    result.copied.push({
      label: candidate.label,
      sourceDir: candidate.sourceDir,
      targetDir: candidate.targetDir,
      fileCount: copiedFiles.length,
    });
    for (const file of copiedFiles) {
      result.files.push(path.relative(workspaceDir, file).replace(/\\/g, '/'));
    }
  }

  result.fileCount = result.files.length;
  return result;
}

async function buildStageBColorSystem(stageAWorkspace, stageAArtifact, title, stageAMetadata = {}) {
  const sources = [];
  for (const candidate of [
    path.join(stageAWorkspace, 'tokens.css'),
    path.join(stageAWorkspace, 'drafts', 'tokens.css'),
    stageAArtifact,
  ]) {
    const content = await readOptionalText(candidate);
    if (content.trim()) {
      sources.push({
        path: path.relative(stageAWorkspace, candidate).replace(/\\/g, '/'),
        content,
      });
    }
  }

  const tokens = new Map();
  for (const source of sources) {
    for (const token of extractCssVariableDeclarations(source.content)) {
      if (!tokens.has(token.name)) {
        tokens.set(token.name, {
          ...token,
          source: source.path,
        });
      }
    }
  }

  const tokenList = [...tokens.values()];
  const paletteTokens = tokenList.filter((token) => isBricksPaletteColorValue(token.value));
  const identity = inferStageBColorSystemIdentity(stageAMetadata, title);
  const systemName = identity.name;
  const systemKey = identity.key;
  const paletteId = deterministicBricksId(`stage-b-palette:${systemKey}`);
  const variableCategoryId = deterministicBricksId(`stage-b-variables:${systemKey}`);

  return {
    type: 'pixflow_stage_b_color_system',
    version: 1,
    source: 'stage_a_tokens',
    systemKey,
    systemName,
    title: systemName,
    mergeStrategy: 'reuse_existing_bricks_scheme_by_id',
    generatedAt: new Date().toISOString(),
    sourceFiles: sources.map((source) => source.path),
    tokenCount: tokenList.length,
    paletteTokenCount: paletteTokens.length,
    variableCategory: {
      id: variableCategoryId,
      name: `${systemName} Tokens`,
    },
    variables: tokenList.map((token) => ({
      id: deterministicBricksId(`stage-b-variable:${token.name}`),
      name: token.name.replace(/^--/, ''),
      cssVariable: token.name.startsWith('--') ? token.name : `--${token.name}`,
      value: token.value,
      category: variableCategoryId,
      source: token.source,
    })),
    palette: {
      id: paletteId,
      name: `${systemName} Color System`,
      colors: paletteTokens.map((token) => {
        const cssVariable = token.name.startsWith('--') ? token.name : `--${token.name}`;
        const variableReference = `var(${cssVariable})`;
        return {
          id: deterministicBricksId(`stage-b-palette-color:${token.name}`),
          name: cssVariable.replace(/^--/, ''),
          raw: variableReference,
          light: token.value,
          variableReference,
          token: cssVariable,
          source: token.source,
        };
      }),
    },
  };
}

async function buildStageBFontSystem(stageAWorkspace, stageAArtifact, title, stageAMetadata = {}) {
  const sources = [];
  for (const candidate of [
    stageAArtifact,
    path.join(stageAWorkspace, 'tokens.css'),
    path.join(stageAWorkspace, 'drafts', 'tokens.css'),
    path.join(stageAWorkspace, 'design-system.md'),
  ]) {
    const content = await readOptionalText(candidate);
    if (content.trim()) {
      sources.push({
        path: path.relative(stageAWorkspace, candidate).replace(/\\/g, '/'),
        content,
      });
    }
  }

  const googleFamilies = new Map();
  const roleTokens = [];
  const familyRoles = new Map();

  for (const source of sources) {
    for (const family of extractStageBGoogleFontFamilies(source.content, source.path)) {
      const key = family.familyId;
      const existing = googleFamilies.get(key) || {
        familyId: family.familyId,
        family: family.family,
        provider: 'google_fonts',
        sourceUrls: [],
        roles: [],
        requiredWeights: [],
        requiredStyles: [],
        variableVariants: [],
        staticVariants: [],
      };
      existing.sourceUrls = uniqueStrings([...existing.sourceUrls, family.sourceUrl]);
      existing.requiredWeights = uniqueStrings([...existing.requiredWeights, ...family.requiredWeights]);
      existing.requiredStyles = uniqueStrings([...existing.requiredStyles, ...family.requiredStyles]);
      existing.variableVariants = uniqueStrings([...existing.variableVariants, ...family.variableVariants]);
      existing.staticVariants = uniqueStrings([...existing.staticVariants, ...family.staticVariants]);
      googleFamilies.set(key, existing);
    }

    for (const token of extractStageBFontRoleTokens(source.content, source.path)) {
      roleTokens.push(token);
      const role = inferStageBFontRole(token.name);
      const familyName = token.primaryFamily;
      if (familyName) {
        const key = normalizeStageBFontFamilyId(familyName);
        if (!familyRoles.has(key)) familyRoles.set(key, new Set());
        familyRoles.get(key).add(role);
      }
    }
  }

  const fonts = [...googleFamilies.values()].map((font) => {
    const roleSet = familyRoles.get(font.familyId);
    const roles = roleSet ? [...roleSet] : inferStageBFontRolesFromFamily(font.family);
    const requiredStyles = font.requiredStyles.length ? font.requiredStyles : ['normal'];
    const variableVariants = font.variableVariants.length
      ? font.variableVariants
      : (requiredStyles.includes('italic') ? ['regular', 'italic'] : ['regular']);
    const staticVariants = font.staticVariants.length
      ? font.staticVariants
      : ['regular'];
    return {
      ...font,
      roles: uniqueStrings(roles),
      requiredWeights: uniqueStrings(font.requiredWeights).sort(sortNumericStrings),
      requiredStyles: uniqueStrings(requiredStyles),
      variableVariants: uniqueStrings(variableVariants),
      staticVariants: uniqueStrings(staticVariants),
      installAction: 'install_before_stage_b_insert',
      installTool: 'pixflow.google_fonts.install',
      bricksUsage: 'Use the installed Bricks custom font id when available; CSS custom selectors may still reference the real family name because the installed @font-face uses that family.',
    };
  });

  const systemIdentity = inferStageBColorSystemIdentity(stageAMetadata, title);
  return {
    type: 'pixflow_stage_b_font_system',
    version: 1,
    source: 'stage_a_font_imports_and_role_tokens',
    systemKey: systemIdentity.key,
    systemName: systemIdentity.name,
    generatedAt: new Date().toISOString(),
    sourceFiles: sources.map((source) => source.path),
    installStrategy: 'pixflow_google_font_manager_before_bricks_insert',
    modelContract: [
      'Preserve Stage A font roles before choosing Bricks typography settings.',
      'Do not emit Google Fonts <link>, @import, fonts.googleapis, fonts.gstatic, or @font-face in Bricks payloads.',
      'Use _typography.font-family on Bricks elements/global classes for visible font overrides.',
      'Use role-specific classes for display, body, mono, and serif/italic emphasis when the active theme style does not already match Stage A.',
      'For mixed sans/serif headlines, keep editable text and style the inline emphasis with scoped %root% em CSS using the installed family name.',
    ],
    roleTokens: dedupeStageBFontRoleTokens(roleTokens),
    fonts,
    fontCount: fonts.length,
    googleFontCount: fonts.length,
  };
}

function extractStageBGoogleFontFamilies(content, sourcePath) {
  const families = [];
  const urls = extractStageBGoogleFontUrls(content);
  for (const url of urls) {
    let parsed;
    try {
      parsed = new URL(url.replace(/&amp;/g, '&'));
    } catch {
      continue;
    }
    for (const spec of parsed.searchParams.getAll('family')) {
      const family = parseStageBGoogleFontFamilySpec(spec, url, sourcePath);
      if (family) families.push(family);
    }
  }
  return families;
}

function extractStageBGoogleFontUrls(content) {
  const urls = new Set();
  const source = String(content || '').replace(/&amp;/g, '&');
  const patterns = [
    /https:\/\/fonts\.googleapis\.com\/css2?\?[^"'\s)<>]+/gi,
    /url\(\s*['"]?(https:\/\/fonts\.googleapis\.com\/css2?\?[^'")\s<>]+)['"]?\s*\)/gi,
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(source)) !== null) {
      urls.add((match[1] || match[0] || '').trim());
    }
  }
  return [...urls].filter(Boolean);
}

function parseStageBGoogleFontFamilySpec(spec, sourceUrl, sourcePath) {
  const [rawFamily, descriptor = ''] = String(spec || '').split(':');
  const family = rawFamily.replace(/\+/g, ' ').trim();
  if (!family) return null;
  const parsed = parseStageBGoogleFontDescriptor(descriptor);
  return {
    familyId: normalizeStageBFontFamilyId(family),
    family,
    sourceUrl,
    source: sourcePath,
    requiredWeights: parsed.weights,
    requiredStyles: parsed.styles,
    variableVariants: parsed.variableVariants,
    staticVariants: parsed.staticVariants,
  };
}

function parseStageBGoogleFontDescriptor(descriptor) {
  const weights = new Set();
  const styles = new Set();
  const variableVariants = new Set();
  const staticVariants = new Set();
  const text = String(descriptor || '').trim();

  if (!text) {
    styles.add('normal');
    variableVariants.add('regular');
    staticVariants.add('regular');
    return fontDescriptorResult(weights, styles, variableVariants, staticVariants);
  }

  const [axisPart = '', valuesPart = ''] = text.split('@');
  const axes = axisPart.split(',').map((axis) => axis.trim()).filter(Boolean);
  const rows = valuesPart.split(';').map((row) => row.trim()).filter(Boolean);
  for (const row of rows.length ? rows : ['regular']) {
    const values = row.split(',').map((value) => value.trim());
    const axisValues = {};
    axes.forEach((axis, index) => {
      axisValues[axis] = values[index] || '';
    });
    const rawWeight = axisValues.wght || (!axes.length ? row : '');
    const rawItalic = axisValues.ital || '';
    const style = rawItalic === '1' ? 'italic' : 'normal';
    styles.add(style);
    variableVariants.add(style === 'italic' ? 'italic' : 'regular');

    if (rawWeight.includes('..')) {
      const [min, max] = rawWeight.split('..').map((value) => String(Number.parseInt(value, 10) || '').trim()).filter(Boolean);
      if (min) weights.add(min);
      if (max) weights.add(max);
      staticVariants.add(style === 'italic' ? `${min || '400'}italic` : (min || 'regular'));
      continue;
    }

    const normalizedWeight = String(Number.parseInt(rawWeight, 10) || '').trim();
    if (normalizedWeight) {
      weights.add(normalizedWeight);
      staticVariants.add(style === 'italic' ? `${normalizedWeight}italic` : normalizedWeight);
    } else if (style === 'italic') {
      staticVariants.add('italic');
    } else {
      staticVariants.add('regular');
    }
  }

  if (styles.size === 0) {
    styles.add('normal');
  }

  return fontDescriptorResult(weights, styles, variableVariants, staticVariants);
}

function fontDescriptorResult(weights, styles, variableVariants, staticVariants) {
  return {
    weights: uniqueStrings([...weights]).sort(sortNumericStrings),
    styles: uniqueStrings([...styles]),
    variableVariants: uniqueStrings([...variableVariants]),
    staticVariants: uniqueStrings([...staticVariants]),
  };
}

function extractStageBFontRoleTokens(content, sourcePath) {
  const tokens = [];
  const pattern = /(--(?:font|type|body|sans|serif|mono)[A-Za-z0-9_-]*)\s*:\s*([^;{}]+);/g;
  let match;
  while ((match = pattern.exec(String(content || ''))) !== null) {
    const name = match[1].trim();
    const value = normalizeCssDeclarationValue(match[2]);
    const primaryFamily = extractPrimaryStageBFontFamily(value);
    if (!name || !value || !primaryFamily) continue;
    tokens.push({
      name,
      value,
      primaryFamily,
      role: inferStageBFontRole(name),
      source: sourcePath,
    });
  }
  return tokens;
}

function extractPrimaryStageBFontFamily(value) {
  const source = String(value || '').replace(/^var\([^)]+\)$/i, '').trim();
  const quoted = source.match(/["']([^"']+)["']/);
  if (quoted && quoted[1]) return quoted[1].trim();
  const first = source.split(',')[0].trim();
  if (!first || /^(system-ui|ui-|serif|sans-serif|monospace|inherit|initial|unset)$/i.test(first)) return '';
  return first;
}

function inferStageBFontRole(name) {
  const source = firstString(name).toLowerCase();
  if (source.includes('display') || source.includes('heading') || source.includes('sans')) return 'display';
  if (source.includes('serif')) return 'serif_emphasis';
  if (source.includes('mono') || source.includes('code')) return 'mono';
  if (source.includes('body') || source.includes('text')) return 'body';
  return 'body';
}

function inferStageBFontRolesFromFamily(family) {
  const lower = firstString(family).toLowerCase();
  if (lower.includes('mono')) return ['mono'];
  if (lower.includes('playfair') || lower.includes('serif')) return ['serif_emphasis'];
  if (lower.includes('tight') || lower.includes('display')) return ['display'];
  return ['body'];
}

function normalizeStageBFontFamilyId(family) {
  return slugify(firstString(family).replace(/\+/g, ' '));
}

function dedupeStageBFontRoleTokens(tokens) {
  const seen = new Set();
  const deduped = [];
  for (const token of tokens) {
    const key = `${token.name}|${token.primaryFamily}|${token.value}`;
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(token);
  }
  return deduped;
}

async function buildStageBIconSystem(stageAWorkspace, stageAArtifact, title, stageAMetadata = {}) {
  const sourceFiles = [
    { path: stageAArtifact, label: 'Stage A artifact', required: true },
    { path: path.join(stageAWorkspace, 'design-system.md'), label: 'Stage A design system', required: false },
    { path: path.join(stageAWorkspace, 'components-manifest.md'), label: 'Stage A components manifest', required: false },
  ];
  const sources = [];
  for (const source of sourceFiles) {
    const content = source.required
      ? await readTextFile(source.path, source.label)
      : await readOptionalText(source.path);
    if (content.trim()) {
      sources.push({ ...source, content });
    }
  }

  const detected = new Map();
  const addIcon = (icon) => {
    const setId = firstString(icon.setId, 'tabler-outline');
    const id = normalizeStageBIconId(firstString(icon.id));
    if (!id) return;
    const key = `${setId}:${id}`;
    const existing = detected.get(key) || {};
    detected.set(key, {
      setId,
      id,
      name: firstString(icon.name, titleCaseFromSlug(id)),
      variant: setId.includes('filled') ? 'filled' : 'outline',
      roles: uniqueStrings([
        ...(Array.isArray(existing.roles) ? existing.roles : []),
        ...(Array.isArray(icon.roles) ? icon.roles.map(firstString) : []),
      ]).filter(Boolean),
      reason: firstString(existing.reason, icon.reason),
      placeholder: buildStageBIconPlaceholder(setId, id),
      bricksIcon: {
        library: 'pixflowSvg',
        icon: buildStageBIconPlaceholder(setId, id),
      },
    });
  };

  const combined = sources.map((source) => source.content).join('\n\n');
  const lower = combined.toLowerCase();
  if (/<svg\b/i.test(combined) && /M5\s+19L19\s+5/i.test(combined)) {
    addIcon({ id: 'arrow-up-right', roles: ['button_icon', 'external_link'], reason: 'Stage A uses inline external-arrow SVGs.' });
  }
  if (/<svg\b/i.test(combined) && /<circle[^>]+cx=["']?12/i.test(combined) && /M9\s+12h6/i.test(combined)) {
    addIcon({ id: 'circle-plus', roles: ['button_icon', 'download_action'], reason: 'Stage A uses an inline circular plus SVG for a CTA.' });
  }
  if (/\bgithub\b/i.test(combined)) {
    addIcon({ id: 'brand-github', roles: ['brand_icon', 'button_icon', 'footer_link'], reason: 'Stage A links to GitHub.' });
  }
  if (/\bdownload\b|\breleases\b/i.test(combined)) {
    addIcon({ id: 'download', roles: ['button_icon', 'download_action'], reason: 'Stage A has a download/release action.' });
  }
  if (/class=["'][^"']*\bcard-arrow\b/i.test(combined) || />\s*\+\s*<\/span>/i.test(combined)) {
    addIcon({ id: 'plus', roles: ['card_affordance', 'disclosure_marker'], reason: 'Stage A uses plus card markers.' });
  }
  if (/\bmarquee\b/i.test(combined)) {
    addIcon({ id: 'arrow-right', roles: ['motion_affordance', 'marquee_context'], reason: 'Stage A has marquee/motion rows that may need directional affordances.' });
  }
  if (/\bnav\b|\bheader\b|\bmenu\b/i.test(combined)) {
    addIcon({ id: 'menu-2', roles: ['mobile_navigation'], reason: 'Header/nav conversion may need a mobile menu icon.' });
    addIcon({ id: 'x', roles: ['mobile_navigation'], reason: 'Header/nav conversion may need a close icon.' });
  }

  for (const icon of [
    { id: 'circle-check', roles: ['list_marker', 'proof_marker'], reason: 'Reusable semantic proof/check marker.' },
    { id: 'sparkles', roles: ['feature_marker', 'creative_marker'], reason: 'Reusable feature marker for editorial/product surfaces.' },
    { id: 'external-link', roles: ['external_link'], reason: 'Reusable external-link affordance.' },
    { id: 'chevron-right', roles: ['inline_link', 'card_affordance'], reason: 'Reusable compact directional affordance.' },
  ]) {
    addIcon(icon);
  }

  const iconSetsById = new Map();
  for (const icon of detected.values()) {
    const set = iconSetsById.get(icon.setId) || {
      setId: icon.setId,
      name: icon.setId === 'tabler-filled' ? 'Tabler Icons Filled' : 'Tabler Icons Outline',
      library: 'Tabler Icons',
      variant: icon.variant,
      provider: 'pixflow_icon_sets',
      installAction: 'install_before_stage_b_insert',
      installTool: 'pixflow.icon_sets.install_subset',
      icons: [],
    };
    set.icons.push(icon);
    iconSetsById.set(icon.setId, set);
  }

  const iconSets = [...iconSetsById.values()].map((set) => ({
    ...set,
    icons: set.icons.sort((a, b) => a.id.localeCompare(b.id)),
    iconCount: set.icons.length,
  })).sort((a, b) => a.setId.localeCompare(b.setId));
  const systemIdentity = inferStageBColorSystemIdentity(stageAMetadata, title);

  return {
    type: 'pixflow_stage_b_icon_system',
    version: 1,
    source: 'stage_a_svg_and_semantic_affordance_scan',
    systemKey: systemIdentity.key,
    systemName: systemIdentity.name,
    generatedAt: new Date().toISOString(),
    sourceFiles: sources.map((source) => source.path),
    installStrategy: 'pixflow_icon_set_manager_before_bricks_insert',
    defaultSetId: 'tabler-outline',
    fallbackSetId: 'tabler-filled',
    modelContract: [
      'Use Pixflow-installed Tabler SVG icons instead of Bricks Font Awesome font icons for Stage B conversion.',
      'Copy stage-b-icon-system.json into bricks-result.json.stage_b_icon_system when any icon from this sidecar is used.',
      'Reference sidecar icons with settings.icon = { "library": "pixflowSvg", "icon": "pixflow:<setId>:<iconId>" }; Pixflow rewrites the placeholder to Bricks custom SVG icon controls during insertion.',
      'Use button icon/iconPosition for source CTA arrows, download actions, GitHub actions, and other obvious action affordances.',
      'Use standalone icon elements for feature/card/proof markers when the Stage A design used visual markers or would otherwise lose source affordance.',
      'Style standalone SVG icon elements through a global class settings.icon object: { "height": "2rem", "width": "2rem", "stroke": { "raw": "var(--accent)", "light": "#..." }, "strokeWidth": "2" }. Use fill for filled icons or deliberate fill/stroke special cases.',
      'Do not use iconSize or iconColor for Pixflow SVG icon styling; those controls are for regular font icons.',
      'Do not use Font Awesome libraries for Stage B page/content icons unless converting an existing WordPress/social icon that has no Tabler equivalent.',
      'Do not paste raw SVG code into Bricks code/html/custom CSS for icons.',
    ],
    iconSets,
    icons: iconSets.flatMap((set) => set.icons.map((icon) => ({
      ...icon,
      setId: set.setId,
      setName: set.name,
    }))),
    iconCount: iconSets.reduce((total, set) => total + set.icons.length, 0),
  };
}

function normalizeStageBIconId(value) {
  return firstString(value)
    .trim()
    .toLowerCase()
    .replace(/_/g, '-')
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function buildStageBIconPlaceholder(setId, iconId) {
  return `pixflow:${firstString(setId, 'tabler-outline')}:${normalizeStageBIconId(iconId)}`;
}

function titleCaseFromSlug(value) {
  return firstString(value)
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

function sortNumericStrings(a, b) {
  const left = Number.parseInt(a, 10);
  const right = Number.parseInt(b, 10);
  if (Number.isFinite(left) && Number.isFinite(right)) return left - right;
  return String(a).localeCompare(String(b));
}

function inferStageBColorSystemIdentity(stageAMetadata, fallbackTitle) {
  const system = firstPlainObject(
    stageAMetadata?.selectedPixflowDesignSystem,
    stageAMetadata?.selected_pixflow_design_system,
    stageAMetadata?.pixflowDesignSystem,
    stageAMetadata?.pixflow_design_system
  );
  const key = normalizeKey(firstString(
    system.key,
    system.slug,
    system.id,
    system.path,
    system.resourceDir,
    system.resource_dir,
    fallbackTitle,
    'pixflow-stage-b'
  ));
  const name = firstString(
    system.label,
    system.title,
    system.name,
    fallbackTitle,
    'Pixflow Stage B'
  );

  return {
    key: key || slugify(name),
    name,
  };
}

function extractCssVariableDeclarations(cssText) {
  const tokens = [];
  const seen = new Set();
  const pattern = /(--[A-Za-z][A-Za-z0-9_-]*)\s*:\s*([^;{}]+);/g;
  let match;
  while ((match = pattern.exec(String(cssText || ''))) !== null) {
    const name = match[1].trim();
    const value = normalizeCssDeclarationValue(match[2]);
    if (!name || !value || seen.has(name)) {
      continue;
    }
    seen.add(name);
    tokens.push({ name, value });
  }
  return tokens;
}

function normalizeCssDeclarationValue(value) {
  return String(value || '')
    .replace(/\s+/g, ' ')
    .trim();
}

function isBricksPaletteColorValue(value) {
  const color = String(value || '').trim();
  return /^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(color)
    || /^(?:rgb|rgba|hsl|hsla|oklch|oklab)\(/i.test(color);
}

function deterministicBricksId(seed) {
  const hash = createHash('sha256').update(String(seed || 'pixflow')).digest('hex');
  let id = '';
  for (let index = 0; index < 6; index += 1) {
    id += String.fromCharCode(97 + (parseInt(hash.slice(index * 2, index * 2 + 2), 16) % 26));
  }
  return id;
}

function renderStageBInstructions(metadata) {
  const lines = [];
  lines.push('# Pixflow Design Local CLI Stage B');
  lines.push('');
  lines.push('You are running Pixflow Design Stage B. Stage A is already accepted. Your job is to convert the accepted Pixflow Design-quality HTML artifact into editable Bricks JSON while preserving the design intent.');
  lines.push('');
  lines.push('## Hard Boundary');
  lines.push('- Stage B may use Pixflow/Bricks MCP references and Bricks skills. Stage A Pixflow Design skills are read-only source evidence.');
  lines.push('- Do not redesign the artifact. Preserve the Stage A composition, hierarchy, section order, visual density, media roles, and responsive rhythm as closely as Bricks permits.');
  lines.push('- Do not output raw HTML, raw inline SVG markup, script tags, imported CSS, or a WordPress page. The final deliverable is editable Bricks JSON.');
  lines.push('- If Stage A used safe interaction polish such as `data-reveal` plus IntersectionObserver, preserve the needed `data-*` attributes and place source JavaScript in `bricks-result.json.page_settings.customScriptsBodyFooter` as a complete `<script>...</script>` block. Do not use Bricks `code` elements for Stage B JavaScript.');
  lines.push('');
  lines.push('## Files To Read First');
  lines.push('- `stage-a/drafts/index.html`: canonical accepted Stage A artifact.');
  lines.push('- `stage-a/drafts/assets/` and `stage-a/screenshots/` when present: accepted media slots and visual QA references.');
  lines.push('- `stage-a/prompt.md`, `stage-a/brief.md`, `stage-a/composition-dna.md`, `stage-a/stage-a-self-critique.md`, and `stage-a/stage-a-qa.json`: source intent and quality notes.');
  lines.push('- `stage-a/design-system.md`, `stage-a/tokens.css`, `stage-a/components-manifest.md`, and `stage-a/components.html` when present: Pixflow Design design-system evidence copied from Stage A.');
  lines.push('- `bricks-baseline-result.json`, `bricks-baseline-payload.json`, `bricks-baseline-header-payload.json`, `bricks-baseline-footer-payload.json`, `bricks-baseline-global-classes.json`, and `stage-b-baseline-report.md` when present: Pixflow clean-room HTML-to-Bricks baseline. Treat this as the primary starting payload, not as disposable sample output.');
  lines.push('- `stage-b-route-contract.json`: active Pixflow route, variable authority, palette policy, route rewrite policy, and forbidden output.');
  lines.push('- `stage-b-theme-style-contract.json`: whether Stage B may lean on Bricks theme-style defaults or must emit explicit page-scoped defaults.');
  lines.push('- `stage-b-theme-style-health.json`: deterministic health check for current Bricks theme-style essentials and any user-question flow.');
  lines.push('- `stage-b-color-system.json`: Pixflow preflight colour variables and Bricks palette entries extracted from Stage A tokens, named after the selected Pixflow Design design system when one exists.');
  lines.push('- `stage-b-font-system.json`: Pixflow preflight font roles, Google Font install requests, and Bricks font usage rules extracted from Stage A imports and font tokens.');
  lines.push('- `stage-b-icon-system.json`: Pixflow preflight icon set requests, Tabler SVG icon placeholders, and Bricks icon usage rules extracted from Stage A SVG/action/navigation affordances.');
  lines.push('- `stage-b-source-map.json`: deterministic source inventory for sections, headings, text, CTAs, media, assets, scripts, classes, and `data-od-id` traceability.');
  lines.push('- `stage-b-style-map.json`: deterministic CSS rule, token, media-query, pseudo-selector, and class-bucket inventory.');
  lines.push('- `stage-b-section-map.json`: section-by-section Bricks mapping plan derived from the accepted artifact.');
  lines.push('- `stage-b-header-plan.json`: header detection, user include/scope choice, page-section filtering, and Bricks header-template assignment plan.');
  lines.push('- `stage-b-footer-plan.json`: footer detection, user include/scope choice, page-section filtering, and Bricks footer-template assignment plan.');
  lines.push('- `stage-b-class-plan.json`: global-class ownership plan and custom-CSS policy.');
  lines.push('- `stage-b-fidelity-plan.md`: readable preservation notes and conversion risks.');
  lines.push('- `stage-b-conversion-plan.json`: bounded final section, asset, map, and token plan generated before the model pass. Use the Stage B maps first; do not run broad exploratory scans unless those files are missing.');
  lines.push('- `pixflow-bricks-mcp.md`: Pixflow Bricks MCP element/settings/global-class contract.');
  lines.push('- `pixflow-plugin-mcp.md`: Pixflow Plugin MCP route, token, class, media, and framework rules.');
  lines.push('- `.pixflow-skills/bricks-web-prototype/SKILL.md` and its references.');
  lines.push('- `TODO.md`: update this as the live Stage B progress ledger.');
  lines.push('');
  lines.push('## Baseline-First Workflow');
  lines.push('- If the `bricks-baseline-*` files exist, start by copying their element trees and global classes into the final output files, then make targeted improvements. Do not rebuild the page from scratch unless the baseline is missing or structurally invalid.');
  lines.push('- The baseline already preserves Stage A DOM order, source classes as Bricks global classes, data/aria/id attributes, safe JavaScript in Bricks page settings, images, header/footer extraction, font/icon/color sidecar intent, and simple responsive `@media (max-width)` rules as Bricks breakpoint settings.');
  lines.push('- Your job is to audit and refine the baseline: fix semantic element choices, improve editable Bricks settings where the source clearly needs them, repair missing craft details, and keep sidecar contracts synchronized.');
  lines.push('- Preserve baseline ids, parent/child links, class ids, `_attributes`, responsive suffixed settings, image refs, and page settings unless a local QA issue or source comparison proves they are wrong.');
  lines.push('- Preserve semantic section roles from Stage A/source maps without inventing them. Add hero trace attributes only when the source, source map, section map, classes, id, or `data-od-id` explicitly identify the section as a hero/masthead; do not infer hero from "first section" alone.');
  lines.push('- If Stage A declares a tab/card control through classes, labels, comments, active states, or ARIA but omits JavaScript, do not leave it as a dead static grid. Build native Bricks tab structure when practical, or add minimal page-settings JavaScript that switches the existing editable content without using Bricks `code` elements.');
  lines.push('- Do not spend time translating every remaining CSS selector into Bricks controls. Move only high-value routine layout/spacing/type/radius/media settings into Bricks settings when it improves editability or frontend fidelity.');
  lines.push('- Do not remove `_cssCustom` that carries source-only effects, reveal behavior, marquee keyframes, collage details, or other CSS Bricks controls cannot express.');
  lines.push('- Prefer editable Bricks child elements for visible pseudo-element dividers/marks. Avoid `%root%::before`/`%root%::after` unless the source effect cannot be represented structurally and is not a token bucket or page-wide overlay.');
  lines.push('- Cleanup priority: schema validity, sidecar copies, header/footer separation, route/theme-style compliance, source-accurate responsive layout, real Bricks palette/font/icon contracts, then visual fidelity details such as radius, row flex, marquee rhythm, icons, and stat rings.');
  lines.push('- If the baseline and Stage A disagree, Stage A is authoritative. Record any deliberate baseline correction in `conversion-report.md`.');
  lines.push('');
  lines.push('## Required Output');
  lines.push('- `bricks-result.json`: complete Direct Page Generation-style result, including `page_settings`/`stage_b_page_settings` when Stage A source JavaScript exists or when Stage A clearly declares an interactive control that must not be static.');
  lines.push('- `bricks-payload.json`: the `content` array from `bricks-result.json`.');
  lines.push('- `bricks-header-payload.json`: the `stage_b_header.content` array when `stage-b-header-plan.json.includeHeader` is true, otherwise an empty array.');
  lines.push('- `bricks-footer-payload.json`: the `stage_b_footer.content` array when `stage-b-footer-plan.json.includeFooter` is true, otherwise an empty array.');
  lines.push('- `global-classes.json`: the `global_classes` array from `bricks-result.json`.');
  lines.push('- `color-system-usage.json`: short note listing the Stage A tokens used and whether any colour had to fall back to a raw value.');
  lines.push('- `conversion-report.md`: section-by-section mapping notes, limitations, and preservation risks.');
  lines.push('- Write all JSON outputs as UTF-8 without BOM. Sidecar arrays must exactly mirror the corresponding arrays in `bricks-result.json`.');
  lines.push('- Copy `stage-b-route-contract.json`, `stage-b-theme-style-contract.json`, and `stage-b-theme-style-health.json` into `bricks-result.json` as `stage_b_route_contract`, `stage_b_theme_style_contract`, and `stage_b_theme_style_health`.');
  lines.push('- Copy `stage-b-color-system.json` into `bricks-result.json.stage_b_color_system`; Pixflow uses it to check for an existing native Bricks scheme/category, then write missing variables and palette colours before insertion.');
  lines.push('- Copy `stage-b-font-system.json` into `bricks-result.json.stage_b_font_system`; Pixflow uses it to install Google fonts into Bricks custom fonts before insertion and to verify no frontend font imports were emitted.');
  lines.push('- Copy `stage-b-icon-system.json` into `bricks-result.json.stage_b_icon_system` when using any sidecar icon; Pixflow uses it to build/install the Tabler SVG subset before insertion and to rewrite placeholders to Bricks SVG attachments.');
  lines.push('');
  lines.push('## `bricks-result.json` Shape');
  lines.push('Use this top-level shape exactly enough for Pixflow to inspect locally:');
  lines.push('```json');
  lines.push(JSON.stringify({
    type: 'direct_page_generation',
    generation_mode: 'direct_page',
    source_request_id: metadata.sourceId,
    prompt: 'source prompt text',
    page_title: metadata.title,
    page_goal: 'preserve accepted Stage A artifact in editable Bricks',
    plan: {},
    section_specs: [],
    section_count: 0,
    stage_b_header: {
      type: 'pixflow_stage_b_header_template',
      includeHeader: false,
      scope: 'current_page',
      templateType: 'header',
      templateTitle: `${metadata.title} Header`,
      content: [],
    },
    stage_b_footer: {
      type: 'pixflow_stage_b_footer_template',
      includeFooter: false,
      scope: 'current_page',
      templateType: 'footer',
      templateTitle: `${metadata.title} Footer`,
      content: [],
    },
    payload_included: true,
    payload_status: 'insertable_with_payload',
    payload_format: 'bricks_json',
    payload_source: 'pixflow_cli_stage_b',
    content: [],
    global_classes: [],
    stage_b_color_system: {
      type: 'pixflow_stage_b_color_system',
      variableCategory: {},
      variables: [],
      palette: {},
    },
    stage_b_font_system: {
      type: 'pixflow_stage_b_font_system',
      fonts: [],
      roleTokens: [],
      installStrategy: 'pixflow_google_font_manager_before_bricks_insert',
    },
    stage_b_icon_system: {
      type: 'pixflow_stage_b_icon_system',
      iconSets: [],
      icons: [],
      installStrategy: 'pixflow_icon_set_manager_before_bricks_insert',
    },
    stage_b_route_contract: {
      type: 'pixflow_stage_b_route_contract',
      routeId: 'pixflow-native-bricks',
      styleMode: 'pixflow_framework',
    },
    stage_b_theme_style_contract: {
      type: 'pixflow_stage_b_theme_style_contract',
      safeToLeanOnThemeStyles: false,
      mustEmitExplicit: [],
    },
    stage_b_theme_style_health: {
      type: 'pixflow_stage_b_theme_style_health',
      status: 'unknown',
    },
    classes_included: true,
    classes_status: 'generated_bem_classes_included',
    components: [],
    components_included: false,
    components_status: 'components_missing',
    diagnostics: {
      direct_generation_path: 'pixflow_design_artifact_to_bricks_cli',
    },
  }, null, 2));
  lines.push('```');
  lines.push('');
  lines.push('## Pixflow Bricks Build Order');
  lines.push('- Treat Stage B as a compiler/QA/repair pass, not a redesign pass.');
  lines.push('- When the clean-room baseline files exist, begin from `bricks-baseline-result.json` and refine it. The model pass should be a bounded cleanup pass over a strong compiler baseline, not a long full-page authoring pass.');
  lines.push('- First inspect `stage-b-route-contract.json`, `stage-b-theme-style-contract.json`, `stage-b-theme-style-health.json`, `stage-b-font-system.json`, and `stage-b-icon-system.json`, then consume Bricks setup, variables, fonts, icons, global classes, and color palettes. Reuse existing style primitives before creating new ones.');
  lines.push('- Create normal page content separately from header/footer template content. Never set a template type on a normal page.');
  lines.push('- For page-only headers, the page must exist before Pixflow attaches the header template condition to that page id.');
  lines.push('- Run local QA before import. Repair the smallest failing slice by element id, class id, or header template payload instead of regenerating the whole page.');
  lines.push('');
  lines.push('## Bricks Element Contract');
  lines.push('- Allowed element names: `section`, `container`, `div`, `block`, `heading`, `text-basic`, `text`, `text-link`, `button`, `image`, `icon`, `svg`, `nav-menu`, `divider`, `video`.');
  lines.push('- Every element requires `id`, `name`, `settings`, and `children`.');
  lines.push('- Use `parent` for non-root elements. Root `section` elements should have no parent or an empty parent.');
  lines.push('- `children` must reference real child ids.');
  lines.push('- Use `_cssGlobalClasses` arrays containing generated global class IDs, not class names.');
  lines.push('- `_cssGlobalClasses` must be a flat string array. Object entries can break Bricks.');
  lines.push('- Do not place routine style keys directly on Stage B elements as ID-level styling. Put source layout, spacing, typography, background, border, radius, and responsive controls in global classes; element settings are for structure, content, links, attributes, semantic tags, and class references unless a Bricks control has no class-level equivalent.');
  lines.push('- Preserve Stage A runtime `data-*`, `aria-*`, and anchor `id` attributes with Bricks `_attributes`, for example `_attributes: [{ "id": "abcxyz", "name": "data-reveal" }]` or `_attributes: [{ "id": "defuvw", "name": "id", "value": "about" }]`.');
  lines.push('- Do not set Bricks `_cssId` during Stage B. Source anchor IDs belong in `_attributes`, not the Bricks ID option.');
  lines.push('- Attribute IDs must be stable short IDs. Do not include copied-element metadata such as `source`, `sourceUrl`, or `version`; Bricks adds those when copying elements.');
  lines.push('- Global classes require `id`, `name`, and `settings`.');
  lines.push('- Use Bricks underscore settings such as `_display`, `_direction`, `_flexWrap`, `_rowGap`, `_gridTemplateColumns`, `_background`, `_typography`, `_border`, `_padding`, `_margin`, `_aspectRatio`, `_objectFit`, `_width`, `_widthMin`, `_widthMax`, `_height`, `_heightMin`, and `_heightMax`.');
  lines.push('- Number/unit controls are scalar strings such as `"24px"` or `"clamp(24px, 4vw, 64px)"`, not `{ "value": 24, "unit": "px" }` objects.');
  lines.push('- Typography values belong under `_typography`. Do not put `fontSize`, `font-family`, `fontWeight`, `lineHeight`, `letterSpacing`, or root `color` at element settings root.');
  lines.push('- Heading elements must set the semantic HTML tag with `settings.tag` (`h1`-`h6`). Do not use `tagName`; Bricks ignores it and falls back to its default heading tag.');
  lines.push('- Button and link settings must use valid Bricks link shapes. Plain external URLs use `{ "type": "external", "url": "https://..." }`; do not use `type: "url"`.');
  lines.push('- Flex settings only count when `_display` is `flex` or `inline-flex` on that same element. Grid settings only count when `_display` is `grid` on that same element.');
  lines.push('- Multi-column grids must include Bricks responsive `_gridTemplateColumns:tablet_portrait` or `_gridTemplateColumns:mobile_portrait` overrides. Do not rely only on `_cssCustom` media queries for mobile column collapse.');
  lines.push('- Use `nav-menu` for real Bricks/WordPress navigation menus when a menu source is available. Keep CTA actions as `button` elements; do not turn every header action into a nav-menu item.');
  lines.push('- CSS variable colours must use tokens from `stage-b-color-system.json` as `{ "raw": "var(--token)" }` objects in Bricks settings.');
  lines.push('- Bricks palette entries for Stage B design systems must be real Bricks color rows with `raw: "var(--token)"`, a matching token `name`, and a literal hex/rgb/oklch `light` fallback so the Style Manager labels the token and the frontend resolves the color.');
  lines.push('- Fonts from `stage-b-font-system.json` must be represented as Bricks typography settings and copied into `bricks-result.json.stage_b_font_system`. Do not import Google Fonts in `_cssCustom` or code elements.');
  lines.push('- Icons from `stage-b-icon-system.json` must be represented as Pixflow Tabler SVG placeholders and copied into `bricks-result.json.stage_b_icon_system`. Do not use Bricks Font Awesome font icon classes for Stage B page icons.');
  lines.push('- Button icons use `settings.icon: { "library": "pixflowSvg", "icon": "pixflow:tabler-outline:arrow-up-right" }` plus `iconPosition: "left"` or `"right"`. Pixflow rewrites this placeholder to the installed Bricks custom SVG icon control during insertion.');
  lines.push('- Standalone icons use the Bricks `icon` element with the same `settings.icon` placeholder. Use the Bricks `svg` element only when the source calls for an SVG media/control element, with `source: "iconSet"` and `iconSet` using the same placeholder shape.');
  lines.push('- Bricks styles custom SVG icons differently from regular font icons. For standalone SVG `icon` elements, use a global class with nested `settings.icon`, for example `{ "icon": { "height": "2rem", "width": "2rem", "stroke": { "raw": "var(--accent)", "light": "#ef6b4d" }, "strokeWidth": "2" } }`. Use `fill` instead of `stroke` for filled icons, or both for deliberate fill/stroke special cases.');
  lines.push('- Do not use `iconSize` or `iconColor` for Pixflow SVG icon classes/elements. Those are regular font icon controls and can fail to style custom SVG icons correctly on the frontend.');
  lines.push('- Use `tabler-outline` by default. Use `tabler-filled` only when Stage A clearly needs a filled icon. Do not paste raw `<svg>` icon markup into `code`, text, or custom CSS.');
  lines.push('- Preserve visible border radius/corner rhythm with `_border.radius`, Pixflow radius variables, or source-scoped class settings. Do not drop rounded cards, buttons, media, pills, or badges.');
  lines.push('- Any horizontal row wrapper, action group, nav fallback, marquee track, or card action row must set `_display: "flex"` and `_direction: "row"` on the same element/class. Add `_flexWrap: "wrap"` when Stage A allows wrapping.');
  lines.push('- Preserve marquee-like rows as repeated editable Bricks items with the same visual rhythm and direction. Do not collapse the row into a malformed text block.');
  lines.push('- Preserve declared tab/card interfaces as working controls. Use Bricks-native tabs where the structure maps cleanly; otherwise keep the editable card/panel structure and place a minimal switching script in page settings.');
  lines.push('- If `stage-b-theme-style-contract.json.safeToLeanOnThemeStyles` is true, do not duplicate routine section padding, container gutters/max width, body/headings, buttons, forms, or dividers unless the local design needs an intentional override.');
  lines.push('- If `stage-b-theme-style-contract.json.safeToLeanOnThemeStyles` is false, emit explicit page-scoped section/container/button/form/divider baselines through Bricks settings and generated global classes.');
  lines.push('- For non-Pixflow routes, do not create or mutate Bricks theme styles unless the preflight question flow records explicit user approval and scope.');
  lines.push('- Do not create a root/global class whose purpose is to declare `--od-*` or other colour tokens. Pixflow checks for the existing native Bricks colour scheme by deterministic design-system ID, then writes missing variables/palette colours before insertion.');
  lines.push('- Do not add an `.od-root`, `*-root`, or all-sections wrapper class. Preserve section classes only when they represent visible Stage A structure.');
  lines.push('- `_cssCustom` must contain complete selector blocks using `%root%`.');
  lines.push('- Use `_cssCustom` only for details that Bricks settings cannot represent, not routine layout/spacing/type/background.');
  lines.push('- Do not use `code` elements for Stage B JavaScript. Put safe source JavaScript in `page_settings.customScriptsBodyFooter` and copy the same object to `stage_b_page_settings`.');
  lines.push('- When adding missing interaction for an explicit Stage A affordance such as a tab-like card grid with `.active` state, the script must be scoped to the converted section, preserve keyboard access where practical, and target stable classes/attributes from the Bricks payload.');
  lines.push('- If `stage-b-header-plan.json.includeHeader` is true, emit the source header as `stage_b_header.content` and write the same array to `bricks-header-payload.json`. Do not duplicate that header in page `content`.');
  lines.push('- When an included header has source-backed auxiliary bands such as rails or a topbar, keep them only if they exist in Stage A, but the approved header section from `stage-b-header-plan.json.selectedSectionOdId` must remain present and must be the section whose inner wrapper/nav/action controls satisfy the header layout contract.');
  lines.push('- Header template root sections must explicitly set source-accurate compact top/bottom padding on the element or its global class. Do not let Pixflow Framework page section padding inflate topbar/nav/header bands.');
  lines.push('- If `stage-b-header-plan.json.includeHeader` is false, omit the detected header from page `content`; the user has not approved a header template.');
  lines.push('- If `stage-b-footer-plan.json.includeFooter` is true, emit the source footer as `stage_b_footer.content` and write the same array to `bricks-footer-payload.json`. Do not duplicate that footer in page `content`.');
  lines.push('- Footer template root sections must explicitly set source-accurate top/bottom padding on the element or its global class instead of inheriting generic page section padding.');
  lines.push('- If `stage-b-footer-plan.json.includeFooter` is false, omit the detected footer from page `content`; the user has not approved a footer template.');
  lines.push('- Header/footer areas must be Bricks templates, not normal page content. Header template elements are written to the Bricks header area and footer template elements are written to the Bricks footer area by Pixflow during insertion.');
  lines.push('- Included headers must have explicit Bricks layout controls on the real wrapper elements, not only CSS: the inner wrapper needs `_display: "flex"`, `_direction: "row"`, alignment, justification, and gaps; fallback nav/action blocks need `_display: "flex"`, `_direction: "row"`, `_flexWrap: "wrap"`, alignment, justification, and gaps.');
  lines.push('- Header and footer templates need Bricks template conditions. Sitewide is `[{ "main": "any" }]`; current-page-only is `[{ "main": "ids", "ids": [pageId], "idsIncludeChildren": false }]` after the page exists.');
  lines.push('- If Stage A has stat rings, build them as separate editable elements: a circular number element with the 2px ring, then a separate label/text element. Do not put a dashed border on the whole stat text.');
  lines.push('- If Stage A has plate/image wrappers, match the original wrapper treatment exactly. Do not add a solid wrapper border unless it exists in Stage A.');
  lines.push('- Keep dynamic data tokens only when they are known valid Bricks tokens. Unknown `{tokens}` render literally and must not be guessed.');
  lines.push('');
  lines.push('## Quality Bar');
  lines.push('- Preserve every major Stage A section as an editable Bricks section with matching rhythm and visual role, including explicit hero trace attributes only when Stage A/source maps identify the section as the page hero.');
  lines.push('- Build enough global classes to preserve the craft layer without turning every element into custom CSS.');
  lines.push('- Keep text editable in `heading` and `text-basic` elements.');
  lines.push('- Use `image` elements for real visual roles when the Stage A artifact has clear media slots. Use honest placeholders only when no usable asset is available.');
  lines.push('- Avoid adjacent repeated layout families; mirror the Stage A section variety.');
  lines.push('- Before finishing, compare the JSON against the Stage A artifact and repair missing sections, weak lower sections, broken hierarchy, invalid child links, unsupported elements, missing classes, source-declared hero sections missing trace attributes, invented hero labels, or dead interactive controls.');
  lines.push('');
  lines.push('## Final Response');
  lines.push(`After creating the required files, summarize the Stage B conversion for ${metadata.title}.`);
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function renderStageBRunnerPrompt(metadata) {
  return [
    'Read AGENTS.md first, then execute TODO.md exactly.',
    'Use this filesystem workspace as the complete source of truth for Pixflow Design Stage B.',
    'If bricks-baseline-result.json exists, treat it as the initial Bricks payload and perform a focused cleanup/refinement pass. Do not regenerate the page from scratch.',
    'Keep inspection bounded. Do not print or dump full JSON maps, full CSS text, full HTML, full skill files, or full Bricks payloads to the terminal. Inspect compact summaries, known keys, and targeted snippets only.',
    'Do not run broad custom scripts that echo large fields such as styles.cssText, complete element trees, or entire global class arrays. If a script is needed, cap output to concise counts, ids, and concrete gaps.',
    'Start from stage-b-route-contract.json, stage-b-theme-style-contract.json, stage-b-theme-style-health.json, stage-b-font-system.json, stage-b-icon-system.json, stage-b-source-map.json, stage-b-style-map.json, stage-b-section-map.json, stage-b-header-plan.json, stage-b-footer-plan.json, stage-b-class-plan.json, and stage-b-fidelity-plan.md before rereading the full Stage A HTML.',
    'Convert or refine the accepted Stage A HTML artifact into editable Bricks JSON using the Pixflow baseline, Stage B maps, Pixflow/Bricks MCP, and the staged Bricks skill pack.',
    'Do not redesign Stage A. Preserve its section order, composition DNA, typography rhythm, media roles, and lower-section quality.',
    'Preserve baseline ids, class ids, attributes, responsive breakpoint settings, image refs, and page settings unless source comparison or local QA shows a concrete error.',
    'If a header is included, give it the same attention as page sections: write it to stage_b_header.content, use nav-menu for real menu navigation when available, and set explicit Bricks layout controls on wrapper/action elements.',
    'For included headers, preserve source-backed auxiliary bands such as rails/topbar only when Stage A has them, but validate and repair the approved source header section from stage-b-header-plan.json.selectedSectionOdId as the actual nav/header wrapper.',
    'For included headers, top-level template section elements must explicitly set compact source-accurate top/bottom padding so site page-section theme styles do not create blank header bands.',
    'If a footer is included, give it the same attention as page sections: write it to stage_b_footer.content and preserve footer links, brand/copyright text, and closing rhythm.',
    'For included footers, top-level template section elements must explicitly set source-accurate top/bottom padding rather than inheriting generic page section padding.',
    'Write bricks-result.json, bricks-payload.json, bricks-header-payload.json, bricks-footer-payload.json, global-classes.json, and conversion-report.md.',
    'Write JSON as UTF-8 without BOM. Keep bricks-payload.json, bricks-header-payload.json, bricks-footer-payload.json, and global-classes.json as exact mirrors of the corresponding arrays inside bricks-result.json.',
    'Put routine style controls in global classes rather than direct element/ID settings. Direct element settings are for content, semantic tags, links, attributes, structure, and class references unless a Bricks control has no class-level equivalent.',
    'Do not create raw HTML as the final deliverable. Do not use unsupported Bricks elements, script tags in text/code elements, imported CSS, raw inline SVG markup, Font Awesome page icons, Bricks code elements, or `_cssId` values. Put safe Stage A JavaScript and required source-declared interaction scripts in page settings.',
    `Finish only when ${metadata.title} is ready for Pixflow Bricks payload inspection.`,
    '',
  ].join('\n');
}

function renderStageBTodo(metadata) {
  const lines = [];
  lines.push(`# Stage B TODO: ${metadata.title}`);
  lines.push('');
  lines.push('- [ ] Read `stage-a/drafts/index.html` as the canonical accepted creative artifact.');
  lines.push('- [ ] Inspect `stage-a/drafts/assets/` and `stage-a/screenshots/` when present so media slots are mapped with the same roles as Stage A.');
  lines.push('- [ ] Read `stage-a/prompt.md`, `stage-a/brief.md`, `stage-a/composition-dna.md`, `stage-a/stage-a-self-critique.md`, and `stage-a/stage-a-qa.json`.');
  lines.push('- [ ] Read `stage-a/design-system.md`, `stage-a/tokens.css`, `stage-a/components-manifest.md`, and `stage-a/components.html` when present.');
  lines.push('- [ ] If present, read `bricks-baseline-result.json`, `bricks-baseline-payload.json`, `bricks-baseline-header-payload.json`, `bricks-baseline-footer-payload.json`, `bricks-baseline-global-classes.json`, and `stage-b-baseline-report.md`; use them as the starting payload and preserve what they already map correctly.');
  lines.push('- [ ] Read `stage-b-route-contract.json`, `stage-b-theme-style-contract.json`, and `stage-b-theme-style-health.json` before authoring any Bricks settings or global classes.');
  lines.push('- [ ] Read `stage-b-color-system.json`; use these tokens in Bricks colour objects and do not create `.od-root` token CSS.');
  lines.push('- [ ] Read `stage-b-font-system.json`; preserve Stage A font roles, use installed/available Bricks fonts, and do not emit Google font imports.');
  lines.push('- [ ] Read `stage-b-icon-system.json`; preserve Stage A action/navigation/card/proof affordances with Pixflow Tabler SVG placeholders and do not use Font Awesome page icons.');
  lines.push('- [ ] Read `stage-b-source-map.json`, `stage-b-style-map.json`, `stage-b-section-map.json`, `stage-b-header-plan.json`, `stage-b-footer-plan.json`, `stage-b-class-plan.json`, and `stage-b-fidelity-plan.md` before broad HTML/CSS inspection.');
  lines.push('- [ ] Read `stage-b-conversion-plan.json`; use it as the bounded section and asset map before writing any payload.');
  lines.push('- [ ] Read `pixflow-bricks-mcp.md` and `pixflow-plugin-mcp.md` before writing any JSON.');
  lines.push('- [ ] Read `.pixflow-skills/bricks-web-prototype/SKILL.md`, `checklist.md`, `layouts.json`, and `references/`.');
  lines.push('- [ ] Keep file inspection compact: do not print full JSON maps, full CSS text, full HTML, full skill files, or full Bricks payloads. Use targeted snippets and concise counts only.');
  lines.push('- [ ] Do not run broad scripts that echo `styles.cssText`, complete element trees, full global-class arrays, or other large fields. If scripting is needed, cap output to concrete ids, counts, and gaps.');
  lines.push('- [ ] Compare the baseline against Stage A and Stage B maps. List only concrete gaps that need targeted cleanup; do not restart from blank when the baseline is valid.');
  lines.push('- [ ] Preserve baseline global classes and Bricks setting ownership before writing targeted element/class edits.');
  lines.push('- [ ] Write `bricks-result.json` as a Direct Page Generation-style result.');
  lines.push('- [ ] Include `stage_b_color_system` in `bricks-result.json` by copying `stage-b-color-system.json`.');
  lines.push('- [ ] Include `stage_b_font_system` in `bricks-result.json` by copying `stage-b-font-system.json`.');
  lines.push('- [ ] Include `stage_b_icon_system` in `bricks-result.json` by copying `stage-b-icon-system.json` when any sidecar icon is used.');
  lines.push('- [ ] Include `stage_b_route_contract`, `stage_b_theme_style_contract`, and `stage_b_theme_style_health` in `bricks-result.json` by copying the Stage B contract files.');
  lines.push('- [ ] If `stage-b-header-plan.json.includeHeader` is true, write header elements to `bricks-result.json.stage_b_header.content` and `bricks-header-payload.json`; otherwise keep `bricks-header-payload.json` as an empty array.');
  lines.push('- [ ] If a header is included, use `nav-menu` for real menu navigation when available, keep CTA actions separate, and set explicit Bricks layout controls on the header inner wrapper and any fallback nav/action block: `_display`, `_direction`, `_flexWrap` where wrapping is needed, alignment, justification, and gaps.');
  lines.push('- [ ] If Stage A has header-adjacent rails/topbar, keep them source-backed and separate from the approved nav/header section; do not let those auxiliary bands replace the selected header section from `stage-b-header-plan.json.selectedSectionOdId`.');
  lines.push('- [ ] If `stage-b-footer-plan.json.includeFooter` is true, write footer elements to `bricks-result.json.stage_b_footer.content` and `bricks-footer-payload.json`; otherwise keep `bricks-footer-payload.json` as an empty array.');
  lines.push('- [ ] Write `bricks-payload.json` from `bricks-result.json.content`.');
  lines.push('- [ ] Write `global-classes.json` from `bricks-result.json.global_classes`.');
  lines.push('- [ ] Write `color-system-usage.json` summarizing which Stage B colour-system tokens were consumed.');
  lines.push('- [ ] Write `conversion-report.md` with mapping notes and any interaction/media limitations.');
  lines.push('- [ ] Self-check allowed elements, `_attributes`, page settings for source JavaScript/declared interaction, absence of code elements and `_cssId`, parent/child links, class ID references, token color objects, source radius, row flex directions, malformed marquees, missing button/card/proof icons, missing stat-ring structure, source-declared hero trace attributes, no invented hero labels, dead tab/card controls, unsupported `.od-root`, and unsupported raw HTML/script/SVG.');
  lines.push('- [ ] Repair any missing sections or Bricks contract violations before finishing.');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function renderPixflowBricksMcpMarkdown() {
  return `# Pixflow Bricks MCP

Built-in Bricks schema, validation, variables, global classes, media, and compiler capabilities used by Pixflow Design.

## Active Tools

- bricks.reference.compact
- bricks.payload.validate
- bricks.payload.inspect
- bricks.media.selected_assets
- bricks.classes.global
- bricks.tokens.pixflow
- pixflow.google_fonts.install
- pixflow.icon_sets.install_subset

## Stage B Baseline Workflow

- If \`bricks-baseline-result.json\` exists, treat it as the initial editable Bricks payload.
- The Pixflow clean-room baseline preserves source DOM order, global class ids, \`_attributes\`, image refs, Bricks page settings for safe Stage A JavaScript, header/footer extraction, and responsive breakpoint settings from simple \`@media (max-width)\` class rules.
- Model cleanup should be targeted: improve semantic Bricks elements, move high-value routine layout/style controls into Bricks settings, repair missing craft details, and keep sidecar contracts synchronized.
- Do not regenerate the entire page, remove baseline ids/classes, or flatten preserved responsive keys unless source comparison or local QA identifies a concrete problem.
- Preserve semantic section roles from Stage A/source maps without inventing them. Add hero trace attributes only when the source, source map, section map, classes, id, or \`data-od-id\` explicitly identify the section as a hero/masthead; do not infer hero from "first section" alone.
- If Stage A clearly declares an interactive tab/card affordance through classes, comments, active states, labels, or ARIA but omits source JavaScript, the conversion still needs working behavior. Prefer native Bricks tabs when the structure maps cleanly; otherwise keep the editable card/panel structure and add minimal scoped page-settings JavaScript.
- Keep \`_cssCustom\` when it carries source-only selectors/effects such as reveal CSS, keyframes, collage detail, or unsupported Bricks control behavior. Rebuild visible pseudo-element dividers/marks as child elements where practical.

## Supported Elements

- section
- container
- block
- div
- heading
- text-basic
- text
- text-link
- button
- image
- icon
- svg
- nav-menu
- divider
- video

## Class References

- _cssGlobalClasses must be an array of generated global class IDs.
- Short BEM class names remain human-readable, but elements reference class IDs in Bricks JSON.
- Runtime HTML attributes are represented with _attributes arrays, for example:
  - { "id": "abcxyz", "name": "data-reveal" }
  - { "id": "defuvw", "name": "data-reveal", "value": "true" }
- Do not include copied-element metadata such as source, sourceUrl, or version in model output.
- Use nav-menu for real Bricks/WordPress navigation menus when a menu source is available. Keep CTA buttons as button elements.

## Layout Controls

- Use Bricks underscore settings such as _display, _direction, _flexWrap, _rowGap, _gridTemplateColumns.
- Never emit raw unprefixed layout keys such as direction, flexWrap, or justifyContent.
- Flex controls require _display: "flex" or _display: "inline-flex" on the same element.
- Grid controls require _display: "grid" on the same element.

## Style Controls

- Bricks settings first: route visual style into element/global-class settings before using _cssCustom.
- Core supported setting keys include _background, _typography, _border, _padding, _margin, _display, _direction, _gridTemplateColumns, _columnGap, _rowGap, _overflow, _aspectRatio, _objectFit, _width, _widthMin, _widthMax, _height, _heightMin, and _heightMax.
- Number/unit controls are scalar strings like "24px", not { value, unit } objects.
- Typography belongs under _typography. Root font/color keys are ignored or unsafe.
- Plain external links use { "type": "external", "url": "https://..." }; do not use type: "url".
- section/container/block styles should use _background, _border, _padding, _display, _gridTemplateColumns, _overflow, and _aspectRatio for bands, panels, cards, mockups, collages, and product packs.
- heading/text-basic styles should use _typography colour/size/weight/line-height settings where the design system allows overrides.
- image styles should use _border, _aspectRatio, _objectFit, _overflow, width/height constraints, and media settings; do not hide media treatment only in CSS.

## Font Controls

- Stage B workspaces include \`stage-b-font-system.json\` when Stage A exposes Google Font imports or font role tokens.
- Preserve Stage A font roles: display/heading, body, mono/code, and serif/italic emphasis. Do not collapse all roles into the active theme body font when Stage A uses distinct families.
- Use Bricks typography settings for visible font choices: \`_typography: { "font-family": "Inter Tight" }\` or the installed Bricks custom font id when Pixflow supplies one.
- Pixflow installs Google Fonts through its Bricks custom font manager before Stage B insertion. Model output must copy \`stage-b-font-system.json\` to \`bricks-result.json.stage_b_font_system\`.
- Never emit Google font \`<link>\`, CSS \`@import\`, \`fonts.googleapis.com\`, \`fonts.gstatic.com\`, or ad hoc \`@font-face\` in Bricks payload CSS/code. Installed fonts are loaded by Bricks.
- For mixed sans/serif headlines, keep editable heading/text content and style inline \`em\` or span emphasis with scoped \`%root%\` CSS using the installed family name.
- If a Stage A font is proprietary or not available from Google/Bricks custom fonts, record the fallback in \`conversion-report.md\` instead of silently substituting a generic system stack.

## Icon Controls

- Stage B workspaces include \`stage-b-icon-system.json\` when Stage A exposes SVG icons, CTA arrows, download/GitHub actions, navigation affordances, or card/proof markers.
- Preserve Stage A icon affordances with Pixflow-installed Tabler SVG icons. Use \`tabler-outline\` by default and \`tabler-filled\` only when the source icon is clearly filled.
- Model output references sidecar icons with \`{ "library": "pixflowSvg", "icon": "pixflow:tabler-outline:arrow-up-right" }\`. Pixflow installs the requested subset and rewrites this placeholder to the Bricks custom SVG icon control before insertion, for example \`{ "library": "custom_pixflow-icon-set-tabler-outline", "svg": { "id": 123, "icon_id": "icon_tabler_outline_arrow_up_right", "url": "..." } }\`.
- Button icons belong on the button settings: \`icon\`, \`iconPosition\`, and optional \`iconGap\`. Use icons for source CTA arrows, GitHub/download actions, and compact action affordances when Stage A used them.
- Standalone icon markers use the Bricks \`icon\` element with \`settings.icon\`. Use \`svg\` only for an SVG media/control element, with \`source: "iconSet"\` and \`iconSet\` set to the Pixflow placeholder.
- Style standalone SVG icon elements through global classes with nested \`settings.icon\`, for example \`{ "icon": { "height": "2rem", "width": "2rem", "stroke": { "raw": "var(--accent)", "light": "#ef6b4d" }, "strokeWidth": "2" } }\`. Filled icons use \`fill\`; special cases may use both \`stroke\` and \`fill\`.
- Do not use regular font icon controls \`iconSize\` or \`iconColor\` for Pixflow SVG icons.
- Do not use Bricks Font Awesome font icon classes for Stage B page icons, and do not paste raw \`<svg>\` icon markup into text, code, or _cssCustom.
- Copy \`stage-b-icon-system.json\` to \`bricks-result.json.stage_b_icon_system\` when any sidecar icon is used.

## Page Scripts

- Do not use Bricks code elements for Stage B JavaScript.
- Source JavaScript needed for interaction polish, such as data-reveal IntersectionObserver behavior, belongs in \`bricks-result.json.page_settings.customScriptsBodyFooter\` as a complete \`<script>...</script>\` block.
- Missing behavior for explicit Stage A controls such as tab-like card grids with \`.active\` state also belongs in page settings. Scope scripts to the converted section, preserve keyboard access where practical, and target stable classes/attributes from the Bricks payload.
- Copy the same page settings object to \`bricks-result.json.stage_b_page_settings\` so Pixflow persists it to Bricks page settings during insertion.
- Do not use page scripts for fonts or icons. Fonts use \`stage-b-font-system.json\`; icons use \`stage-b-icon-system.json\`.

## Header And Footer Templates

- Bricks headers and footers are separate \`bricks_template\` posts, not normal page content.
- Header templates use \`_bricks_template_type = "header"\` and Pixflow writes their element tree to the Bricks header area.
- Footer templates use \`_bricks_template_type = "footer"\` and Pixflow writes their element tree to the Bricks footer area.
- Template assignment conditions live in \`_bricks_template_settings.templateConditions\`.
- Sitewide header condition: \`[{ "main": "any" }]\`.
- Current-page-only header condition after Pixflow creates the page: \`[{ "main": "ids", "ids": [pageId], "idsIncludeChildren": false }]\`.
- Exclusions use the same condition shape with \`"exclude": true\`.
- Writing header/footer area content to a regular page has no visible effect in Bricks.
- Stage B model output must keep approved header elements in \`stage_b_header.content\` and approved footer elements in \`stage_b_footer.content\`; Pixflow creates/updates the Bricks templates and conditions during insertion.
- Header inner wrappers must carry explicit Bricks flex controls on the element settings: \`_display: "flex"\`, \`_direction: "row"\`, alignment, justification, and gaps.
- Header navigation should use \`nav-menu\` when a real menu source is available. Fallback nav/action blocks must carry explicit Bricks flex controls on the element settings: \`_display: "flex"\`, \`_direction: "row"\`, \`_flexWrap: "wrap"\`, alignment, justification, and gaps.
- Footer templates use the same condition contract as headers and must remain separate from page content.

## Color Controls

- Stage B workspaces include \`stage-b-color-system.json\` when Stage A exposed design tokens.
- Pixflow names that colour system after the selected design system, checks for the deterministic native Bricks scheme/category first, and only writes missing variables or palette colours before page insertion.
- CSS variable colours must be Bricks raw color objects: { "raw": "var(--token)" }.
- Native Bricks palette entries for Stage B design systems should use token-backed raw values plus literal fallbacks: { "raw": "var(--token)", "light": "#hex", "name": "token" }.
- Do not put token declarations in a global class such as \`.od-root\`, \`.root\`, or \`*-root\`.
- Do not emit null or empty hex color placeholders.

## Custom CSS

- _cssCustom must contain complete selector blocks.
- _cssCustom is an escape hatch for selectors or effects that cannot be represented by Bricks settings; it must not carry routine layout, background, typography, border, padding, aspect-ratio, or object-fit styling.
- Use %root% while authoring class CSS; Pixflow scopes it to the generated class before insertion.
- Do not add page-wide pseudo-background overlays unless the accepted Stage A artifact has that same visible overlay.

## Component Fidelity

- Convert stat rings as separate editable elements: circular number/ring plus separate label text.
- Do not approximate stat rings with a dashed border on the whole stat text element.
- Do not add solid borders to plate/image wrappers unless the Stage A wrapper actually has that border.
- Preserve source border-radius/corner rhythm on buttons, badges, cards, images, and panels with Bricks radius controls or Pixflow radius variables.
- Horizontal wrappers must declare row layout with Bricks controls, not only CSS: _display flex/inline-flex plus _direction row on the same element/class.
- Preserve declared tab/card interfaces as working controls. Do not leave a source-labelled tabs grid as static cards.
- Preserve marquee rows as repeated editable items/tracks with matching spacing and direction. Do not flatten marquee content into malformed text.

## Pixflow Framework Rules

- Sections do not set routine top/bottom padding; Bricks Theme Style owns section spacing.
- Containers do not set routine left/right padding; Bricks Theme Style owns page gutters.
- Theme Style owns body font size, body line height, default heading/text colours, and default button styles.
- Buttons use Bricks button style/type where practical instead of hand-authored button CSS.
- Apply Pixflow colour schemes with pixflowColorScheme on section/container/block/div after approved schemes exist.
`;
}

function renderPixflowPluginMcpMarkdown() {
  return `# Pixflow Plugin MCP

Built-in, always-on Pixflow runtime context. Use this as the source of truth for Pixflow Framework routing, token mapping, Bricks payload constraints, media discipline, framework design-system controls, and class-name safety.

## Active Tools

- pixflow.route.resolve
- pixflow.design_system.resolve
- pixflow.tokens.map
- pixflow.classes.namespace
- pixflow.bricks.reference
- pixflow.google_fonts.install
- pixflow.icon_sets.install_subset
- pixflow.media.policy
- pixflow.qa.inspect

## Rules

- Final output is editable Bricks JSON.
- Stage B starts from Pixflow's clean-room HTML-to-Bricks baseline when the \`bricks-baseline-*\` files are present. Refine that payload instead of rebuilding the page from scratch.
- Read \`stage-b-route-contract.json\`, \`stage-b-theme-style-contract.json\`, and \`stage-b-theme-style-health.json\` before authoring Bricks settings or classes.
- Pixflow Framework is final authority for framework route output.
- Pixflow Design systems are creative direction only at conversion time.
- Compiler resolves final global class IDs and Bricks color IDs.
- No raw hex in Pixflow Framework mode when a token can express the role.
- No CSS variable fallback chains in Pixflow Framework mode.
- Pixflow Framework theme style owns routine spacing and defaults.
- Sections avoid routine vertical padding in Pixflow Framework mode.
- Containers avoid routine inline padding in Pixflow Framework mode.
- When \`safeToLeanOnThemeStyles\` is false, emit explicit page-scoped section, container, button, form, divider, card, and media baselines instead of assuming theme defaults exist.
- For non-Pixflow routes, do not create or mutate Bricks theme styles unless the Stage B preflight question flow records explicit user approval and scope.
- Do not use BEM suffixes that include primary or secondary for buttons. Prefer button-main and button-alt.
- Model proposes framework mutations only; Pixflow owns framework scheme and ramp calculations.
- Google Font families from \`stage-b-font-system.json\` are installed by Pixflow into Bricks custom fonts before Stage B insertion. Do not ask the model to load font files in CSS or JavaScript.
- Tabler SVG icons from \`stage-b-icon-system.json\` are built/installed by Pixflow into Bricks custom icon sets before Stage B insertion. Do not ask the model to use Bricks Font Awesome page icons or paste raw SVG icon code.
- Stage B icon placeholders use \`pixflow:<setId>:<iconId>\`, for example \`pixflow:tabler-outline:arrow-up-right\`, inside a Bricks icon control object with \`library: "pixflowSvg"\`.
- Pixflow rewrites placeholders to Bricks custom SVG icon controls such as \`library: "custom_pixflow-icon-set-tabler-outline"\` and \`svg.icon_id: "icon_tabler_outline_arrow_up_right"\`.
- SVG icon styling uses nested Bricks \`settings.icon\` style controls with \`height\`, \`width\`, \`stroke\`, optional \`strokeWidth\`, and \`fill\` for filled icons. Do not use \`iconSize\` or \`iconColor\` for Pixflow SVG icons.

## Class Contract

- compiler_owns_class_ids: true
- model_outputs_intent_not_final_ids: true
- short_bem_required: true
- button variant suffixes to use: button-main, button-alt, action-main, action-alt
- button suffixes to avoid: button-primary, button-secondary, primary-button, secondary-button
- allowed examples: brand-hero__button-main, brand-hero__button-alt, brand-card__media, brand-proof__stat
- blocked examples: brand-hero__button-primary, brand-hero__button-secondary
`;
}

async function assertStageBResultExists(resultFile) {
  await assertFileExists(resultFile, 'Stage B Bricks result');
}

async function normalizeStageBGeneratedArtifacts(prepared) {
  const result = await readJsonFile(prepared.resultFile, 'Stage B Bricks result');
  await writeJsonFile(prepared.resultFile, result);

  const content = Array.isArray(result.content) ? result.content : [];
  const globalClasses = Array.isArray(result.global_classes)
    ? result.global_classes
    : Array.isArray(result.globalClasses)
      ? result.globalClasses
      : [];
  const headerSpec = objectValue(result.stage_b_header || result.stageBHeader);
  const headerContent = Array.isArray(headerSpec.content)
    ? headerSpec.content
    : (Array.isArray(result.header_content) ? result.header_content : []);
  const footerSpec = objectValue(result.stage_b_footer || result.stageBFooter);
  const footerContent = Array.isArray(footerSpec.content)
    ? footerSpec.content
    : (Array.isArray(result.footer_content) ? result.footer_content : []);

  const sidecars = [
    [prepared.payloadFile, content],
    [prepared.globalClassesFile, globalClasses],
    [prepared.headerPayloadFile, headerContent],
    [prepared.footerPayloadFile, footerContent],
  ];
  for (const [filePath, value] of sidecars) {
    if (firstString(filePath)) {
      await writeJsonFile(filePath, value);
    }
  }
}

async function analyzeStageBResult(prepared) {
  const result = await readJsonFile(prepared.resultFile, 'Stage B Bricks result');
  const issues = [];
  const warnings = [];
  const content = Array.isArray(result.content) ? result.content : [];
  const globalClasses = Array.isArray(result.global_classes)
    ? result.global_classes
    : Array.isArray(result.globalClasses)
      ? result.globalClasses
      : [];
  const headerSpec = objectValue(result.stage_b_header || result.stageBHeader);
  const headerContent = Array.isArray(headerSpec.content)
    ? headerSpec.content
    : (Array.isArray(result.header_content) ? result.header_content : []);
  const headerIncluded = headerSpec.includeHeader === true || headerSpec.include_header === true || headerSpec.include === true;
  const footerSpec = objectValue(result.stage_b_footer || result.stageBFooter);
  const footerContent = Array.isArray(footerSpec.content)
    ? footerSpec.content
    : (Array.isArray(result.footer_content) ? result.footer_content : []);
  const footerIncluded = footerSpec.includeFooter === true || footerSpec.include_footer === true || footerSpec.include === true;
  const headerPlan = objectValue(result.stage_b_header_plan || result.stageBHeaderPlan || await readOptionalJson(prepared.headerPlanFile || ''));
  const routeContract = objectValue(result.stage_b_route_contract || await readOptionalJson(prepared.routeContractFile || ''));
  const themeStyleContract = objectValue(result.stage_b_theme_style_contract || await readOptionalJson(prepared.themeStyleContractFile || ''));
  const themeStyleHealth = objectValue(result.stage_b_theme_style_health || await readOptionalJson(prepared.themeStyleHealthFile || ''));
  const resultFontSystem = objectValue(result.stage_b_font_system || result.stageBFontSystem || result.font_system || result.fontSystem);
  const fontSystem = objectValue(Object.keys(resultFontSystem).length > 0 ? resultFontSystem : await readOptionalJson(prepared.fontSystemFile || ''));
  const resultIconSystem = objectValue(result.stage_b_icon_system || result.stageBIconSystem || result.icon_system || result.iconSystem);
  const iconSystem = objectValue(Object.keys(resultIconSystem).length > 0 ? resultIconSystem : await readOptionalJson(prepared.iconSystemFile || ''));
  const pageSettings = objectValue(result.stage_b_page_settings || result.stageBPageSettings || result.page_settings || result.pageSettings);

  if (result.type !== 'direct_page_generation') {
    issues.push(stageBIssue('stage_b_result_type_invalid', 'p0', 'bricks-result.json must use type direct_page_generation.'));
  }
  if (result.payload_format !== 'bricks_json') {
    issues.push(stageBIssue('stage_b_payload_format_invalid', 'p0', 'payload_format must be bricks_json.'));
  }
  if (result.payload_included !== true) {
    issues.push(stageBIssue('stage_b_payload_not_included', 'p0', 'payload_included must be true.'));
  }
  if (content.length === 0) {
    issues.push(stageBIssue('stage_b_content_empty', 'p0', 'content must contain Bricks elements.'));
  }
  if (globalClasses.length === 0) {
    warnings.push(stageBIssue('stage_b_global_classes_empty', 'p1', 'global_classes is empty; conversion may lose craft-level style control.'));
  }
  if (Object.keys(routeContract).length === 0) {
    warnings.push(stageBIssue('stage_b_route_contract_missing', 'p1', 'stage-b-route-contract.json or bricks-result.json.stage_b_route_contract is missing.'));
  }
  if (Object.keys(themeStyleContract).length === 0) {
    warnings.push(stageBIssue('stage_b_theme_style_contract_missing', 'p1', 'stage-b-theme-style-contract.json or bricks-result.json.stage_b_theme_style_contract is missing.'));
  }
  const stagedFontSystem = objectValue(await readOptionalJson(prepared.fontSystemFile || ''));
  if (Object.keys(stagedFontSystem).length > 0 && Object.keys(resultFontSystem).length === 0) {
    warnings.push(stageBIssue('stage_b_font_system_missing', 'p1', 'stage-b-font-system.json exists but bricks-result.json.stage_b_font_system is missing; Stage B insertion cannot preinstall source Google fonts.'));
  }
  const stagedIconSystem = objectValue(await readOptionalJson(prepared.iconSystemFile || ''));
  if (Object.keys(stagedIconSystem).length > 0 && Object.keys(resultIconSystem).length === 0) {
    warnings.push(stageBIssue('stage_b_icon_system_missing', 'p1', 'stage-b-icon-system.json exists but bricks-result.json.stage_b_icon_system is missing; Stage B insertion cannot preinstall source Tabler SVG icons.'));
  }
  const pageSettingsIssues = inspectStageBPageSettings(pageSettings);
  issues.push(...pageSettingsIssues.errors);
  warnings.push(...pageSettingsIssues.warnings);

  const validation = inspectStageBBricksPayload(content, globalClasses, prepared.workspaceDir, { requirePageH1: true, iconSystem });
  issues.push(...validation.errors);
  warnings.push(...validation.warnings);
  let headerValidation = null;
  if (headerIncluded) {
    if (!['current_page', 'sitewide'].includes(firstString(headerSpec.scope))) {
      issues.push(stageBIssue('stage_b_header_scope_invalid', 'p0', 'stage_b_header.scope must be current_page or sitewide when includeHeader is true.'));
    }
    if (firstString(headerSpec.templateType, headerSpec.template_type) !== 'header') {
      issues.push(stageBIssue('stage_b_header_template_type_invalid', 'p0', 'stage_b_header.templateType must be header.'));
    }
    if (headerContent.length === 0) {
      issues.push(stageBIssue('stage_b_header_content_empty', 'p0', 'stage_b_header.content must contain Bricks elements when includeHeader is true.'));
    } else {
      headerValidation = inspectStageBBricksPayload(headerContent, globalClasses, prepared.workspaceDir, { requireTopLevelSection: false, iconSystem });
      issues.push(...headerValidation.errors.map((issue) => ({
        ...issue,
        id: `stage_b_header_${issue.id}`,
        message: `Header payload: ${issue.message}`,
      })));
      warnings.push(...headerValidation.warnings.map((issue) => ({
        ...issue,
        id: `stage_b_header_${issue.id}`,
        message: `Header payload: ${issue.message}`,
      })));
      const headerLayoutValidation = inspectStageBHeaderLayoutContract(headerContent, {
        ...headerPlan,
        ...headerSpec,
        sourceSectionOdId: firstString(
          headerSpec.sourceSectionOdId,
          headerSpec.source_section_od_id,
          headerSpec.selectedSectionOdId,
          headerSpec.selected_section_od_id,
          headerPlan.sourceSectionOdId,
          headerPlan.source_section_od_id,
          headerPlan.selectedSectionOdId,
          headerPlan.selected_section_od_id,
        ),
      }, globalClasses);
      issues.push(...headerLayoutValidation.errors);
      warnings.push(...headerLayoutValidation.warnings);
    }
  }
  let footerValidation = null;
  if (footerIncluded) {
    if (!['current_page', 'sitewide'].includes(firstString(footerSpec.scope))) {
      issues.push(stageBIssue('stage_b_footer_scope_invalid', 'p0', 'stage_b_footer.scope must be current_page or sitewide when includeFooter is true.'));
    }
    if (firstString(footerSpec.templateType, footerSpec.template_type) !== 'footer') {
      issues.push(stageBIssue('stage_b_footer_template_type_invalid', 'p0', 'stage_b_footer.templateType must be footer.'));
    }
    if (footerContent.length === 0) {
      issues.push(stageBIssue('stage_b_footer_content_empty', 'p0', 'stage_b_footer.content must contain Bricks elements when includeFooter is true.'));
    } else {
      footerValidation = inspectStageBBricksPayload(footerContent, globalClasses, prepared.workspaceDir, { requireTopLevelSection: false, iconSystem });
      issues.push(...footerValidation.errors.map((issue) => ({
        ...issue,
        id: `stage_b_footer_${issue.id}`,
        message: `Footer payload: ${issue.message}`,
      })));
      warnings.push(...footerValidation.warnings.map((issue) => ({
        ...issue,
        id: `stage_b_footer_${issue.id}`,
        message: `Footer payload: ${issue.message}`,
      })));
      const footerPaddingValidation = inspectStageBTemplateSectionPaddingContract(footerContent, globalClasses, 'footer');
      issues.push(...footerPaddingValidation.errors);
      warnings.push(...footerPaddingValidation.warnings);
    }
  }

  const payloadFileContent = await readOptionalJson(prepared.payloadFile);
  if (Array.isArray(payloadFileContent) && payloadFileContent.length !== content.length) {
    warnings.push(stageBIssue('stage_b_payload_sidecar_mismatch', 'p1', 'bricks-payload.json length differs from bricks-result.json content length.'));
  } else if (!Array.isArray(payloadFileContent)) {
    warnings.push(stageBIssue('stage_b_payload_sidecar_missing', 'p1', 'bricks-payload.json is missing or not an array.'));
  }

  const classesFileContent = await readOptionalJson(prepared.globalClassesFile);
  if (Array.isArray(classesFileContent) && classesFileContent.length !== globalClasses.length) {
    warnings.push(stageBIssue('stage_b_classes_sidecar_mismatch', 'p1', 'global-classes.json length differs from bricks-result.json global_classes length.'));
  } else if (!Array.isArray(classesFileContent)) {
    warnings.push(stageBIssue('stage_b_classes_sidecar_missing', 'p1', 'global-classes.json is missing or not an array.'));
  }

  if (prepared.headerPayloadFile) {
    const headerFileContent = await readOptionalJson(prepared.headerPayloadFile);
    if (headerIncluded && Array.isArray(headerFileContent) && headerFileContent.length !== headerContent.length) {
      warnings.push(stageBIssue('stage_b_header_payload_sidecar_mismatch', 'p1', 'bricks-header-payload.json length differs from bricks-result.json stage_b_header.content length.'));
    } else if (headerIncluded && !Array.isArray(headerFileContent)) {
      warnings.push(stageBIssue('stage_b_header_payload_sidecar_missing', 'p1', 'bricks-header-payload.json is missing or not an array.'));
    }
  }
  if (prepared.footerPayloadFile) {
    const footerFileContent = await readOptionalJson(prepared.footerPayloadFile);
    if (footerIncluded && Array.isArray(footerFileContent) && footerFileContent.length !== footerContent.length) {
      warnings.push(stageBIssue('stage_b_footer_payload_sidecar_mismatch', 'p1', 'bricks-footer-payload.json length differs from bricks-result.json stage_b_footer.content length.'));
    } else if (footerIncluded && !Array.isArray(footerFileContent)) {
      warnings.push(stageBIssue('stage_b_footer_payload_sidecar_missing', 'p1', 'bricks-footer-payload.json is missing or not an array.'));
    }
  }

  const report = await readOptionalText(path.join(prepared.workspaceDir, 'conversion-report.md'));
  if (report.trim().length < 300) {
    warnings.push(stageBIssue('stage_b_conversion_report_thin', 'p1', 'conversion-report.md should include section mapping and preservation notes.'));
  }

  const severity = severityCounts([...issues, ...warnings]);
  const blocking = severity.p0 > 0;
  const score = Math.max(0, 100 - (severity.p0 * 30) - (severity.p1 * 10) - (severity.p2 * 3));
  return {
    status: blocking ? 'failed' : 'passed',
    blocking,
    score,
    summary: {
      elementCount: content.length,
      headerElementCount: headerContent.length,
      footerElementCount: footerContent.length,
      globalClassCount: globalClasses.length,
      topLevelSectionCount: validation.topLevelSectionCount,
      headerTopLevelSectionCount: headerValidation?.topLevelSectionCount || 0,
      footerTopLevelSectionCount: footerValidation?.topLevelSectionCount || 0,
      supportedElementCount: validation.supportedElementCount,
      headingTagCounts: validation.headingTagCounts,
      routeId: firstString(routeContract.routeId),
      routeFamily: firstString(routeContract.routeFamily),
      styleMode: firstString(routeContract.styleMode),
      themeStyleMode: firstString(themeStyleContract.mode),
      themeStyleHealthStatus: firstString(themeStyleHealth.status),
      safeToLeanOnThemeStyles: themeStyleContract.safeToLeanOnThemeStyles === true,
      iconSystem: summarizeStageBIconSystem(iconSystem),
      iconUsageCount: validation.iconUsageCount,
      headerIconUsageCount: headerValidation?.iconUsageCount || 0,
      footerIconUsageCount: footerValidation?.iconUsageCount || 0,
    },
    severity,
    issues: [...issues, ...warnings],
  };
}

function inspectStageBBricksPayload(content, globalClasses, workspaceDir = '', options = {}) {
  const errors = [];
  const warnings = [];
  const allowed = new Set(['section', 'container', 'div', 'block', 'heading', 'text-basic', 'text', 'text-link', 'button', 'image', 'icon', 'svg', 'nav-menu', 'divider', 'video']);
  const ids = new Set();
  const classIds = new Set();
  const headingTagCounts = { h1: 0, h2: 0, h3: 0, h4: 0, h5: 0, h6: 0 };
  let topLevelSectionCount = 0;
  let supportedElementCount = 0;
  let actionElementCount = 0;
  const iconSystem = objectValue(options.iconSystem);
  const expectedIconCount = summarizeStageBIconSystem(iconSystem).iconCount;
  const iconUsages = [];

  for (const [index, classItem] of globalClasses.entries()) {
    if (!classItem || typeof classItem !== 'object' || Array.isArray(classItem)) {
      errors.push(stageBIssue('stage_b_global_class_invalid', 'p0', `global_classes[${index}] must be an object.`));
      continue;
    }
    const id = firstString(classItem.id);
    const name = firstString(classItem.name);
    if (!id || !name) {
      errors.push(stageBIssue('stage_b_global_class_missing_identity', 'p0', `global_classes[${index}] is missing id or name.`));
    }
    if (id) classIds.add(id);
    if (/(?:^|[-_])(primary|secondary)(?:$|[-_])/i.test(name)) {
      warnings.push(stageBIssue('stage_b_button_class_reserved_fragment', 'p1', `Global class "${name}" contains reserved primary/secondary wording.`));
    }
    const settings = objectValue(classItem.settings);
    const classSettingsIssues = inspectStageBBricksSettings(settings, `Global class "${name}"`);
    errors.push(...classSettingsIssues.errors);
    warnings.push(...classSettingsIssues.warnings);
    if (Object.prototype.hasOwnProperty.call(settings, 'iconSize') || Object.prototype.hasOwnProperty.call(settings, 'iconColor')) {
      warnings.push(stageBIssue(
        'stage_b_svg_icon_class_font_controls',
        'p1',
        `Global class "${name}" uses iconSize/iconColor. Pixflow SVG icon classes must use nested settings.icon height/width/stroke/fill controls because Bricks styles SVG icons differently from font icons.`
      ));
    }
    const customCss = firstString(settings._cssCustom);
    const tokenDeclarationCount = countStageBRootCssVariableDeclarations(customCss);
    if (/(?:^|[-_])root$/i.test(name) || tokenDeclarationCount >= 4) {
      if (tokenDeclarationCount > 0 || /%root%::before/i.test(customCss)) {
        errors.push(stageBIssue(
          'stage_b_root_token_bucket_class',
          'p0',
          `Global class "${name}" appears to store design tokens or page-wide root CSS. Use stage-b-color-system.json and native Bricks variables/palettes instead.`
        ));
      }
    }
    if (/\bstat\b/i.test(name) && String(settings?._border?.style || '').toLowerCase() === 'dashed') {
      warnings.push(stageBIssue(
        'stage_b_stat_ring_approximated',
        'p1',
        `Global class "${name}" uses a dashed border on the stat container. Build stat rings as separate circular number elements plus label text.`
      ));
    }
    if (/\bplate\b/i.test(name) && settings?._border && String(settings._border.style || '').toLowerCase() === 'solid') {
      warnings.push(stageBIssue(
        'stage_b_plate_border_added',
        'p1',
        `Global class "${name}" adds a solid border. Verify the accepted Stage A plate wrapper had this border before keeping it.`
      ));
    }
  }

  for (const [index, element] of content.entries()) {
    if (!element || typeof element !== 'object' || Array.isArray(element)) {
      errors.push(stageBIssue('stage_b_element_invalid', 'p0', `content[${index}] must be an object.`));
      continue;
    }
    const id = firstString(element.id);
    const name = firstString(element.name);
    if (!id || !name) {
      errors.push(stageBIssue('stage_b_element_missing_identity', 'p0', `content[${index}] is missing id or name.`));
      continue;
    }
    if (ids.has(id)) {
      errors.push(stageBIssue('stage_b_duplicate_element_id', 'p0', `Duplicate Bricks element id "${id}".`));
    }
    ids.add(id);
    if (!allowed.has(name)) {
      errors.push(stageBIssue('stage_b_unsupported_element', 'p0', `Unsupported Bricks element "${name}".`));
    } else {
      supportedElementCount += 1;
    }
    if (name === 'button') {
      actionElementCount += 1;
    }
    if (name === 'section' && !firstString(element.parent)) {
      topLevelSectionCount += 1;
    }
    if (!Array.isArray(element.children)) {
      errors.push(stageBIssue('stage_b_children_invalid', 'p0', `Element "${id}" children must be an array.`));
    }
    for (const metadataKey of ['source', 'sourceUrl', 'version']) {
      if (Object.prototype.hasOwnProperty.call(element, metadataKey)) {
        errors.push(stageBIssue('stage_b_copied_element_metadata', 'p0', `Element "${id}" includes copied-element metadata "${metadataKey}", which Bricks adds itself.`));
      }
    }
    const settings = objectValue(element.settings);
    const directStyleKeys = collectStageBElementDirectStyleKeys(settings);
    if (directStyleKeys.length > 0) {
      errors.push(stageBIssue(
        'stage_b_element_direct_style_disallowed',
        'p0',
        `Element "${id}" sets direct style keys (${directStyleKeys.slice(0, 10).join(', ')}). Stage B must put source CSS in global classes, not Bricks element/ID styling.`
      ));
    }
    if (firstString(settings._cssId)) {
      errors.push(stageBIssue('stage_b_css_id_option_disallowed', 'p0', `Element "${id}" sets Bricks _cssId. Preserve source ids as _attributes only when needed for anchors; do not write the Bricks ID option in Stage B.`));
    }
    const elementIconUsages = collectStageBIconUsages(settings, `Element "${id}"`, name);
    iconUsages.push(...elementIconUsages);
    if (
      name === 'icon'
      && elementIconUsages.some((usage) => usage.placeholder || usage.svg)
      && (Object.prototype.hasOwnProperty.call(settings, 'iconSize') || Object.prototype.hasOwnProperty.call(settings, 'iconColor'))
    ) {
      warnings.push(stageBIssue(
        'stage_b_svg_icon_uses_font_style_controls',
        'p1',
        `Icon element "${id}" uses iconSize/iconColor with a Pixflow SVG icon. Move sizing/colour to a global class settings.icon object with height, width, stroke/fill, and optional strokeWidth.`
      ));
    }
    const settingsIssues = inspectStageBBricksSettings(settings, `Element "${id}"`);
    errors.push(...settingsIssues.errors);
    warnings.push(...settingsIssues.warnings);
    if (name === 'heading') {
      if (Object.prototype.hasOwnProperty.call(settings, 'tagName')) {
        errors.push(stageBIssue('stage_b_heading_uses_tag_name', 'p0', `Heading element "${id}" uses tagName; Bricks requires settings.tag for semantic heading tags.`));
      }
      const tag = firstString(settings.tag).toLowerCase();
      const customTag = firstString(settings.customTag).toLowerCase();
      const semanticTag = /^h[1-6]$/.test(tag) ? tag : (/^h[1-6]$/.test(customTag) ? customTag : '');
      if (!semanticTag) {
        errors.push(stageBIssue('stage_b_heading_tag_missing', 'p0', `Heading element "${id}" must set settings.tag to h1-h6 so Bricks renders the intended semantic tag.`));
      } else if (Object.prototype.hasOwnProperty.call(headingTagCounts, semanticTag)) {
        headingTagCounts[semanticTag] += 1;
      }
    }
    const attributeIssues = inspectStageBElementAttributes(settings, id);
    errors.push(...attributeIssues.errors);
    warnings.push(...attributeIssues.warnings);
    if (Object.prototype.hasOwnProperty.call(settings, '_cssGlobalClasses') && !Array.isArray(settings._cssGlobalClasses)) {
      errors.push(stageBIssue('stage_b_global_class_refs_invalid', 'p0', `Element "${id}" _cssGlobalClasses must be an array of class id strings.`));
    }
    const refs = Array.isArray(settings._cssGlobalClasses) ? settings._cssGlobalClasses : [];
    for (const ref of refs) {
      if (ref && typeof ref === 'object') {
        errors.push(stageBIssue('stage_b_global_class_ref_object', 'p0', `Element "${id}" _cssGlobalClasses contains an object; Bricks requires class id strings.`));
        continue;
      }
      const refId = firstString(ref);
      if (refId && !classIds.has(refId)) {
        errors.push(stageBIssue('stage_b_global_class_ref_missing', 'p0', `Element "${id}" references missing global class id "${refId}".`));
      }
    }
    const linkIssues = inspectStageBLinkSetting(settings.link, `Element "${id}"`);
    errors.push(...linkIssues.errors);
    warnings.push(...linkIssues.warnings);
    if (name === 'image' && workspaceDir) {
      const localAssetRefs = collectStageBLocalAssetRefs(settings);
      if (localAssetRefs.length === 0) {
        warnings.push(stageBIssue('stage_b_image_without_asset_ref', 'p1', `Image element "${id}" does not reference a local asset path.`));
      }
      for (const assetRef of localAssetRefs) {
        if (!stageBLocalAssetExists(workspaceDir, assetRef)) {
          warnings.push(stageBIssue('stage_b_image_asset_missing', 'p1', `Image element "${id}" references missing local asset "${assetRef}".`));
        }
      }
    }
    if (name === 'code') {
      errors.push(stageBIssue('stage_b_code_element_disallowed', 'p0', `Code element "${id}" is not allowed for Stage B JavaScript. Move source JS into bricks-result.json.page_settings.customScriptsBodyFooter so Pixflow saves it as Bricks page settings.`));
    }
    if (name === 'svg') {
      if (firstString(settings.source) === 'code' || firstString(settings.code)) {
        errors.push(stageBIssue('stage_b_svg_raw_code_source', 'p0', `SVG element "${id}" uses raw code. Use source "iconSet" plus a Pixflow icon placeholder for icons.`));
      }
      if (firstString(settings.source) === 'iconSet') {
        const svgIconUsages = collectStageBIconUsages(settings.iconSet, `Element "${id}" iconSet`, name);
        if (svgIconUsages.length === 0) {
          errors.push(stageBIssue('stage_b_svg_icon_set_missing_icon', 'p0', `SVG element "${id}" uses source iconSet but is missing settings.iconSet.`));
        }
      }
    }
  }

  for (const element of content) {
    if (!element || typeof element !== 'object') continue;
    const id = firstString(element.id);
    const parent = element.parent === 0 || element.parent === '0' ? '' : firstString(element.parent);
    if (parent && !ids.has(parent)) {
      errors.push(stageBIssue('stage_b_parent_missing', 'p0', `Element "${id}" references missing parent "${parent}".`));
    }
    const children = Array.isArray(element.children) ? element.children : [];
    for (const child of children) {
      const childId = firstString(child);
      if (childId && !ids.has(childId)) {
        errors.push(stageBIssue('stage_b_child_missing', 'p0', `Element "${id}" references missing child "${childId}".`));
      }
    }
  }

  const requireTopLevelSection = options.requireTopLevelSection !== false;
  if (requireTopLevelSection && topLevelSectionCount <= 0) {
    errors.push(stageBIssue('stage_b_no_top_level_sections', 'p0', 'Payload must contain at least one top-level section.'));
  }
  if (options.requirePageH1 === true && headingTagCounts.h1 <= 0) {
    errors.push(stageBIssue('stage_b_page_h1_missing', 'p0', 'Page content must contain at least one heading element with settings.tag "h1".'));
  }
  const placeholderIconUsages = iconUsages.filter((usage) => usage.placeholder);
  const fontIconUsages = iconUsages.filter((usage) => usage.fontIcon);
  const fontAwesomeIconUsages = iconUsages.filter((usage) => usage.fontAwesome);
  const rawSvgIconUsages = iconUsages.filter((usage) => usage.rawSvg);
  if (expectedIconCount > 0 && actionElementCount > 0 && iconUsages.length === 0) {
    warnings.push(stageBIssue('stage_b_source_icons_not_used', 'p1', 'stage-b-icon-system.json detected source/action icons, but the Bricks payload does not use any icon controls. Preserve CTA/action/card/proof affordances with Pixflow Tabler SVG icons.'));
  }
  if (placeholderIconUsages.length > 0 && expectedIconCount === 0) {
    errors.push(stageBIssue('stage_b_icon_placeholder_without_sidecar', 'p0', 'Payload uses pixflow:<set>:<icon> placeholders, but stage_b_icon_system is missing or empty. Copy stage-b-icon-system.json into bricks-result.json.stage_b_icon_system.'));
  }
  for (const usage of placeholderIconUsages) {
    if (!stageBIconSystemContainsPlaceholder(iconSystem, usage.icon)) {
      errors.push(stageBIssue('stage_b_icon_placeholder_not_declared', 'p0', `${usage.owner} uses icon placeholder "${usage.icon}", but it is not declared in stage_b_icon_system.`));
    }
  }
  for (const usage of fontAwesomeIconUsages.slice(0, 8)) {
    warnings.push(stageBIssue('stage_b_font_awesome_icon_used', 'p1', `${usage.owner} uses Bricks Font Awesome icon "${usage.icon}". Use Pixflow-installed Tabler SVG icons for Stage B page icons.`));
  }
  for (const usage of fontIconUsages.filter((usage) => !usage.fontAwesome).slice(0, 8)) {
    warnings.push(stageBIssue('stage_b_font_icon_used', 'p2', `${usage.owner} uses font icon "${usage.icon}". Prefer Pixflow Tabler SVG icons from stage-b-icon-system.json for source/action affordances.`));
  }
  for (const usage of rawSvgIconUsages.slice(0, 8)) {
    errors.push(stageBIssue('stage_b_raw_svg_icon_markup', 'p0', `${usage.owner} contains raw SVG icon markup. Use a Pixflow Tabler SVG icon placeholder instead.`));
  }

  return {
    errors,
    warnings,
    topLevelSectionCount,
    supportedElementCount,
    headingTagCounts,
    iconUsageCount: iconUsages.length,
    iconPlaceholderCount: placeholderIconUsages.length,
  };
}

function inspectStageBPageSettings(pageSettings) {
  const errors = [];
  const warnings = [];
  const settings = objectValue(pageSettings);
  const allowedKeys = new Set(['customCss', 'customScriptsHeader', 'customScriptsBodyHeader', 'customScriptsBodyFooter']);
  for (const [key, value] of Object.entries(settings)) {
    if (!allowedKeys.has(key)) {
      warnings.push(stageBIssue('stage_b_page_settings_unknown_key', 'p1', `Page settings include "${key}". Keep Stage B page settings to Bricks custom CSS/script fields unless a new runtime contract supports more keys.`));
      continue;
    }
    if (typeof value !== 'string') {
      errors.push(stageBIssue('stage_b_page_settings_value_invalid', 'p0', `Page setting "${key}" must be a string.`));
      continue;
    }
    if (key === 'customCss') {
      if (/@import\b|@font-face\b|fonts\.googleapis\.com|fonts\.gstatic\.com/i.test(value)) {
        errors.push(stageBIssue('stage_b_page_settings_font_import', 'p0', 'Page customCss must not import fonts. Use stage-b-font-system.json and Pixflow font installation.'));
      }
      continue;
    }
    if (value.trim() && !/<script\b[\s\S]*<\/script>/i.test(value)) {
      warnings.push(stageBIssue('stage_b_page_script_without_tag', 'p1', `Page setting "${key}" should include a complete <script>...</script> block because Bricks prints page scripts as raw page settings.`));
    }
    if (/fonts\.googleapis\.com|fonts\.gstatic\.com|@font-face|document\.createElement\(['"]link['"]\)/i.test(value)) {
      errors.push(stageBIssue('stage_b_page_script_font_import', 'p0', `Page setting "${key}" must not load fonts. Use stage-b-font-system.json and Pixflow's Bricks Google Font installer.`));
    }
    if (/<svg\b/i.test(value)) {
      errors.push(stageBIssue('stage_b_page_script_raw_svg_icon', 'p0', `Page setting "${key}" contains raw SVG markup. Use stage-b-icon-system.json and Pixflow's SVG icon installer.`));
    }
  }
  return { errors, warnings };
}

function collectStageBIconUsages(value, owner, elementName = '', pathLabel = 'settings') {
  const usages = [];
  collectStageBIconUsagesFromValue(value, owner, elementName, pathLabel, usages);
  return usages;
}

function collectStageBIconUsagesFromValue(value, owner, elementName, pathLabel, usages) {
  if (!value) return;
  if (typeof value === 'string') {
    if (/<svg\b/i.test(value)) {
      usages.push({ owner, path: pathLabel, icon: '', library: '', rawSvg: true, fontIcon: false, fontAwesome: false, placeholder: false });
    }
    return;
  }
  if (typeof value !== 'object') return;
  if (Array.isArray(value)) {
    value.forEach((item, index) => collectStageBIconUsagesFromValue(item, owner, elementName, `${pathLabel}[${index}]`, usages));
    return;
  }

  const usage = describeStageBIconSetting(value, owner, elementName, pathLabel);
  if (usage) {
    usages.push(usage);
  }

  for (const [key, child] of Object.entries(value)) {
    if (usage && ['icon', 'pixflowIcon', 'library', 'svg'].includes(key)) {
      continue;
    }
    collectStageBIconUsagesFromValue(child, owner, elementName, `${pathLabel}.${key}`, usages);
  }
}

function describeStageBIconSetting(value, owner, elementName, pathLabel) {
  const icon = firstString(value.icon, value.pixflowIcon);
  const library = firstString(value.library);
  const svg = objectValue(value.svg);
  const hasSvg = Boolean(firstString(svg.id, svg.url, svg.filename));
  const hasIconControlShape = Boolean(icon || library || hasSvg || pathLabel.endsWith('.iconSet'));
  if (!hasIconControlShape) {
    return null;
  }
  const placeholder = isStageBIconPlaceholder(icon);
  const fontAwesome = /font[\s_-]*awesome|^fa[brs]?$/i.test(library)
    || /\bfa[brs]?\s+fa-[a-z0-9-]+/i.test(icon)
    || /^fa-[a-z0-9-]+/i.test(icon);
  const fontIcon = Boolean(icon && !placeholder && !hasSvg);
  return {
    owner,
    elementName,
    path: pathLabel,
    icon,
    library,
    placeholder,
    fontAwesome,
    fontIcon,
    rawSvg: false,
    svg: hasSvg,
  };
}

function isStageBIconPlaceholder(value) {
  return /^pixflow:[a-z0-9-]+:[a-z0-9-]+$/i.test(firstString(value).trim());
}

function stageBIconSystemContainsPlaceholder(iconSystem, placeholder) {
  const target = firstString(placeholder).trim().toLowerCase();
  if (!target) return false;
  const summary = summarizeStageBIconSystem(iconSystem);
  if (summary.iconCount === 0) return false;
  const icons = Array.isArray(iconSystem?.icons)
    ? iconSystem.icons
    : (Array.isArray(iconSystem?.iconSets)
      ? iconSystem.iconSets.flatMap((set) => Array.isArray(set?.icons)
        ? set.icons.map((icon) => ({ ...icon, setId: firstString(icon?.setId, set?.setId) }))
        : [])
      : []);
  return icons.some((icon) => firstString(icon?.placeholder, buildStageBIconPlaceholder(icon?.setId, icon?.id)).toLowerCase() === target);
}

function inspectStageBBricksSettings(settings, owner) {
  const errors = [];
  const warnings = [];
  if (!settings || typeof settings !== 'object' || Array.isArray(settings)) {
    return { errors, warnings };
  }

  for (const rawKey of [
    'display',
    'direction',
    'flexWrap',
    'justifyContent',
    'alignItems',
    'rowGap',
    'columnGap',
    'gridTemplateColumns',
    'gridGap',
    'padding',
    'margin',
    'background',
    'border',
    'width',
    'height',
  ]) {
    if (Object.prototype.hasOwnProperty.call(settings, rawKey)) {
      errors.push(stageBIssue('stage_b_unprefixed_style_key', 'p0', `${owner} uses unprefixed Bricks style key "${rawKey}".`));
    }
  }

  for (const typographyKey of [
    'color',
    'fontSize',
    'font-size',
    'fontFamily',
    'font-family',
    'fontWeight',
    'font-weight',
    'lineHeight',
    'line-height',
    'letterSpacing',
    'letter-spacing',
    'textAlign',
    'text-align',
  ]) {
    if (Object.prototype.hasOwnProperty.call(settings, typographyKey)) {
      errors.push(stageBIssue('stage_b_root_typography_key', 'p0', `${owner} uses typography key "${typographyKey}" at settings root; put it under _typography.`));
    }
  }

  const flexKeys = ['_direction', '_flexWrap'];
  const hasFlexOnlyKey = flexKeys.some((key) => firstString(settings[key]));
  const display = firstString(settings._display).toLowerCase();
  if (hasFlexOnlyKey && !['flex', 'inline-flex'].includes(display)) {
    errors.push(stageBIssue('stage_b_flex_controls_without_display', 'p0', `${owner} uses flex controls but does not set _display to flex or inline-flex on the same element/class.`));
  }
  const gridKeys = ['_gridTemplateColumns', '_gridTemplateRows', '_justifyItemsGrid', '_alignItemsGrid', '_justifyContentGrid', '_alignContentGrid'];
  const hasGridOnlyKey = gridKeys.some((key) => firstString(settings[key]));
  if (hasGridOnlyKey && !['grid', 'inline-grid'].includes(display)) {
    errors.push(stageBIssue('stage_b_grid_controls_without_display', 'p0', `${owner} uses grid controls but does not set _display to grid on the same element/class.`));
  }
  if (
    display === 'grid'
    && stageBGridColumnCountHint(firstString(settings._gridTemplateColumns)) > 1
    && !firstString(settings['_gridTemplateColumns:mobile_portrait'], settings['_gridTemplateColumns:tablet_portrait'])
  ) {
    errors.push(stageBIssue(
      'stage_b_grid_responsive_columns_missing',
      'p0',
      `${owner} defines a multi-column grid but has no Bricks responsive _gridTemplateColumns override. Use Bricks responsive settings instead of relying only on _cssCustom media queries.`,
    ));
  }

  for (const scalarKey of ['_width', '_widthMin', '_widthMax', '_height', '_heightMin', '_heightMax', '_columnGap', '_rowGap', '_gridGap', '_aspectRatio', '_objectFit']) {
    if (settings[scalarKey] && typeof settings[scalarKey] === 'object' && !Array.isArray(settings[scalarKey])) {
      errors.push(stageBIssue('stage_b_scalar_unit_object', 'p0', `${owner} setting ${scalarKey} must be a scalar string, not a value/unit object.`));
    }
  }

  const typography = objectValue(settings._typography);
  for (const [key, value] of Object.entries(typography)) {
    if (['color', 'background-color'].includes(key)) {
      continue;
    }
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      errors.push(stageBIssue('stage_b_typography_scalar_object', 'p0', `${owner} _typography.${key} must be a scalar string.`));
    }
  }
  const fontFamily = firstString(typography['font-family']);
  if (/^var\(/i.test(fontFamily)) {
    errors.push(stageBIssue(
      'stage_b_typography_font_family_var',
      'p0',
      `${owner} sets _typography.font-family to "${fontFamily}". Resolve Stage A font variables to the concrete family name supplied by stage-b-font-system.json so Bricks can map it to an installed custom font.`
    ));
  }

  const border = settings._border;
  if (border && typeof border === 'object' && !Array.isArray(border)) {
    for (const side of ['top', 'right', 'bottom', 'left']) {
      if (border[side] && typeof border[side] === 'object' && !Array.isArray(border[side])) {
        warnings.push(stageBIssue('stage_b_nested_border_side', 'p1', `${owner} _border.${side} is nested. Prefer Bricks' flat border shape or scoped _cssCustom for one-side borders.`));
      }
    }
  }

  const customCss = firstString(settings._cssCustom);
  if (customCss) {
    if (/@import\b|@font-face\b|fonts\.googleapis\.com|fonts\.gstatic\.com/i.test(customCss)) {
      errors.push(stageBIssue('stage_b_font_import_in_custom_css', 'p0', `${owner} imports or declares fonts in _cssCustom. Use stage-b-font-system.json and Pixflow's Bricks Google Font installer instead.`));
    }
    if (!/[{}]/.test(customCss)) {
      errors.push(stageBIssue('stage_b_custom_css_declarations_only', 'p0', `${owner} _cssCustom must contain complete selector blocks, not bare declarations.`));
    }
    if (!/%root%/.test(customCss) && !/^\s*@(?:media|supports|container)\b/i.test(customCss)) {
      warnings.push(stageBIssue('stage_b_custom_css_without_root', 'p1', `${owner} _cssCustom should scope selectors with %root%.`));
    }
    const routineCustomCssProperties = collectStageBRoutineRootCustomCssProperties(customCss);
    if (routineCustomCssProperties.length > 0) {
      warnings.push(stageBIssue(
        'stage_b_custom_css_contains_supported_declarations',
        'p1',
        `${owner} _cssCustom contains routine root declarations (${routineCustomCssProperties.slice(0, 8).join(', ')}). Move layout/spacing/type/background/border/media properties into Bricks settings and leave _cssCustom for unsupported selectors/effects.`
      ));
    }
  }

  if (Object.prototype.hasOwnProperty.call(settings, 'customJs')) {
    errors.push(stageBIssue('stage_b_unknown_custom_js_setting', 'p0', `${owner} uses customJs, which is not a Bricks page/script setting.`));
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'templateType')) {
    errors.push(stageBIssue('stage_b_template_type_on_element', 'p0', `${owner} sets templateType on an element/settings object; template type belongs to a bricks_template post.`));
  }

  return { errors, warnings };
}

function collectStageBElementDirectStyleKeys(settings) {
  const styleKeys = new Set([
    '_cssCustom',
    '_display',
    '_direction',
    '_flexWrap',
    '_alignItems',
    '_alignItemsGrid',
    '_justifyContent',
    '_justifyContentGrid',
    '_justifyItemsGrid',
    '_alignContentGrid',
    '_columnGap',
    '_rowGap',
    '_gridTemplateColumns',
    '_gridTemplateRows',
    '_background',
    '_typography',
    '_border',
    '_padding',
    '_margin',
    '_width',
    '_height',
    '_widthMin',
    '_widthMax',
    '_heightMin',
    '_heightMax',
    '_aspectRatio',
    '_objectFit',
    '_overflow',
    '_position',
    '_top',
    '_right',
    '_bottom',
    '_left',
    '_zIndex',
    '_boxShadow',
    '_transform',
    '_transition',
  ]);
  const result = [];
  for (const key of Object.keys(objectValue(settings))) {
    const baseKey = key.split(':')[0];
    if (styleKeys.has(baseKey)) {
      result.push(key);
    }
  }
  return result;
}

function collectStageBRoutineRootCustomCssProperties(customCss) {
  const properties = [];
  const rules = extractStageBCssRuleSummaries(customCss);
  for (const rule of rules) {
    const selectors = splitPixflowCssSelectorList(rule.selector);
    const isRootOnly = selectors.some((selector) => /^%root%\s*$/i.test(selector.trim()));
    if (!isRootOnly) {
      continue;
    }
    for (const [property, value] of Object.entries(objectValue(rule.declarations))) {
      if (isPixflowStageBMappableCssDeclaration(property, value)) {
        properties.push(property.toLowerCase());
      }
    }
  }
  return uniqueStrings(properties);
}

function inspectStageBLinkSetting(link, owner) {
  const errors = [];
  const warnings = [];
  if (!link || typeof link !== 'object' || Array.isArray(link)) {
    return { errors, warnings };
  }
  const type = firstString(link.type);
  if (type === 'url') {
    errors.push(stageBIssue('stage_b_link_type_url_invalid', 'p0', `${owner} uses link type "url"; use Bricks type "external" for plain URLs.`));
  }
  if (type === 'external' && !firstString(link.url)) {
    errors.push(stageBIssue('stage_b_external_link_missing_url', 'p0', `${owner} external link is missing url.`));
  }
  if (type === 'internal' && !firstString(link.postId, link.post_id, link.url)) {
    warnings.push(stageBIssue('stage_b_internal_link_missing_target', 'p1', `${owner} internal link should include a postId target.`));
  }
  return { errors, warnings };
}

function buildStageBGlobalClassMap(globalClasses) {
  const map = new Map();
  for (const item of Array.isArray(globalClasses) ? globalClasses : []) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
    const id = firstString(item.id);
    const name = firstString(item.name);
    if (id) map.set(id, item);
    if (name) map.set(name, item);
  }
  return map;
}

function resolveStageBElementStyleSettings(element, globalClassById) {
  const settings = objectValue(element?.settings);
  const resolved = {};
  const classIds = Array.isArray(settings._cssGlobalClasses) ? settings._cssGlobalClasses : [];
  for (const classId of classIds) {
    const classItem = globalClassById.get(firstString(classId));
    if (classItem) {
      mergePixflowBricksSettingsInto(resolved, objectValue(classItem.settings));
    }
  }
  mergePixflowBricksSettingsInto(resolved, settings);
  return resolved;
}

function inspectStageBTemplateSectionPaddingContract(templateContent, globalClasses, partLabel) {
  const errors = [];
  const warnings = [];
  const content = Array.isArray(templateContent) ? templateContent : [];
  const globalClassById = buildStageBGlobalClassMap(globalClasses);
  const rootSections = content.filter((element) => (
    element
    && typeof element === 'object'
    && firstString(element.name) === 'section'
    && !firstString(element.parent)
  ));
  for (const root of rootSections) {
    if (!hasStageBTemplateSectionPaddingOverride(root, globalClassById)) {
      errors.push(stageBIssue(
        `stage_b_${partLabel}_template_section_padding_uncontrolled`,
        'p0',
        `${capitalizeStageBLabel(partLabel)} top-level section "${describeStageBElementForIssue(root)}" must set source-accurate top/bottom padding on the element or a global class; otherwise page section theme-style padding can change the template height.`,
      ));
    }
  }
  return { errors, warnings };
}

function hasStageBTemplateSectionPaddingOverride(element, globalClassById) {
  const settings = objectValue(element?.settings);
  if (hasStageBTopBottomPadding(settings)) {
    return true;
  }
  const classIds = Array.isArray(settings._cssGlobalClasses) ? settings._cssGlobalClasses : [];
  for (const classId of classIds) {
    const classItem = globalClassById.get(firstString(classId));
    if (classItem && hasStageBTopBottomPadding(objectValue(classItem.settings))) {
      return true;
    }
  }
  return false;
}

function hasStageBTopBottomPadding(settings) {
  const padding = objectValue(settings?._padding);
  return firstString(padding.top) !== '' && firstString(padding.bottom) !== '';
}

function describeStageBElementForIssue(element) {
  const settings = objectValue(element?.settings);
  return firstString(settings._cssId, element?.id, element?.name, 'unknown');
}

function capitalizeStageBLabel(value) {
  const label = firstString(value, 'template');
  return `${label.slice(0, 1).toUpperCase()}${label.slice(1)}`;
}

function stageBGridColumnCountHint(value) {
  const source = firstString(value).trim();
  if (!source) return 0;
  const repeatMatch = source.match(/\brepeat\(\s*(\d+)\s*,/i);
  if (repeatMatch) {
    return Number(repeatMatch[1]) || 1;
  }
  const tracks = [];
  let depth = 0;
  let current = '';
  for (const char of source) {
    if (char === '(') depth += 1;
    if (char === ')') depth = Math.max(0, depth - 1);
    if (/\s/.test(char) && depth === 0) {
      if (current.trim()) tracks.push(current.trim());
      current = '';
      continue;
    }
    current += char;
  }
  if (current.trim()) tracks.push(current.trim());
  return tracks.length || 1;
}

function inspectStageBHeaderLayoutContract(headerContent, headerSpec = {}, globalClasses = []) {
  const errors = [];
  const warnings = [];
  const content = Array.isArray(headerContent) ? headerContent : [];
  const byId = new Map();
  const globalClassById = buildStageBGlobalClassMap(globalClasses);
  for (const element of content) {
    if (element && typeof element === 'object' && !Array.isArray(element)) {
      const id = firstString(element.id);
      if (id) byId.set(id, element);
    }
  }

  const rootSections = content.filter((element) => (
    element
    && typeof element === 'object'
    && firstString(element.name) === 'section'
    && !firstString(element.parent)
  ));
  const selectedSectionOdId = firstString(
    headerSpec.sourceSectionOdId,
    headerSpec.selectedSectionOdId,
    headerSpec.source_section_od_id,
    headerSpec.selected_section_od_id,
  );
  const matchesSelectedHeaderSection = (element) => {
    if (!selectedSectionOdId) return false;
    const settings = objectValue(element?.settings);
    const attrValues = (Array.isArray(settings._attributes) ? settings._attributes : [])
      .map((attribute) => objectValue(attribute))
      .filter((attribute) => ['data-od-id', 'id'].includes(firstString(attribute.name)));
    return firstString(settings._cssId) === selectedSectionOdId
      || attrValues.some((attribute) => firstString(attribute.value) === selectedSectionOdId)
      || firstString(element?.id) === selectedSectionOdId;
  };

  const root = selectedSectionOdId
    ? rootSections.find(matchesSelectedHeaderSection)
    : rootSections[0];
  if (!root) {
    errors.push(stageBIssue(
      selectedSectionOdId ? 'stage_b_header_selected_section_missing' : 'stage_b_header_root_section_missing',
      'p0',
      selectedSectionOdId
        ? `Header payload must include the selected source header section "${selectedSectionOdId}" as a top-level section.`
        : 'Header payload must include one top-level section for the Bricks header template.',
    ));
    return { errors, warnings };
  }

  for (const rootSection of rootSections) {
    if (!hasStageBTemplateSectionPaddingOverride(rootSection, globalClassById)) {
      errors.push(stageBIssue(
        'stage_b_header_template_section_padding_uncontrolled',
        'p0',
        `Header top-level section "${describeStageBElementForIssue(rootSection)}" must set source-accurate top/bottom padding on the element or a global class; otherwise Pixflow Framework page section padding can create blank header bands.`,
      ));
    }
  }

  const rootChildren = (Array.isArray(root.children) ? root.children : [])
    .map((id) => byId.get(firstString(id)))
    .filter(Boolean);
  const inner = rootChildren.find((element) => ['container', 'block', 'div'].includes(firstString(element.name)));
  if (!inner) {
    errors.push(stageBIssue('stage_b_header_inner_wrapper_missing', 'p0', 'Header section must contain a container or block inner wrapper.'));
    return { errors, warnings };
  }

  const innerId = firstString(inner.id);
  const innerSettings = resolveStageBElementStyleSettings(inner, globalClassById);
  const innerRequired = {
    _display: 'flex',
    _direction: 'row',
    _alignItems: '',
    _justifyContent: '',
    _columnGap: '',
    _rowGap: '',
  };
  for (const [key, expected] of Object.entries(innerRequired)) {
    const value = firstString(innerSettings[key]);
    if (!value || (expected && value !== expected)) {
      errors.push(stageBIssue('stage_b_header_inner_layout_incomplete', 'p0', `Header inner wrapper "${innerId}" must set ${key}${expected ? ` to "${expected}"` : ''}.`));
    }
  }
  if (!firstString(innerSettings['_direction:mobile_portrait'], innerSettings['_direction:tablet_portrait'])) {
    warnings.push(stageBIssue('stage_b_header_inner_responsive_direction_missing', 'p1', `Header inner wrapper "${innerId}" should include a responsive _direction override for narrow screens.`));
  }

  const innerChildren = content.filter((element) => firstString(element?.parent) === innerId);
  const navMenu = innerChildren.find((element) => firstString(element?.name) === 'nav-menu');
  const nav = navMenu || innerChildren.find((element) => {
    if (!['block', 'container', 'div'].includes(firstString(element?.name))) return false;
    const childIds = Array.isArray(element.children) ? element.children : [];
    return childIds.some((id) => firstString(byId.get(firstString(id))?.name) === 'button');
  });
  if (!nav) {
    errors.push(stageBIssue('stage_b_header_nav_block_missing', 'p0', 'Header inner wrapper must contain a Bricks nav-menu element or a fallback nav/action block with CTA button children.'));
    return { errors, warnings };
  }

  if (firstString(nav.name) === 'nav-menu') {
    return { errors, warnings };
  }

  const navId = firstString(nav.id);
  const navSettings = resolveStageBElementStyleSettings(nav, globalClassById);
  const navRequired = {
    _display: 'flex',
    _direction: 'row',
    _flexWrap: 'wrap',
    _alignItems: '',
    _justifyContent: '',
    _columnGap: '',
    _rowGap: '',
  };
  for (const [key, expected] of Object.entries(navRequired)) {
    const value = firstString(navSettings[key]);
    if (!value || (expected && value !== expected)) {
      errors.push(stageBIssue('stage_b_header_nav_layout_incomplete', 'p0', `Header nav/action block "${navId}" must set ${key}${expected ? ` to "${expected}"` : ''}.`));
    }
  }

  return { errors, warnings };
}

function inspectStageBElementAttributes(settings, elementId) {
  const errors = [];
  const warnings = [];
  if (!Object.prototype.hasOwnProperty.call(settings, '_attributes')) {
    return { errors, warnings };
  }
  if (!Array.isArray(settings._attributes)) {
    errors.push(stageBIssue('stage_b_attributes_invalid', 'p0', `Element "${elementId}" _attributes must be an array.`));
    return { errors, warnings };
  }
  settings._attributes.forEach((attribute, index) => {
    if (!attribute || typeof attribute !== 'object' || Array.isArray(attribute)) {
      errors.push(stageBIssue('stage_b_attribute_invalid', 'p0', `Element "${elementId}" _attributes[${index}] must be an object.`));
      return;
    }
    const id = firstString(attribute.id);
    const name = firstString(attribute.name);
    if (!id || !name) {
      errors.push(stageBIssue('stage_b_attribute_missing_identity', 'p0', `Element "${elementId}" _attributes[${index}] requires id and name.`));
    }
    if (name && !/^(?:data|aria)-[A-Za-z0-9_-]+$|^(?:id|role|tabindex|title|href)$/i.test(name)) {
      warnings.push(stageBIssue('stage_b_attribute_unusual_name', 'p1', `Element "${elementId}" _attributes[${index}] uses unusual attribute "${name}".`));
    }
    if (/^on/i.test(name)) {
      errors.push(stageBIssue('stage_b_attribute_inline_handler', 'p0', `Element "${elementId}" must not use inline event handler attribute "${name}".`));
    }
  });
  return { errors, warnings };
}

function countCssVariableDeclarations(cssText) {
  const matches = String(cssText || '').match(/--[A-Za-z][A-Za-z0-9_-]*\s*:/g);
  return Array.isArray(matches) ? matches.length : 0;
}

function countStageBRootCssVariableDeclarations(cssText) {
  const rules = extractStageBCssRuleSummaries(cssText);
  let count = 0;
  for (const rule of rules) {
    const selectors = splitPixflowCssSelectorList(rule.selector);
    if (!selectors.some((selector) => /^%root%\s*$/i.test(selector.trim()))) {
      continue;
    }
    count += Object.keys(objectValue(rule.declarations)).filter((key) => /^--[A-Za-z0-9_-]+$/.test(key)).length;
  }
  return count;
}

function collectStageBLocalAssetRefs(settings) {
  const refs = [];
  collectStageBAssetRefsFromValue(settings?.image, refs);
  collectStageBAssetRefsFromValue(settings?.src, refs);
  collectStageBAssetRefsFromValue(settings?.url, refs);
  collectStageBAssetRefsFromValue(settings?._background, refs);
  return [...new Set(refs.filter((ref) => isStageBLocalAssetRef(ref)))];
}

function collectStageBAssetRefsFromValue(value, refs) {
  if (!value) return;
  if (typeof value === 'string') {
    refs.push(value);
    return;
  }
  if (typeof value !== 'object' || Array.isArray(value)) return;
  for (const key of ['url', 'src', 'image', 'background', 'raw']) {
    if (typeof value[key] === 'string') {
      refs.push(value[key]);
    } else if (value[key] && typeof value[key] === 'object') {
      collectStageBAssetRefsFromValue(value[key], refs);
    }
  }
}

function isStageBLocalAssetRef(ref) {
  const value = String(ref || '').trim();
  if (!value || value.startsWith('#') || value.startsWith('data:')) return false;
  if (/^(?:https?:|blob:|mailto:|tel:)/i.test(value)) return false;
  return /\.(?:avif|gif|jpe?g|png|svg|webp)(?:[?#].*)?$/i.test(value);
}

function stageBLocalAssetExists(workspaceDir, ref) {
  const cleanRef = String(ref || '').split('#')[0].split('?')[0].replace(/^\.?\//, '');
  if (!cleanRef || cleanRef.includes('..')) return false;
  return existsSync(path.join(workspaceDir, cleanRef))
    || existsSync(path.join(workspaceDir, 'stage-a', 'drafts', cleanRef))
    || existsSync(path.join(workspaceDir, 'stage-a', cleanRef));
}

function stageBIssue(id, severity, message) {
  return { id, severity, qa_severity: severity, message };
}

function summarizeStageBQa(qa) {
  return {
    status: firstString(qa?.status, 'unknown'),
    blocking: Boolean(qa?.blocking),
    score: Number(qa?.score || 0),
    severity: qa?.severity || {},
    qualityGate: qa?.qualityGate
      ? {
          passed: qa.qualityGate.passed === true,
          minScore: Number(qa.qualityGate.minScore || 0),
          allowP1: qa.qualityGate.allowP1 === true,
          allowLowQa: qa.qualityGate.allowLowQa === true,
          failures: Array.isArray(qa.qualityGate.failures) ? qa.qualityGate.failures.map((failure) => firstString(failure)).filter(Boolean) : [],
        }
      : null,
    issueCount: Array.isArray(qa?.issues) ? qa.issues.length : 0,
    issues: (Array.isArray(qa?.issues) ? qa.issues : []).slice(0, 12).map((issue) => ({
      id: firstString(issue?.id),
      severity: firstString(issue?.severity, issue?.qa_severity),
      message: firstString(issue?.message),
    })),
  };
}

function parseStageBQualityPolicy(flags = {}) {
  const minScore = Math.min(100, parseNonNegativeIntegerFlag(
    firstString(flags.stageBMinScore, flags.stage_b_min_score, flags.minStageBScore, flags.min_score, flags.minScore),
    DEFAULT_STAGE_B_MIN_QA_SCORE
  ));
  return {
    minScore,
    allowP1: isTruthyFlag(firstDefined(flags.stageBAllowP1, flags.stage_b_allow_p1, flags.allowStageBP1, flags.allow_stage_b_p1, flags.allowP1)),
    allowLowQa: isTruthyFlag(firstDefined(flags.allowLowStageBQa, flags.allow_low_stage_b_qa, flags.skipStageBQaGate, flags.skip_stage_b_qa_gate)),
  };
}

function applyStageBQualityGate(qa, policyInput = {}) {
  const policy = parseStageBQualityPolicy(policyInput);
  const qualityGate = buildStageBQualityGate(qa, policy);
  const result = {
    ...qa,
    qualityGate,
  };
  if (!qualityGate.passed) {
    result.status = 'failed';
    result.blocking = true;
  }
  return result;
}

function buildStageBQualityGate(qa, policyInput = {}) {
  const policy = parseStageBQualityPolicy(policyInput);
  const severity = normalizedStageBSeverityCounts(qa);
  const score = Number.isFinite(Number(qa?.score)) ? Number(qa.score) : 0;
  const failures = [];
  if (severity.p0 > 0) {
    failures.push(`P0 issues remaining: ${severity.p0}`);
  }
  if (!policy.allowLowQa && score < policy.minScore) {
    failures.push(`QA score ${score} is below required minimum ${policy.minScore}`);
  }
  if (!policy.allowLowQa && !policy.allowP1 && severity.p1 > 0) {
    failures.push(`P1 repair-required issues remaining: ${severity.p1}`);
  }
  return {
    passed: failures.length === 0,
    minScore: policy.minScore,
    allowP1: policy.allowP1,
    allowLowQa: policy.allowLowQa,
    score,
    severity,
    failures,
  };
}

function normalizedStageBSeverityCounts(qa) {
  const severity = objectValue(qa?.severity);
  if (Object.keys(severity).length > 0) {
    return {
      p0: Number(severity.p0 || 0),
      p1: Number(severity.p1 || 0),
      p2: Number(severity.p2 || 0),
    };
  }
  return severityCounts(Array.isArray(qa?.issues) ? qa.issues : []);
}

function stageBQaNeedsRepair(qa, policyInput = {}) {
  return buildStageBQualityGate(qa, policyInput).passed !== true;
}

function firstDefined(...values) {
  for (const value of values) {
    if (typeof value !== 'undefined') return value;
  }
  return undefined;
}

function isTruthyFlag(value) {
  if (value === true || value === 1) return true;
  return /^(?:1|true|yes|on)$/i.test(String(value || '').trim());
}

function renderStageBRepairPrompt(prepared, qa, attempt, maxAttempts, policyInput = {}) {
  const qualityPolicy = parseStageBQualityPolicy(policyInput);
  const qualityGate = buildStageBQualityGate(qa, qualityPolicy);
  const severityRank = { p0: 0, p1: 1, p2: 2 };
  const repairSeverities = new Set(['p0']);
  if (!qualityPolicy.allowLowQa) {
    repairSeverities.add('p1');
    if (Number(qa?.score || 0) < qualityPolicy.minScore) {
      repairSeverities.add('p2');
    }
  }
  const issueLines = (Array.isArray(qa?.issues) ? qa.issues : [])
    .filter((issue) => repairSeverities.has(firstString(issue?.severity, issue?.qa_severity, 'p2').toLowerCase()))
    .sort((a, b) => (severityRank[firstString(a?.severity, a?.qa_severity, 'p2').toLowerCase()] ?? 9)
      - (severityRank[firstString(b?.severity, b?.qa_severity, 'p2').toLowerCase()] ?? 9))
    .slice(0, 36)
    .map((issue) => {
      const severity = firstString(issue?.severity, issue?.qa_severity, 'p2').toUpperCase();
      return `- ${severity} ${firstString(issue.id, 'stage_b_issue')}: ${firstString(issue.message)}`;
    });
  const lines = [];
  lines.push('You are repairing Pixflow Design Stage B Bricks JSON.');
  lines.push('');
  lines.push(`Repair attempt ${attempt} of ${maxAttempts}.`);
  lines.push('');
  lines.push('The Stage A artifact is already accepted. Do not redesign the page, rename the project, change content strategy, or remove sections to make QA easier.');
  lines.push('');
  lines.push(`Local QA gate: score must be at least ${qualityPolicy.minScore}, P0 must be zero, and P1 must be zero${qualityPolicy.allowP1 ? ' unless explicitly allowed' : ''}.`);
  lines.push(`Current QA: status ${firstString(qa?.status, 'unknown')}, score ${Number(qa?.score || 0)}, severity ${JSON.stringify(normalizedStageBSeverityCounts(qa))}.`);
  if (qualityGate.failures.length > 0) {
    lines.push(`Gate failures: ${qualityGate.failures.join('; ')}.`);
  }
  lines.push('');
  lines.push('Files you may edit:');
  lines.push(`- ${path.basename(prepared.resultFile)}: main Stage B result; keep content/global_classes/stage_b_header/stage_b_footer synchronized.`);
  lines.push(`- ${path.basename(prepared.payloadFile)}: must exactly mirror bricks-result.json content.`);
  lines.push(`- ${path.basename(prepared.headerPayloadFile)}: must exactly mirror bricks-result.json stage_b_header.content when a header is included.`);
  lines.push(`- ${path.basename(prepared.footerPayloadFile)}: must exactly mirror bricks-result.json stage_b_footer.content when a footer is included.`);
  lines.push(`- ${path.basename(prepared.globalClassesFile)}: must exactly mirror bricks-result.json global_classes.`);
  lines.push('- conversion-report.md: update only if the repair changes mapping or preservation notes.');
  lines.push('');
  lines.push('Repair-required QA issues to fix:');
  lines.push(issueLines.length > 0 ? issueLines.join('\n') : '- No detailed QA issue lines were recorded; rerun QA after checking result consistency and sidecar parity.');
  lines.push('');
  lines.push('Targeted craft repair rules:');
  lines.push('- If an issue mentions Pixflow SVG icon styling, move SVG icon size/colour to a global class `settings.icon` object with `height`, `width`, `stroke`, optional `strokeWidth`, and optional `fill`; do not use `iconSize` or `iconColor` for SVG icons.');
  lines.push('- If an issue mentions stat rings, avoid a dashed border on the stat container. Build a circular number element plus separate label text and preserve the source geometry.');
  lines.push('- If an issue mentions plate borders, remove added solid borders unless the accepted Stage A source visibly had that border.');
  lines.push('- If an issue mentions row, action, nav, wrapper, or marquee layout, set `_display: "flex"` and `_direction: "row"` on the same Bricks element or class, plus `_flexWrap` only when the source allows wrapping.');
  lines.push('- If an issue mentions responsive header direction, add suffixed Bricks controls such as `_direction:mobile_portrait` to the actual inner wrapper, not an unrelated child.');
  lines.push('');
  lines.push('Header contract when stage_b_header.includeHeader is true:');
  lines.push('- Keep header elements in stage_b_header.content, not in the normal page content array.');
  lines.push('- Repair the approved source header section identified by stage_b_header.sourceSectionOdId or stage-b-header-plan.json.selectedSectionOdId. Source-backed rails/topbar may stay as auxiliary bands, but they are not the nav/header wrapper unless that selected section id says so.');
  lines.push('- The header section must contain an inner container/block wrapper with explicit Bricks settings: _display "flex", _direction "row", _alignItems, _justifyContent, _columnGap, and _rowGap.');
  lines.push('- The nav/action block must have explicit Bricks settings: _display "flex", _direction "row", _flexWrap "wrap", _alignItems, _justifyContent, _columnGap, and _rowGap.');
  lines.push('- Add responsive suffixed settings where needed, for example _direction:mobile_portrait "column" on the inner wrapper.');
  lines.push('');
  lines.push('Footer contract when stage_b_footer.includeFooter is true:');
  lines.push('- Keep footer elements in stage_b_footer.content, not in the normal page content array.');
  lines.push('- Preserve footer links, brand/copyright text, closing CTA/caption rhythm, and template scope.');
  lines.push('');
  lines.push('General Stage B contract:');
  lines.push('- Use Bricks underscore settings, not raw unprefixed layout keys.');
  lines.push('- Heading elements must use `settings.tag` for `h1`-`h6`; replace any `tagName` fields because Bricks ignores them.');
  lines.push('- Preserve data attributes from Stage A and place any safe source JavaScript in page settings, not Bricks code elements.');
  lines.push('- Do not use .od-root, --od-* token leakage, dashed stat approximations, incorrect extra wrapper structures, or %root%::before/after for visible dividers that can be Bricks child elements.');
  lines.push('- Keep global class IDs valid and children/parent references consistent.');
  lines.push('');
  lines.push('After editing, stop. The CLI will rerun local Stage B QA.');
  return lines.join('\n');
}

function assertStageBQaPasses(qa, policyInput = {}) {
  const qualityGate = buildStageBQualityGate(qa, policyInput);
  if (!qualityGate.passed) {
    const failureSummary = qualityGate.failures.length > 0 ? ` ${qualityGate.failures.join('; ')}.` : '';
    throw new CliError(`Stage B local QA failed.${failureSummary}`, {
      ...qa,
      qualityGate,
    });
  }
}

function assertStageBRemoteQaReady(qa, qaFile, flags, label) {
  if (!qa || typeof qa !== 'object' || Array.isArray(qa) || Object.keys(qa).length === 0) {
    throw new CliError(`${label} requires a local Stage B QA report before remote import/insert: ${qaFile}`);
  }
  assertStageBQaPasses(qa, parseStageBQualityPolicy(flags));
}

function buildPreparedStageAFromWorkspace(workspaceDir) {
  const metadataFile = path.join(workspaceDir, 'metadata.json');
  return {
    status: 'prepared',
    workspaceDir,
    sourceId: path.basename(workspaceDir),
    title: path.basename(workspaceDir),
    promptFile: path.join(workspaceDir, 'prompt.md'),
    instructionsFile: path.join(workspaceDir, 'AGENTS.md'),
    todoFile: path.join(workspaceDir, 'TODO.md'),
    runnerPromptFile: path.join(workspaceDir, 'codex-stage-a-prompt.txt'),
    metadataFile,
    artifactFile: path.join(workspaceDir, 'drafts', 'index.html'),
    screenshotsDir: path.join(workspaceDir, 'screenshots'),
    qaFile: path.join(workspaceDir, 'stage-a-qa.json'),
    importCommand: [
      'node',
      'tools/pixflow-design-cli/pixflow-design-cli.mjs',
      'import-artifact',
      '--config',
      './pixflow-design-cli.config.json',
      '--html',
      quoteForShell(path.join(workspaceDir, 'drafts', 'index.html')),
      '--prompt-file',
      quoteForShell(path.join(workspaceDir, 'prompt.md')),
      '--metadata-file',
      quoteForShell(metadataFile),
    ].join(' '),
  };
}

async function collectStageAEventFiles(workspaceDir) {
  let entries = [];
  try {
    entries = await fs.readdir(workspaceDir);
  } catch {
    return [];
  }
  return entries
    .filter((entry) => /^stage-a-codex(?:-repair-\d+)?-events\.jsonl$/i.test(entry))
    .sort((a, b) => {
      const aRepair = Number(a.match(/repair-(\d+)/)?.[1] || 0);
      const bRepair = Number(b.match(/repair-(\d+)/)?.[1] || 0);
      return aRepair - bRepair || a.localeCompare(b);
    })
    .map((entry) => path.join(workspaceDir, entry));
}

function buildStageARunnerInvocation(prepared, flags, overrides = {}) {
  const customCommand = firstString(flags.runnerCommand);
  if (customCommand) {
    const command = customCommand
      .replace(/\{workspace\}/g, prepared.workspaceDir)
      .replace(/\{prompt\}/g, prepared.promptFile)
      .replace(/\{artifact\}/g, prepared.artifactFile);
    return {
      kind: 'custom_shell',
      display: command,
      command,
      shell: true,
      stdin: null,
      eventsFile: overrides.eventsFile || path.join(prepared.workspaceDir, 'stage-a-runner-events.log'),
      stderrFile: overrides.stderrFile || path.join(prepared.workspaceDir, 'stage-a-runner-stderr.log'),
    };
  }

  return buildBridgeStageRunnerInvocation('stage-a', prepared, flags, overrides);
}

function buildBridgeStageRunnerInvocation(stage, prepared, flags, overrides = {}) {
  const runnerId = normalizeBridgeRunnerId(firstString(flags.runner, flags.agent, 'codex'));
  const agent = BRIDGE_AGENT_CATALOG.find((item) => item.id === runnerId);
  if (!agent) {
    throw new CliError(`Unknown local CLI runner "${runnerId}". Use one of: ${BRIDGE_AGENT_CATALOG.map((item) => item.id).join(', ')}.`);
  }
  if (!BRIDGE_STAGE_RUNNER_AGENT_IDS.has(agent.id)) {
    throw new CliError(`${agent.label} is detected/installable, but Pixflow does not yet have a verified non-interactive Stage A/B adapter for it. Select a runner-ready provider or use --runner-command.`);
  }

  const command = detectFirstCommandSync(agent);
  if (!command.path) {
    throw new CliError(`${agent.label} was selected, but none of these commands were found on this machine: ${agent.commands.join(', ')}.`);
  }

  const runnerSpec = buildBridgeStageRunnerSpec(agent.id, prepared, flags);
  const stagePrefix = stage === 'stage-b' ? 'stage-b' : 'stage-a';
  const safeRunnerId = agent.id.replace(/[^a-z0-9-]/g, '-');
  const args = Array.isArray(runnerSpec.args) ? runnerSpec.args : [];
  return {
    kind: agent.id,
    display: [quoteForShell(command.path), ...args.map(quoteForShell)].join(' '),
    command: command.path,
    args,
    shell: false,
    stdinFile: runnerSpec.stdinFile || overrides.stdinFile || prepared.runnerPromptFile,
    stdin: runnerSpec.stdin ?? null,
    env: runnerSpec.env || {},
    eventsFile: overrides.eventsFile || path.join(prepared.workspaceDir, `${stagePrefix}-${safeRunnerId}-events.jsonl`),
    stderrFile: overrides.stderrFile || path.join(prepared.workspaceDir, `${stagePrefix}-${safeRunnerId}-stderr.log`),
  };
}

function buildBridgeStageRunnerSpec(runnerId, prepared, flags) {
  const model = firstString(flags.model);
  if (runnerId === 'codex') {
    const args = [
      'exec',
      '--json',
      '--skip-git-repo-check',
      '--sandbox',
      'danger-full-access',
      '--cd',
      prepared.workspaceDir,
    ];
    if (model && model !== 'default') {
      args.push('--model', model);
    }
    const reasoning = firstString(flags.reasoning, flags.reasoningEffort);
    if (reasoning && reasoning !== 'default') {
      args.push('-c', `model_reasoning_effort="${reasoning}"`);
    }
    args.push('-');
    return { args };
  }

  if (runnerId === 'claude') {
    const args = ['-p', '--output-format', 'stream-json', '--verbose', '--permission-mode', 'bypassPermissions'];
    if (model && model !== 'default') {
      args.push('--model', model);
    }
    return { args };
  }

  if (runnerId === 'gemini') {
    const args = ['--output-format', 'stream-json', '--yolo'];
    if (model && model !== 'default') {
      args.push('--model', model);
    }
    return {
      args,
      env: { GEMINI_CLI_TRUST_WORKSPACE: 'true' },
    };
  }

  if (runnerId === 'opencode') {
    const args = ['run', '--format', 'json'];
    if (model && model !== 'default') {
      args.push('-m', model);
    }
    return { args };
  }

  if (runnerId === 'cursor-agent') {
    const args = [
      '--print',
      '--output-format',
      'stream-json',
      '--stream-partial-output',
      '--force',
      '--trust',
      '--workspace',
      prepared.workspaceDir,
    ];
    if (model && model !== 'default') {
      args.push('--model', model);
    }
    return { args };
  }

  if (runnerId === 'qwen') {
    const args = ['--yolo'];
    if (model && model !== 'default') {
      args.push('--model', model);
    }
    return { args };
  }

  throw new CliError(`Pixflow has no Stage A/B runner adapter for "${runnerId}".`);
}

function normalizeBridgeRunnerId(value) {
  const raw = firstString(value, 'codex').toLowerCase().trim().replace(/_/g, '-');
  return BRIDGE_STAGE_RUNNER_ALIASES.get(raw) || raw;
}

async function runStageAInvocation(invocation, cwd) {
  return runLocalInvocation(invocation, cwd, 'Stage A');
}

async function runLocalInvocation(invocation, cwd, label) {
  const liveOutput = invocation.jsonOutput ? process.stderr : process.stdout;
  liveOutput.write(`Running ${label} command in ${cwd}\n${invocation.display}\n`);
  const stdoutFile = invocation.eventsFile ? createWriteStream(invocation.eventsFile, { flags: 'w' }) : null;
  const stderrFile = invocation.stderrFile ? createWriteStream(invocation.stderrFile, { flags: 'w' }) : null;
  const stdin = invocation.stdinFile ? await fs.readFile(invocation.stdinFile, 'utf8') : invocation.stdin;
  const eventSummary = {
    stdoutBytes: 0,
    stderrBytes: 0,
    jsonEventCount: 0,
    usage: null,
  };

  return new Promise((resolve, reject) => {
    const child = invocation.shell
      ? spawn(invocation.command, {
          cwd,
          shell: true,
          env: { ...process.env, ...(invocation.env || {}) },
          stdio: ['pipe', 'pipe', 'pipe'],
          windowsHide: false,
        })
      : spawn(invocation.command, invocation.args || [], {
          cwd,
          shell: false,
          env: { ...process.env, ...(invocation.env || {}) },
          stdio: ['pipe', 'pipe', 'pipe'],
          windowsHide: false,
        });

    child.stdout?.on('data', (chunk) => {
      eventSummary.stdoutBytes += chunk.length;
      liveOutput.write(chunk);
      stdoutFile?.write(chunk);
      const text = chunk.toString('utf8');
      for (const line of text.split(/\r?\n/)) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('{')) continue;
        try {
          const parsed = JSON.parse(trimmed);
          eventSummary.jsonEventCount += 1;
          const usage = extractUsageFromRunnerEvent(parsed);
          if (usage) eventSummary.usage = usage;
        } catch {
          // Runner output can include non-event lines; keep the raw log.
        }
      }
    });

    child.stderr?.on('data', (chunk) => {
      eventSummary.stderrBytes += chunk.length;
      process.stderr.write(chunk);
      stderrFile?.write(chunk);
    });

    if (stdin !== null && stdin !== undefined) {
      child.stdin?.end(stdin);
    } else {
      child.stdin?.end();
    }

    child.on('error', (error) => {
      stdoutFile?.end();
      stderrFile?.end();
      reject(new CliError(`Could not launch ${label} runner: ${error.message}`));
    });

    child.on('close', (code) => {
      stdoutFile?.end();
      stderrFile?.end();
      if (code !== 0) {
        reject(new CliError(`${label} runner exited with code ${code}.`));
        return;
      }
      resolve({
        code: code || 0,
        kind: invocation.kind,
        eventSummary,
        eventsFile: invocation.eventsFile || null,
        stderrFile: invocation.stderrFile || null,
      });
    });
  });
}

async function combineStageAEventLogs(workspaceDir, eventFiles) {
  const uniqueFiles = [...new Set((eventFiles || []).filter(Boolean))];
  if (uniqueFiles.length <= 1) {
    return uniqueFiles[0] || '';
  }

  const combinedFile = path.join(workspaceDir, 'stage-a-codex-events-combined.jsonl');
  const parts = [];
  for (const file of uniqueFiles) {
    const text = await readOptionalText(file);
    if (!text.trim()) {
      continue;
    }
    parts.push(text.endsWith('\n') ? text : `${text}\n`);
  }
  await writeTextFile(combinedFile, parts.join(''));
  return combinedFile;
}

function mergeStageAEventSummaries(previous, next) {
  if (!previous) return next || null;
  if (!next) return previous || null;
  return {
    stdoutBytes: Number(previous.stdoutBytes || 0) + Number(next.stdoutBytes || 0),
    stderrBytes: Number(previous.stderrBytes || 0) + Number(next.stderrBytes || 0),
    jsonEventCount: Number(previous.jsonEventCount || 0) + Number(next.jsonEventCount || 0),
    usage: mergeUsage(previous.usage, next.usage),
  };
}

function mergeUsage(previous, next) {
  if (!previous) return next || null;
  if (!next) return previous || null;
  const keys = new Set([...Object.keys(previous), ...Object.keys(next)]);
  const merged = {};
  for (const key of keys) {
    const previousValue = previous[key];
    const nextValue = next[key];
    if (typeof previousValue === 'number' || typeof nextValue === 'number') {
      merged[key] = Number(previousValue || 0) + Number(nextValue || 0);
    } else {
      merged[key] = nextValue ?? previousValue;
    }
  }
  return merged;
}

async function writeStageAToolTrace(workspaceDir, runnerResult, qa) {
  const traceFile = path.join(workspaceDir, 'stage-a-tool-trace.md');
  const eventsFile = runnerResult?.eventsFile || '';
  const eventText = eventsFile ? await readOptionalText(eventsFile) : '';
  const events = [];
  for (const line of eventText.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed.startsWith('{')) continue;
    const parsed = parseJsonText(trimmed);
    if (Object.keys(parsed).length > 0) {
      events.push(parsed);
    }
  }

  const commands = [];
  const fileChanges = [];
  const todoUpdates = [];
  const messages = [];
  const otherItems = {};

  for (const event of events) {
    const item = objectValue(event.item || event.data?.item || event.msg?.item);
    const itemType = firstString(item.type, event.type);
    if (itemType === 'command_execution') {
      commands.push({
        command: firstString(item.command),
        status: firstString(item.status),
        exitCode: item.exit_code ?? item.exitCode ?? null,
        output: firstString(item.aggregated_output, item.output),
      });
      continue;
    }
    if (itemType === 'file_change') {
      const changes = Array.isArray(item.changes) ? item.changes : [];
      for (const change of changes) {
        fileChanges.push({
          path: firstString(change.path, change.file),
          action: firstString(change.type, change.action, 'change'),
        });
      }
      continue;
    }
    if (itemType === 'todo_list') {
      todoUpdates.push(item);
      continue;
    }
    if (itemType === 'agent_message') {
      messages.push(firstString(item.text, item.content));
      continue;
    }
    if (itemType) {
      otherItems[itemType] = (otherItems[itemType] || 0) + 1;
    }
  }

  const lines = [];
  lines.push('# Stage A Tool Trace');
  lines.push('');
  lines.push(`- Events file: ${eventsFile || '-'}`);
  lines.push(`- Event count: ${events.length}`);
  lines.push(`- Command executions: ${commands.length}`);
  lines.push(`- File changes: ${fileChanges.length}`);
  lines.push(`- Agent messages: ${messages.length}`);
  lines.push(`- QA status: ${qa?.status || '-'}${typeof qa?.score === 'number' ? ` (${qa.score})` : ''}`);
  if (runnerResult?.eventSummary?.usage) {
    lines.push(`- Usage: ${JSON.stringify(runnerResult.eventSummary.usage)}`);
  }
  if (Object.keys(otherItems).length > 0) {
    lines.push(`- Other item types: ${JSON.stringify(otherItems)}`);
  }
  lines.push('');
  lines.push('## Commands');
  if (commands.length === 0) {
    lines.push('- None observed.');
  } else {
    commands.forEach((command, index) => {
      lines.push(`- ${index + 1}. ${command.command || '(unknown command)'}${command.exitCode !== null ? ` [exit ${command.exitCode}]` : ''}`);
      const output = command.output.replace(/\s+/g, ' ').trim();
      if (output) {
        lines.push(`  - Output: ${output.slice(0, 500)}${output.length > 500 ? '...' : ''}`);
      }
    });
  }
  lines.push('');
  lines.push('## File Changes');
  if (fileChanges.length === 0) {
    lines.push('- None observed.');
  } else {
    for (const change of fileChanges) {
      lines.push(`- ${change.action}: ${change.path || '-'}`);
    }
  }
  lines.push('');
  lines.push('## TODO Updates');
  if (todoUpdates.length === 0) {
    lines.push('- None observed in the event stream.');
  } else {
    todoUpdates.forEach((todo, index) => {
      const items = Array.isArray(todo.items) ? todo.items : [];
      lines.push(`- Update ${index + 1}: ${items.length} items`);
      for (const item of items.slice(0, 20)) {
        lines.push(`  - ${firstString(item.status, '-')}: ${firstString(item.text, item.content, '-')}`);
      }
    });
  }
  lines.push('');
  lines.push('## Agent Messages');
  if (messages.length === 0) {
    lines.push('- None observed.');
  } else {
    messages.forEach((message, index) => {
      const text = message.replace(/\s+/g, ' ').trim();
      lines.push(`- ${index + 1}. ${text.slice(0, 900)}${text.length > 900 ? '...' : ''}`);
    });
  }
  lines.push('');
  lines.push('## QA Issues');
  const issues = Array.isArray(qa?.issues) ? qa.issues : [];
  if (issues.length === 0) {
    lines.push('- None.');
  } else {
    for (const issue of issues) {
      lines.push(`- ${firstString(issue.severity, issue.qa_severity, issue.qaSeverity, 'p2')}: ${firstString(issue.id)} - ${firstString(issue.message)}`);
    }
  }
  lines.push('');

  await writeTextFile(traceFile, lines.join('\n'));
  return traceFile;
}

function summarizeStageAQa(qa) {
  return {
    status: qa?.status || '',
    score: typeof qa?.score === 'number' ? qa.score : null,
    blocking: Boolean(qa?.blocking),
    issues: Array.isArray(qa?.issues)
      ? qa.issues.map((issue) => ({
          id: issue?.id || '',
          severity: firstString(issue?.qa_severity, issue?.qaSeverity, issue?.severity, ''),
          message: issue?.message || '',
          repairHint: firstString(issue?.repair_hint, issue?.repairHint, ''),
        }))
      : [],
  };
}

function parseNonNegativeIntegerFlag(value, fallback) {
  if (value === false || value === 'false' || value === 'off' || value === 'none') {
    return 0;
  }
  const number = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(number) || number < 0) {
    return fallback;
  }
  return number;
}

function parsePositiveIntegerFlag(value, fallback) {
  const number = Number.parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(number) || number <= 0) {
    return fallback;
  }
  return number;
}

function renderStageARepairPrompt(prepared, qa, attempt, maxAttempts) {
  const issues = Array.isArray(qa?.issues) ? qa.issues : [];
  const lowContrast = Array.isArray(qa?.visual_qa?.lowContrastText)
    ? qa.visual_qa.lowContrastText
    : Array.isArray(qa?.visualQa?.lowContrastText)
      ? qa.visualQa.lowContrastText
      : [];
  const issueLines = issues.length > 0
    ? issues.map((issue) => {
        const severity = firstString(issue?.qa_severity, issue?.qaSeverity, issue?.severity, 'p2');
        const hint = firstString(issue?.repair_hint, issue?.repairHint);
        return `- ${severity.toUpperCase()} ${issue?.id || 'issue'}: ${issue?.message || ''}${hint ? ` Repair hint: ${hint}` : ''}`;
      })
    : ['- No structured issues were found, but the artifact still needs a repair pass.'];
  const contrastLines = lowContrast.length > 0
    ? lowContrast.map((item) => `- ${item.odId || item.tag || 'text'}: "${String(item.text || '').slice(0, 120)}" contrast ${item.contrast} at ${item.x},${item.y}`)
    : ['- No visual contrast samples were attached.'];

  return [
    `You are repairing Pixflow Design Stage A after local QA failed. Repair attempt ${attempt} of ${maxAttempts}.`,
    '',
    'Do not restart from a generic design. Preserve the selected Pixflow Design route, composition DNA, section order, tokens, prototype motifs, and asset roles already present in `drafts/index.html`.',
    'Do not use Bricks, WordPress, Bricks JSON, class mappings, or conversion-stage copy. Stage A remains a Pixflow Design-quality HTML artifact only.',
    '',
    'Read these files before editing:',
    '- `stage-a-qa.json`',
    '- `drafts/index.html`',
    '- `composition-dna.md`',
    '- `stage-a-self-critique.md` when present',
    '- `TODO.md`',
    '',
    'Blocking QA issues to repair:',
    ...issueLines,
    '',
    'Rendered mobile failure samples:',
    ...contrastLines,
    '',
    'Repair rules:',
    '- Fix every P0/P1 issue directly in `drafts/index.html`; do not weaken the QA by hiding content or removing important sections.',
    '- For mobile contrast, give the affected section/cards explicit background ownership and explicit text colors at phone width. Do not rely on inherited colors over dark/light bands.',
    '- Preserve Pixflow Design-style reveal/motion when it is part of the selected route and the runtime actually reveals content. Remove only broken hidden-content patterns that leave required sections invisible.',
    '- Keep the lower sections as first-class Pixflow Design work; do not simplify the artifact to pass QA.',
    '- Update `stage-a-self-critique.md` with a short “Repair pass” note describing what changed.',
    '- Update `TODO.md` only for tasks genuinely completed by the repair.',
    '',
    'Finish only after `drafts/index.html` is repaired and ready for the outer Stage A QA to rerun.',
    '',
    `Artifact path: ${prepared.artifactFile}`,
  ].join('\n');
}

async function assertStageAArtifactExists(artifactFile) {
  let stat = null;
  try {
    stat = await fs.stat(artifactFile);
  } catch (error) {
    throw new CliError(`Stage A runner finished, but artifact was not found: ${artifactFile}`);
  }

  if (!stat.isFile() || stat.size < 256) {
    throw new CliError(`Stage A artifact looks empty or invalid: ${artifactFile}`);
  }
}

async function analyzeStageAArtifact(prepared, runnerResult) {
  const html = await fs.readFile(prepared.artifactFile, 'utf8');
  const promptText = await readOptionalText(prepared.promptFile);
  const todo = await readOptionalText(prepared.todoFile);
  const compositionDna = await readOptionalText(path.join(prepared.workspaceDir, 'composition-dna.md'));
  const selfCritique = await readOptionalText(path.join(prepared.workspaceDir, 'stage-a-self-critique.md'));
  const sourceContract = await readOptionalJson(path.join(prepared.workspaceDir, 'source-contract.json'));
  const eventLogFile = runnerResult?.eventsFile || path.join(prepared.workspaceDir, 'stage-a-codex-events.jsonl');
  const eventLog = await readOptionalText(eventLogFile);
  const requiredPromptPhrases = extractRequiredPromptPhrases(promptText);
  const missingPromptPhrases = requiredPromptPhrases.filter((phrase) => !normalizedTextIncludes(html, phrase));
  const visualQa = await inspectStageAVisualQa(prepared.artifactFile, html);
  const requiredReads = Array.isArray(sourceContract?.required_model_reads)
    ? sourceContract.required_model_reads.map((item) => firstString(item)).filter(Boolean)
    : [];
  const stats = inspectStageAHtml(html, path.dirname(prepared.artifactFile));
  const referenceStats = await inspectStageAReferenceStats(prepared.workspaceDir, requiredReads);
  if (referenceStats) {
    stats.referenceExample = referenceStats;
  }
  const missingReadEvidence = eventLog
    ? requiredReads.filter((read) => !eventLogMentionsPath(eventLog, read))
    : requiredReads;
  const todoStats = inspectTodo(todo);
  const issues = [];

  const addIssue = (id, severity, message, hint = '') => {
    issues.push({
      id,
      severity,
      qa_severity: severity,
      qaSeverity: severity,
      blocking: severity === 'p0',
      message,
      repair_hint: hint,
      repairHint: hint,
    });
  };

  if (stats.htmlLength < 4000) {
    addIssue('stage_a_tiny_stub_artifact', 'p0', 'Artifact is too small to be a Pixflow Design-quality Stage A deliverable.', 'Regenerate the artifact with complete HTML/CSS and real section content.');
  } else if (stats.htmlLength < 12000) {
    addIssue('stage_a_low_density_artifact', 'p1', 'Artifact is materially smaller than the expected Stage A density for high-fidelity prototypes.', 'Review lower sections, component detail, responsive CSS, and editorial/source-specific microcopy.');
  }
  if (!stats.hasDoctype || !stats.hasHtml) {
    addIssue('stage_a_not_complete_document', 'p0', 'Artifact must be a complete standalone HTML document.', 'Write a complete <!doctype html> document to drafts/index.html.');
  }
  if (!stats.startsWithDocument) {
    addIssue('stage_a_document_start_invalid', 'p0', 'Artifact must start with <!doctype html> or <html, not prose or wrapper text.', 'Write raw standalone HTML only, with no explanation before the document.');
  }
  if (!stats.hasStyle) {
    addIssue('stage_a_missing_embedded_css', 'p0', 'Artifact has no embedded CSS craft layer.', 'Inline the artifact CSS in the first document style block.');
  }
  if (stats.sectionCount < 3) {
    addIssue('stage_a_missing_section_depth', 'p0', 'Artifact has too few structural sections for a Pixflow Design-quality prototype.', 'Preserve the selected prototype route and add complete section beats.');
  } else if (stats.sectionCount < 5 && !stats.isCompactPrototype) {
    addIssue('stage_a_thin_section_depth', 'p1', 'Artifact may not carry enough lower-section depth for the selected prototype route.', 'Check the selected Pixflow Design example and add missing section rhythm if needed.');
  }
  if (stats.dataOdIdCount < 6) {
    addIssue('stage_a_low_structural_traceability', 'p1', 'Artifact has little section traceability for Pixflow Design comparison.', 'Match the selected Pixflow Design example annotation style: landmarks and top-level sections first, plus only distinctive motifs the example itself annotates.');
  }
  if (stats.bricksLeakCount > 0) {
    addIssue('stage_a_bricks_boundary_leak', 'p0', 'Stage A artifact contains Bricks or WordPress runtime output.', 'Remove Bricks/WordPress implementation details until Stage B conversion.');
  }
  if (stats.reservedProjectPathReferences.length > 0) {
    addIssue('stage_a_internal_storage_path_reference', 'p0', 'Stage A artifact references internal workspace storage paths.', `Use artifact-local paths instead of internal storage paths: ${stats.reservedProjectPathReferences.slice(0, 6).join(', ')}`);
  }
  if (stats.tailwindCdnCount > 0) {
    addIssue('stage_a_tailwind_cdn', 'p0', 'Artifact uses cdn.tailwindcss.com, which Pixflow Design treats as non-production/stub output.', 'Inline authored CSS instead of depending on Tailwind CDN.');
  }
  if (stats.hiddenRevealCount > 0) {
    addIssue('stage_a_hidden_reveal_risk', 'p0', 'Artifact contains hidden-content patterns that can leave lower sections invisible in screenshot QA.', 'Use the selected Pixflow Design example motion system with a working reveal script/reduced-motion fallback, or keep structural content visible by default.');
  }
  if (stats.slopSignalCount > 0) {
    addIssue('stage_a_ai_slop_signal', 'p1', 'Artifact contains one or more Pixflow Design anti-slop signals.', 'Replace generic filler, trope gradients, default indigo, emoji icons, or invented metrics with source-specific craft.');
  }
  if (
    referenceStats
    && referenceStats.cssSelectorCount >= 250
    && stats.cssSelectorCount < Math.floor(referenceStats.cssSelectorCount * 0.75)
  ) {
    addIssue(
      'stage_a_selected_route_style_density_drift',
      'p1',
      'Artifact CSS craft layer is materially thinner than the selected Pixflow Design route example.',
      `Preserve more of the selected example's component/state/motion styling density. Generated selectors: ${stats.cssSelectorCount}; reference selectors: ${referenceStats.cssSelectorCount}.`,
    );
  }
  if (stats.bodyPercentSplitBackgroundCount > 0) {
    addIssue('stage_a_page_height_background_split_risk', 'p1', 'Artifact uses body-level percentage background splits that can put lower sections on the wrong band at mobile heights.', 'Give every major section explicit background ownership instead of relying on page-height gradient stop percentages.');
  }
  if (visualQa.lowContrastText.length > 0) {
    const labels = visualQa.lowContrastText
      .slice(0, 4)
      .map((item) => item.odId || item.text || item.tag)
      .join(', ');
    addIssue('stage_a_mobile_visual_contrast', 'p0', 'Mobile screenshot QA found visible text with insufficient contrast against its rendered background.', `Repair mobile section background/text pairing. Failing samples: ${labels}`);
  }
  if (stats.missingLocalAssets.length > 0) {
    addIssue('stage_a_missing_local_assets', 'p1', 'Artifact references local assets that are missing from the workspace.', `Fix or remove missing references: ${stats.missingLocalAssets.slice(0, 8).join(', ')}`);
  }
  if (missingPromptPhrases.length > 0) {
    addIssue('stage_a_prompt_copy_drift', 'p1', 'Artifact is missing exact copy explicitly required by the prompt.', `Preserve required prompt phrases: ${missingPromptPhrases.slice(0, 6).join(' | ')}`);
  }
  if (requiredReads.length > 0 && missingReadEvidence.length > 0) {
    addIssue('stage_a_required_reads_not_observed', 'p1', 'Runner log does not show every required Pixflow Design source read.', `Read or cite these before finalizing: ${missingReadEvidence.slice(0, 12).join(', ')}`);
  }
  if (!todo) {
    addIssue('stage_a_todo_missing', 'p1', 'TODO.md was not available for Pixflow Design-style progress tracking.', 'Keep TODO.md in the workspace and update it during the run.');
  } else if (todoStats.uncheckedCount > 0) {
    addIssue('stage_a_todo_incomplete', 'p1', 'TODO.md still has unchecked Stage A workflow items.', 'Mark tasks complete only after the corresponding work is done.');
  }
  if (!selfCritique.trim()) {
    addIssue('stage_a_self_critique_missing', 'p1', 'stage-a-self-critique.md is missing.', 'Record the Pixflow Design 5-dimensional critique and fixes before finishing.');
  }
  if (!compositionDna.trim()) {
    addIssue('stage_a_composition_dna_missing', 'p1', 'composition-dna.md is missing.', 'Record the selected prototype/route composition DNA before authoring or finalizing the artifact.');
  }

  const counts = severityCounts(issues);
  const blocking = (counts.p0 || 0) > 0;
  const score = Math.max(0, 100 - ((counts.p0 || 0) * 22) - ((counts.p1 || 0) * 5) - ((counts.p2 || 0) * 2));
  return {
    type: 'pixflow_cli_stage_a_qa_report',
    version: 1,
    stage: DEFAULT_STAGE,
    status: blocking ? 'fail' : issues.length > 0 ? 'warning' : 'pass',
    blocking,
    score,
    runner: {
      kind: runnerResult?.kind || 'codex',
      event_summary: runnerResult?.eventSummary || null,
      events_file: eventLogFile,
    },
    stats,
    visual_qa: visualQa,
    visualQa,
    todo: todoStats,
    required_model_reads: requiredReads,
    requiredModelReads: requiredReads,
    required_prompt_phrases: requiredPromptPhrases,
    requiredPromptPhrases,
    missing_prompt_phrases: missingPromptPhrases,
    missingPromptPhrases,
    missing_required_read_evidence: missingReadEvidence,
    missingRequiredReadEvidence: missingReadEvidence,
    issues,
    issue_count: issues.length,
    issueCount: issues.length,
    qa_severity_counts: counts,
    qaSeverityCounts: counts,
    generated_at: new Date().toISOString(),
    generatedAt: new Date().toISOString(),
  };
}

function assertStageAQaPasses(qa) {
  if (!qa?.blocking) {
    return;
  }
  const issues = Array.isArray(qa.issues) ? qa.issues : [];
  const summary = issues
    .filter((issue) => issue?.blocking || issue?.severity === 'p0' || issue?.qa_severity === 'p0')
    .map((issue) => `${issue.id}: ${issue.message}`)
    .slice(0, 6)
    .join('; ');
  throw new CliError(`Stage A local QA failed before import.${summary ? ` ${summary}` : ''}`);
}

function inspectStageAHtml(html, artifactDir) {
  const refs = collectLocalAssetRefs(html);
  const missingLocalAssets = refs.filter((ref) => !existsSync(path.join(artifactDir, ref)));
  const sectionCount = countMatches(html, /<(?:section|article)\b/gi);
  const dataOdIdCount = countMatches(html, /\bdata-od-id\s*=/gi);
  const styleText = Array.from(html.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style>/gi))
    .map((match) => match[1] || '')
    .join('\n');
  const compactSignals = /\bcarousel\b|\bsocial\b|\bpost\b|\bposter\b|\bcard set\b/i.test(html);
  const reservedProjectPathReferences = findReservedProjectPathReferences(html);
  const babelScriptSrcs = extractStageABabelScriptSrcs(html);
  return {
    htmlLength: html.length,
    wordCount: countMatches(html, /\b[\w'-]{2,}\b/g),
    hasDoctype: /<!doctype html>/i.test(html.slice(0, 400)),
    startsWithDocument: startsWithHtmlDocument(html),
    hasHtml: /<html[\s>]/i.test(html),
    hasStyle: /<style[\s>]/i.test(html),
    hasScript: /<script[\s>]/i.test(html),
    scriptCount: countMatches(html, /<script[\s>]/gi),
    babelScriptSrcs,
    babelScriptSrcCount: babelScriptSrcs.length,
    cssSelectorCount: countMatches(styleText, /\.[a-zA-Z][\w-]*/g),
    sectionCount,
    dataOdIdCount,
    isCompactPrototype: compactSignals && sectionCount >= 3,
    localAssetRefCount: refs.length,
    missingLocalAssets,
    reservedProjectPathReferences,
    reservedProjectPathCount: reservedProjectPathReferences.length,
    bricksLeakCount: countMatches(html, /\b(?:Bricks|brxe-|data-bricks|wp-json|wp-admin|wp-block-|bricks-builder|WordPress|wp\s+admin)\b/gi),
    tailwindCdnCount: countMatches(html, /cdn\.tailwindcss\.com/gi),
    hiddenRevealCount: countHiddenRevealRisks(html),
    bodyPercentSplitBackgroundCount: countBodyPercentSplitBackgrounds(html),
    slopSignalCount:
      countMatches(html, /\blorem ipsum\b|\bfeature (?:one|two|three|1|2|3)\b|\bplaceholder text\b/gi)
      + countMatches(html, /linear-gradient\([^)]*(?:#6366f1|#4f46e5|#7c3aed|purple|violet|#06b6d4)[^)]*\)/gi)
      + countMatches(html, /(?:\u2728|\uD83D\uDE80|\uD83C\uDFAF|\u26A1|\uD83D\uDD25|\uD83D\uDCA1|\uD83D\uDCC8|\uD83C\uDFA8|\u2705|\u2B50)/gu)
      + countMatches(html, /\b(?:10x|100x|10\u00d7|100\u00d7|99\.9% uptime|zero[- ]downtime)\b/gi),
  };
}

function startsWithHtmlDocument(html) {
  return /^(?:<!doctype\s+html\b|<html\b)/i.test(String(html || '').replace(/^\uFEFF/, '').trimStart());
}

function extractStageABabelScriptSrcs(html) {
  const scannable = String(html || '').replace(/<!--[\s\S]*?-->/g, '');
  const srcs = [];
  const pattern = /<script\b([^>]*)>/gi;
  let match;
  while ((match = pattern.exec(scannable)) !== null) {
    const attrs = match[1] || '';
    if (!/\btype\s*=\s*["']?text\/babel\b/i.test(attrs)) {
      continue;
    }
    const srcMatch = attrs.match(/\bsrc\s*=\s*["']([^"']+)["']/i);
    const src = normalizeStageAScriptRef(srcMatch?.[1] || '');
    if (src) {
      srcs.push(src);
    }
  }
  return uniqueStrings(srcs).slice(0, 20);
}

function normalizeStageAScriptRef(src) {
  return firstString(src).split(/[?#]/)[0].replace(/^\.\//, '').trim();
}

function findReservedProjectPathReferences(html) {
  const scannable = String(html || '').replace(/<!--[\s\S]*?-->/g, ' ');
  const references = [];
  const tagPattern = /<[a-z][^>]*>/gi;
  let tagMatch;
  while ((tagMatch = tagPattern.exec(scannable)) !== null) {
    collectReservedProjectPathAttributes(references, tagMatch[0] || '');
    collectReservedProjectPathStyleAttributes(references, tagMatch[0] || '');
  }

  const stylePattern = /<style\b[^>]*>([\s\S]*?)<\/style>/gi;
  let styleMatch;
  while ((styleMatch = stylePattern.exec(scannable)) !== null) {
    collectReservedProjectPathCss(references, styleMatch[1] || '');
  }
  return uniqueStrings(references).slice(0, 12);
}

function collectReservedProjectPathAttributes(references, tag) {
  const pattern = /\b(?:href|src|srcset|poster|action|formaction|data|xlink:href)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'`=<>]+))/gi;
  let match;
  while ((match = pattern.exec(tag)) !== null) {
    const candidate = firstString(match[1], match[2], match[3]);
    const isSrcset = /\bsrcset\s*=/i.test(match[0] || '');
    for (const path of stageAPathCandidates(candidate, isSrcset)) {
      if (isReservedProjectPath(path)) {
        references.push(path);
      }
    }
  }
}

function collectReservedProjectPathStyleAttributes(references, tag) {
  const pattern = /\bstyle\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'`=<>]+))/gi;
  let match;
  while ((match = pattern.exec(tag)) !== null) {
    collectReservedProjectPathCss(references, firstString(match[1], match[2], match[3]));
  }
}

function collectReservedProjectPathCss(references, cssText) {
  const patterns = [
    /\burl\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*?))\s*\)/gi,
    /@import\s+(?:url\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*?))\s*\)|"([^"]*)"|'([^']*)')/gi,
  ];
  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(String(cssText || ''))) !== null) {
      const candidate = match.slice(1).find((value) => value !== undefined && String(value).trim()) || '';
      for (const path of stageAPathCandidates(candidate, false)) {
        if (isReservedProjectPath(path)) {
          references.push(path);
        }
      }
    }
  }
}

function stageAPathCandidates(value, splitSrcset) {
  if (!splitSrcset) {
    return [firstStageAPathToken(value)];
  }
  return String(value || '').split(',').map((candidate) => firstStageAPathToken(candidate));
}

function firstStageAPathToken(value) {
  return firstString(value).trim().split(/\s+/)[0] || '';
}

function isReservedProjectPath(pathValue) {
  const pathName = firstString(pathValue).trim().split(/[?#]/)[0] || '';
  if (!pathName || pathName.startsWith('#') || pathName.startsWith('//') || /^[a-z][a-z0-9+.-]*:/i.test(pathName)) {
    return false;
  }
  return /(?:^|\/|\.\/)(?:\.live-artifacts|\.od|\.tmp)(?=$|[/?#"'`\s>)])/i.test(pathName);
}

async function inspectStageAReferenceStats(workspaceDir, requiredReads) {
  const candidates = (requiredReads || [])
    .map((read) => firstString(read))
    .filter(Boolean)
    .filter((read) => /\.od-skills[\\/][^\\/]+[\\/]example\.html$/i.test(read.replaceAll('/', path.sep)));
  for (const read of candidates) {
    const file = path.join(workspaceDir, read);
    if (!existsSync(file)) {
      continue;
    }
    const html = await readOptionalText(file);
    if (!html.trim()) {
      continue;
    }
    const stats = inspectStageAHtml(html, path.dirname(file));
    return {
      path: read,
      htmlLength: stats.htmlLength,
      wordCount: stats.wordCount,
      sectionCount: stats.sectionCount,
      dataOdIdCount: stats.dataOdIdCount,
      scriptCount: stats.scriptCount,
      cssSelectorCount: stats.cssSelectorCount,
      localAssetRefCount: stats.localAssetRefCount,
    };
  }
  return null;
}

function extractRequiredPromptPhrases(promptText) {
  const text = firstString(promptText);
  if (!text) {
    return [];
  }
  const phrases = [];
  const lines = text.split(/\r?\n/);
  const labelledPattern = /^\s*(?:carousel sentence|required text|exact text|required copy|must include|must use|use this copy|copy to preserve|verbatim copy)\s*:\s*(.+?)\s*$/i;
  for (const line of lines) {
    const match = line.match(labelledPattern);
    if (!match) continue;
    for (const phrase of splitRequiredPromptPhrase(match[1])) {
      if (phrase.length >= 8) {
        phrases.push(phrase);
      }
    }
  }
  const inlineLabelPattern = /\b(carousel sentence|required text|exact text|required copy|must include|must use|use this copy|copy to preserve|verbatim copy)\s*:\s*([\s\S]{8,220}?)(?=\s+(?:Use the|Keep the|Match|Do not|Selected|Design-system|Visual direction|Brand|Output|Create|Design)\b|$)/gi;
  let inlineMatch;
  while ((inlineMatch = inlineLabelPattern.exec(text)) !== null) {
    for (const phrase of splitRequiredPromptPhrase(inlineMatch[2])) {
      if (phrase.length >= 8) {
        phrases.push(phrase);
      }
    }
  }
  const quotedPattern = /(?:must include|must use|use this copy|exact text|required text|verbatim)[^"'`]{0,80}["'`]([^"'`]{8,160})["'`]/gi;
  let quoteMatch;
  while ((quoteMatch = quotedPattern.exec(text)) !== null) {
    phrases.push(quoteMatch[1]);
  }
  return Array.from(new Set(phrases.map(normalizeRequiredPromptPhrase).filter((phrase) => phrase.length >= 8))).slice(0, 20);
}

function splitRequiredPromptPhrase(value) {
  const text = firstString(value)
    .replace(/^["'`]+|["'`]+$/g, '')
    .trim();
  if (!text) return [];
  if (text.length <= 180) return [text];
  return text
    .split(/\s+(?:\||;|\/)\s+|\s+-\s+/)
    .map((part) => part.trim())
    .filter(Boolean);
}

function normalizeRequiredPromptPhrase(value) {
  return firstString(value)
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizedTextIncludes(haystack, needle) {
  const normalizedHaystack = normalizeForCopyMatch(haystack);
  const normalizedNeedle = normalizeForCopyMatch(needle);
  return normalizedNeedle.length > 0 && normalizedHaystack.includes(normalizedNeedle);
}

function normalizeForCopyMatch(value) {
  return firstString(value)
    .toLowerCase()
    .replace(/&amp;/g, '&')
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

async function inspectStageAVisualQa(artifactFile, html) {
  const result = {
    status: 'skipped',
    viewport: { width: 390, height: 1100 },
    lowContrastText: [],
    sampledTextCount: 0,
    bodyPercentSplitBackgroundCount: countBodyPercentSplitBackgrounds(html),
    error: '',
  };

  let chromium;
  try {
    ({ chromium } = await import('playwright'));
  } catch (error) {
    result.error = `Playwright unavailable: ${error.message}`;
    return result;
  }

  let browser;
  try {
    browser = await chromium.launch({ headless: true });
    const page = await browser.newPage({
      viewport: result.viewport,
      deviceScaleFactor: 1,
    });
    await page.goto(pathToFileURL(artifactFile).href, { waitUntil: 'networkidle' });
    const textNodes = await page.evaluate(() => {
      const selector = [
        'h1',
        'h2',
        'h3',
        'h4',
        'p',
        'li',
        'blockquote',
        'figcaption',
        'button',
        'a',
        '[class*="eyebrow"]',
        '[class*="caption"]',
        '[class*="lede"]',
      ].join(',');
      let qaIndex = 0;
      const nearestSolidBackground = (element) => {
        for (let node = element; node; node = node.parentElement) {
          const value = window.getComputedStyle(node).backgroundColor;
          if (!value || value === 'transparent') {
            continue;
          }
          const match = value.match(/rgba?\(([^)]+)\)/i);
          if (!match) {
            continue;
          }
          const parts = match[1].split(',').map((part) => Number.parseFloat(part.trim()));
          const alpha = parts.length >= 4 ? parts[3] : 1;
          if (alpha > 0.85) {
            return value;
          }
        }
        return '';
      };
      return Array.from(document.querySelectorAll(selector))
        .map((element) => {
          const style = window.getComputedStyle(element);
          const directText = Array.from(element.childNodes)
            .filter((node) => node.nodeType === window.Node.TEXT_NODE)
            .map((node) => node.textContent || '')
            .join(' ')
            .replace(/\s+/g, ' ')
            .trim();
          const tag = element.tagName.toLowerCase();
          const text = (directText || (['h1', 'h2', 'h3', 'h4', 'p', 'li', 'blockquote', 'figcaption', 'button', 'a'].includes(tag) ? element.textContent || '' : ''))
            .replace(/\s+/g, ' ')
            .trim();
          const rect = element.getBoundingClientRect();
          const hidden = style.display === 'none'
            || style.visibility === 'hidden'
            || Number.parseFloat(style.opacity || '1') < 0.15
            || rect.width < 20
            || rect.height < 8
            || text.length < 3;
          if (hidden) {
            return null;
          }
          const qaId = `pfai-qa-${qaIndex}`;
          qaIndex += 1;
          element.setAttribute('data-pfai-qa-id', qaId);
          return {
            qaId,
            tag,
            text: text.slice(0, 96),
            color: style.color,
            backgroundColor: style.backgroundColor,
            resolvedBackgroundColor: nearestSolidBackground(element),
            fontSize: Number.parseFloat(style.fontSize || '16') || 16,
            fontWeight: style.fontWeight,
            className: typeof element.className === 'string' ? element.className : '',
            odId: element.closest('[data-od-id]')?.getAttribute('data-od-id') || '',
            x: rect.left + window.scrollX,
            y: rect.top + window.scrollY,
            width: rect.width,
            height: rect.height,
          };
        })
        .filter(Boolean)
        .slice(0, 220);
    });
    const failures = [];
    for (const node of textNodes) {
      const textRgb = parseRgbColor(node.color);
      if (!textRgb) {
        continue;
      }
      const solidBackground = parseRgbColor(node.backgroundColor);
      const resolvedBackground = parseRgbColor(node.resolvedBackgroundColor);
      const samples = solidBackground && solidBackground.a > 0.85
        ? [solidBackground]
        : resolvedBackground && resolvedBackground.a > 0.85
          ? [resolvedBackground]
          : await sampleViewportBackgroundPixels(page, node);
      if (samples.length === 0) {
        continue;
      }
      const ratios = samples.map((sample) => contrastRatio(textRgb, sample));
      const bestRatio = Math.max(...ratios);
      const largeText = node.fontSize >= 24 || (node.fontSize >= 18.66 && Number.parseFloat(node.fontWeight) >= 700);
      const metaText = /\b(?:eyebrow|caption|micro|meta|surface-note|stamp)\b/i.test(node.className || '') || node.tag === 'figcaption';
      const interactiveToken = ['a', 'button'].includes(node.tag)
        || /\b(?:button|btn|chip|pill|tag|filter|cta|ghost|primary)\b/i.test(node.className || '');
      const primaryInteractiveToken = interactiveToken && /\b(?:primary|btn|cta)\b/i.test(node.className || '');
      const threshold = primaryInteractiveToken ? 2.4 : interactiveToken ? 2.75 : metaText ? 2.75 : largeText ? 2.9 : 4.0;
      if (bestRatio < threshold) {
        failures.push({
          tag: node.tag,
          text: node.text,
          odId: node.odId,
          contrast: Number(bestRatio.toFixed(2)),
          threshold,
          x: Math.round(node.x),
          y: Math.round(node.y),
        });
      }
    }
    result.status = failures.length > 0 ? 'fail' : 'pass';
    result.sampledTextCount = textNodes.length;
    result.lowContrastText = failures.slice(0, 12);
    await page.close();
    return result;
  } catch (error) {
    result.error = error.message;
    return result;
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

function countBodyPercentSplitBackgrounds(html) {
  const bodyBlocks = Array.from(html.matchAll(/body\s*\{([\s\S]*?)\}/gi)).map((match) => match[1] || '');
  return bodyBlocks.filter((block) => {
    const backgroundMatch = block.match(/background(?:-image)?\s*:\s*([\s\S]*?);/i);
    const value = backgroundMatch?.[1] || '';
    return /linear-gradient\s*\(\s*180deg/i.test(value)
      && /(?:\d+(?:\.\d+)?%)[\s\S]{0,120}(?:\d+(?:\.\d+)?%)/.test(value);
  }).length;
}

function countHiddenRevealRisks(html) {
  const revealPatternCount = countMatches(html, /\bIntersectionObserver\b|\bdata-reveal\b|\breveal-(?:on|item|section)\b/gi);
  const hasOdStyleRevealRuntime = revealPatternCount > 0
    && /\bIntersectionObserver\b/i.test(html)
    && /\bdata-revealed\b/i.test(html)
    && /prefers-reduced-motion/i.test(html);
  const opacityRiskHtml = hasOdStyleRevealRuntime
    ? html
      .replace(/\[data-reveal(?:[^\]]*)\]\s*\{[\s\S]*?\}/gi, '')
      .replace(/\[[^\]]*data-reveal[^\]]*\]\s*\{[\s\S]*?\}/gi, '')
      .replace(/@media\s*\(\s*prefers-reduced-motion[\s\S]*?\}\s*\}/gi, '')
    : html;
  const revealRuntimeRiskCount = revealPatternCount > 0 && !hasOdStyleRevealRuntime ? revealPatternCount : 0;
  const hiddenOpacityCount = countMatches(opacityRiskHtml, /opacity\s*:\s*0(?:\.0+)?\s*(?:;|\})/gi);
  const hiddenVisibilityCount = countMatches(html, /visibility\s*:\s*hidden(?:\b|;)/gi);
  const structuralDisplayNoneCount = countMatches(
    html,
    /\.(?:section|card|panel|block|content|feature|testimonial|service|work|case|story|article|gallery|media|hero|cta)[\w-]*\s*\{[^}]*display\s*:\s*none/gi,
  );
  return revealRuntimeRiskCount + hiddenOpacityCount + hiddenVisibilityCount + structuralDisplayNoneCount;
}

async function sampleViewportBackgroundPixels(page, node) {
  if (!node?.qaId) {
    return [];
  }
  const viewportNode = await page.evaluate(async (qaId) => {
    const element = document.querySelector(`[data-pfai-qa-id="${qaId}"]`);
    if (!element) {
      return null;
    }
    element.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
    let rect = element.getBoundingClientRect();
    if (rect.top < 0 || rect.bottom > window.innerHeight || rect.left < 0 || rect.right > window.innerWidth) {
      const targetY = window.scrollY + rect.top - Math.max(0, (window.innerHeight - rect.height) / 2);
      const targetX = window.scrollX + rect.left - Math.max(0, (window.innerWidth - rect.width) / 2);
      window.scrollTo({ left: Math.max(0, targetX), top: Math.max(0, targetY), behavior: 'instant' });
      await new Promise((resolve) => window.requestAnimationFrame(() => resolve()));
      rect = element.getBoundingClientRect();
    }
    if (rect.width < 1 || rect.height < 1) {
      return null;
    }
    return {
      x: rect.left,
      y: rect.top,
      width: rect.width,
      height: rect.height,
    };
  }, node.qaId);
  if (!viewportNode) {
    return [];
  }
  const buffer = await page.screenshot({ fullPage: false });
  const png = decodePng(buffer);
  return sampleBackgroundPixels(png, {
    ...node,
    x: viewportNode.x,
    y: viewportNode.y,
    width: viewportNode.width,
    height: viewportNode.height,
  });
}

function sampleBackgroundPixels(png, node) {
  const x = Math.round(node.x);
  const y = Math.round(node.y);
  const width = Math.round(node.width);
  const height = Math.round(node.height);
  const points = [
    [x - 6, y + Math.round(height / 2)],
    [x + width + 6, y + Math.round(height / 2)],
    [x + Math.round(width / 2), y + height + 6],
    [x + Math.round(width * 0.12), y + height + 4],
    [x + Math.round(width * 0.88), y + height + 4],
    [x + Math.round(width / 2), y - 6],
  ];
  const pixels = [];
  for (const [px, py] of points) {
    const pixel = getPngPixel(png, px, py);
    if (pixel) {
      pixels.push(pixel);
    }
  }
  return pixels;
}

function getPngPixel(png, x, y) {
  if (!png || x < 0 || y < 0 || x >= png.width || y >= png.height) {
    return null;
  }
  const index = (Math.floor(y) * png.width + Math.floor(x)) * 4;
  return {
    r: png.data[index],
    g: png.data[index + 1],
    b: png.data[index + 2],
    a: png.data[index + 3] / 255,
  };
}

function decodePng(buffer) {
  const signature = buffer.subarray(0, 8).toString('hex');
  if (signature !== '89504e470d0a1a0a') {
    throw new CliError('Visual QA expected a PNG screenshot.');
  }
  let offset = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  const idat = [];
  while (offset < buffer.length) {
    const length = buffer.readUInt32BE(offset);
    const type = buffer.subarray(offset + 4, offset + 8).toString('ascii');
    const data = buffer.subarray(offset + 8, offset + 8 + length);
    offset += 12 + length;
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === 'IDAT') {
      idat.push(data);
    } else if (type === 'IEND') {
      break;
    }
  }
  if (bitDepth !== 8 || ![2, 6].includes(colorType)) {
    throw new CliError(`Visual QA supports 8-bit RGB/RGBA PNG screenshots only; got bit depth ${bitDepth}, color type ${colorType}.`);
  }
  const channels = colorType === 6 ? 4 : 3;
  const inflated = inflateSync(Buffer.concat(idat));
  const stride = width * channels;
  const raw = Buffer.alloc(width * height * channels);
  let inputOffset = 0;
  let outputOffset = 0;
  for (let row = 0; row < height; row += 1) {
    const filter = inflated[inputOffset];
    inputOffset += 1;
    for (let col = 0; col < stride; col += 1) {
      const value = inflated[inputOffset + col];
      const left = col >= channels ? raw[outputOffset + col - channels] : 0;
      const up = row > 0 ? raw[outputOffset + col - stride] : 0;
      const upLeft = row > 0 && col >= channels ? raw[outputOffset + col - stride - channels] : 0;
      raw[outputOffset + col] = unfilterPngByte(filter, value, left, up, upLeft);
    }
    inputOffset += stride;
    outputOffset += stride;
  }
  const rgba = Buffer.alloc(width * height * 4);
  for (let input = 0, output = 0; input < raw.length; input += channels, output += 4) {
    rgba[output] = raw[input];
    rgba[output + 1] = raw[input + 1];
    rgba[output + 2] = raw[input + 2];
    rgba[output + 3] = channels === 4 ? raw[input + 3] : 255;
  }
  return { width, height, data: rgba };
}

function unfilterPngByte(filter, value, left, up, upLeft) {
  if (filter === 0) {
    return value;
  }
  if (filter === 1) {
    return (value + left) & 0xff;
  }
  if (filter === 2) {
    return (value + up) & 0xff;
  }
  if (filter === 3) {
    return (value + Math.floor((left + up) / 2)) & 0xff;
  }
  if (filter === 4) {
    return (value + paethPredictor(left, up, upLeft)) & 0xff;
  }
  throw new CliError(`Unsupported PNG filter ${filter}.`);
}

function paethPredictor(left, up, upLeft) {
  const p = left + up - upLeft;
  const pa = Math.abs(p - left);
  const pb = Math.abs(p - up);
  const pc = Math.abs(p - upLeft);
  if (pa <= pb && pa <= pc) {
    return left;
  }
  return pb <= pc ? up : upLeft;
}

function parseRgbColor(value) {
  const text = String(value || '').trim();
  const match = text.match(/rgba?\(([^)]+)\)/i);
  if (match) {
    const parts = match[1]
      .split(',')
      .map((part) => Number.parseFloat(part.trim()));
    if (parts.length < 3 || parts.some((part, index) => index < 3 && !Number.isFinite(part))) {
      return null;
    }
    return { r: parts[0], g: parts[1], b: parts[2], a: parts[3] ?? 1 };
  }

  const oklch = text.match(/oklch\(([^)]+)\)/i);
  if (oklch) {
    return parseOklchColor(oklch[1]);
  }

  const oklab = text.match(/oklab\(([^)]+)\)/i);
  if (oklab) {
    return parseOklabColor(oklab[1]);
  }

  return null;
}

function parseOklchColor(contents) {
  const parsed = parseModernColorParts(contents);
  if (parsed.parts.length < 3) {
    return null;
  }
  const l = parseCssNumber(parsed.parts[0], 1);
  const c = parseCssNumber(parsed.parts[1], 1);
  const h = parseHueDegrees(parsed.parts[2]);
  if (![l, c, h].every(Number.isFinite)) {
    return null;
  }
  const radians = h * Math.PI / 180;
  return oklabToRgb({
    l,
    a: c * Math.cos(radians),
    b: c * Math.sin(radians),
    alpha: parsed.alpha,
  });
}

function parseOklabColor(contents) {
  const parsed = parseModernColorParts(contents);
  if (parsed.parts.length < 3) {
    return null;
  }
  const l = parseCssNumber(parsed.parts[0], 1);
  const a = parseCssNumber(parsed.parts[1], 1);
  const b = parseCssNumber(parsed.parts[2], 1);
  if (![l, a, b].every(Number.isFinite)) {
    return null;
  }
  return oklabToRgb({ l, a, b, alpha: parsed.alpha });
}

function parseModernColorParts(contents) {
  const sections = String(contents || '').replace(/,/g, ' ').split('/');
  const parts = sections[0].trim().split(/\s+/).filter(Boolean);
  const alpha = sections[1] ? parseCssNumber(sections[1].trim(), 1) : 1;
  return { parts, alpha: Number.isFinite(alpha) ? alpha : 1 };
}

function parseCssNumber(value, percentScale) {
  const text = String(value || '').trim();
  if (text.endsWith('%')) {
    const number = Number.parseFloat(text.slice(0, -1));
    return Number.isFinite(number) ? (number / 100) * percentScale : Number.NaN;
  }
  return Number.parseFloat(text);
}

function parseHueDegrees(value) {
  const text = String(value || '').trim().toLowerCase();
  if (text.endsWith('turn')) {
    return Number.parseFloat(text) * 360;
  }
  if (text.endsWith('rad')) {
    return Number.parseFloat(text) * 180 / Math.PI;
  }
  return Number.parseFloat(text.replace(/deg$/, ''));
}

function oklabToRgb({ l, a, b, alpha }) {
  const lmsL = l + 0.3963377774 * a + 0.2158037573 * b;
  const lmsM = l - 0.1055613458 * a - 0.0638541728 * b;
  const lmsS = l - 0.0894841775 * a + 0.4667660 * b;
  const l3 = lmsL ** 3;
  const m3 = lmsM ** 3;
  const s3 = lmsS ** 3;
  const linearR = 3.2409699419 * l3 - 1.5373831776 * m3 - 0.4986107603 * s3;
  const linearG = -0.9692436363 * l3 + 1.8759675015 * m3 + 0.0415550574 * s3;
  const linearB = 0.0556300797 * l3 - 0.2039769589 * m3 + 1.0569715142 * s3;
  return {
    r: linearSrgbToRgb(linearR),
    g: linearSrgbToRgb(linearG),
    b: linearSrgbToRgb(linearB),
    a: alpha,
  };
}

function linearSrgbToRgb(value) {
  const clipped = Math.max(0, Math.min(1, value));
  const srgb = clipped <= 0.0031308
    ? clipped * 12.92
    : 1.055 * (clipped ** (1 / 2.4)) - 0.055;
  return srgb * 255;
}

function contrastRatio(foreground, background) {
  const fg = compositeOver(foreground, background);
  const bg = background;
  const lighter = Math.max(relativeLuminance(fg), relativeLuminance(bg));
  const darker = Math.min(relativeLuminance(fg), relativeLuminance(bg));
  return (lighter + 0.05) / (darker + 0.05);
}

function compositeOver(foreground, background) {
  const alpha = Number.isFinite(foreground.a) ? foreground.a : 1;
  return {
    r: foreground.r * alpha + background.r * (1 - alpha),
    g: foreground.g * alpha + background.g * (1 - alpha),
    b: foreground.b * alpha + background.b * (1 - alpha),
  };
}

function relativeLuminance(color) {
  const rgb = [color.r, color.g, color.b].map((value) => {
    const channel = Math.max(0, Math.min(255, value)) / 255;
    return channel <= 0.03928 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
  });
  return (0.2126 * rgb[0]) + (0.7152 * rgb[1]) + (0.0722 * rgb[2]);
}

function inspectTodo(todo) {
  const text = firstString(todo);
  if (!text) {
    return { present: false, totalCount: 0, checkedCount: 0, uncheckedCount: 0 };
  }
  const totalCount = countMatches(text, /^\s*-\s+\[[ xX]\]/gm);
  const checkedCount = countMatches(text, /^\s*-\s+\[[xX]\]/gm);
  const uncheckedCount = countMatches(text, /^\s*-\s+\[ \]/gm);
  return { present: true, totalCount, checkedCount, uncheckedCount };
}

function collectLocalAssetRefs(html) {
  const refs = [];
  const attrRe = /\b(?:src|href)\s*=\s*["']([^"']+)["']/gi;
  let match;
  while ((match = attrRe.exec(html)) !== null) {
    const ref = match[1].trim();
    if (!ref || ref.startsWith('#')) continue;
    if (/^(?:https?:|data:|mailto:|tel:|javascript:)/i.test(ref)) continue;
    if (ref.startsWith('/')) continue;
    if (/\.(?:html?|css|js)$/i.test(ref)) continue;
    refs.push(ref.replace(/\\/g, '/').replace(/^\.\//, '').split(/[?#]/)[0]);
  }
  return Array.from(new Set(refs)).filter(Boolean);
}

async function readOptionalText(filePath) {
  try {
    return await fs.readFile(filePath, 'utf8');
  } catch {
    return '';
  }
}

async function readOptionalJson(filePath) {
  const raw = await readOptionalText(filePath);
  if (!raw.trim()) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function eventLogMentionsPath(eventLog, readPath) {
  const normalized = readPath.replace(/\\/g, '/');
  const basename = path.basename(normalized);
  return eventLog.includes(normalized) || (basename.length > 3 && eventLog.includes(basename));
}

function severityCounts(issues) {
  return issues.reduce((counts, issue) => {
    const severity = firstString(issue?.qa_severity, issue?.qaSeverity, issue?.severity, 'p2').toLowerCase();
    counts[severity] = (counts[severity] || 0) + 1;
    return counts;
  }, { p0: 0, p1: 0, p2: 0 });
}

function countMatches(text, pattern) {
  return Array.from(String(text || '').matchAll(pattern)).length;
}

function extractUsageFromRunnerEvent(event) {
  const candidates = [
    event?.usage,
    event?.data?.usage,
    event?.msg?.usage,
    event?.message?.usage,
  ];
  for (const usage of candidates) {
    if (usage && typeof usage === 'object') {
      return usage;
    }
  }
  return null;
}

async function readJsonFile(filePath, label) {
  const raw = stripBom(await readTextFile(filePath, label));
  try {
    return JSON.parse(raw);
  } catch (error) {
    throw new CliError(`${label} is not valid JSON: ${path.resolve(process.cwd(), filePath)}`);
  }
}

async function ensureStageAWorkspace(workspaceDir, force) {
  try {
    const stat = await fs.stat(workspaceDir);
    if (!stat.isDirectory()) {
      throw new CliError(`Stage A workspace path exists and is not a directory: ${workspaceDir}`);
    }
    if (!force) {
      throw new CliError(`Stage A workspace already exists: ${workspaceDir}. Use --force to overwrite known handoff files.`);
    }
  } catch (error) {
    if (error instanceof CliError) {
      throw error;
    }
    if (error?.code !== 'ENOENT') {
      throw new CliError(`Could not inspect Stage A workspace: ${workspaceDir}`);
    }
  }

  await fs.mkdir(workspaceDir, { recursive: true });
}

async function ensureStageBWorkspace(workspaceDir, force) {
  try {
    const stat = await fs.stat(workspaceDir);
    if (!stat.isDirectory()) {
      throw new CliError(`Stage B workspace path exists and is not a directory: ${workspaceDir}`);
    }
    if (!force) {
      throw new CliError(`Stage B workspace already exists: ${workspaceDir}. Use --force to overwrite known files.`);
    }
  } catch (error) {
    if (error instanceof CliError) {
      throw error;
    }
    if (error?.code !== 'ENOENT') {
      throw new CliError(`Could not inspect Stage B workspace: ${workspaceDir}`);
    }
  }

  await fs.mkdir(workspaceDir, { recursive: true });
}

async function writeTextFile(filePath, contents) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, contents, 'utf8');
}

async function assertFileExists(filePath, label) {
  try {
    const stat = await fs.stat(filePath);
    if (!stat.isFile()) {
      throw new CliError(`${label} path exists but is not a file: ${filePath}`);
    }
  } catch (error) {
    if (error instanceof CliError) {
      throw error;
    }
    throw new CliError(`${label} is missing: ${filePath}`);
  }
}

async function copyExistingFile(sourcePath, targetPath, fallbackContents = null) {
  try {
    await assertFileExists(sourcePath, 'Source file');
    await fs.mkdir(path.dirname(targetPath), { recursive: true });
    await fs.copyFile(sourcePath, targetPath);
  } catch (error) {
    if (fallbackContents === null) {
      throw error;
    }
    await writeTextFile(targetPath, fallbackContents);
  }
}

async function copyDirectoryRecursive(sourceDir, targetDir) {
  await fs.mkdir(targetDir, { recursive: true });
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });
  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const targetPath = path.join(targetDir, entry.name);
    if (entry.isDirectory()) {
      await copyDirectoryRecursive(sourcePath, targetPath);
    } else if (entry.isFile()) {
      await fs.mkdir(path.dirname(targetPath), { recursive: true });
      await fs.copyFile(sourcePath, targetPath);
    }
  }
}

async function listFilesRecursive(directory) {
  const files = [];
  let entries = [];
  try {
    entries = await fs.readdir(directory, { withFileTypes: true });
  } catch {
    return files;
  }
  for (const entry of entries) {
    const entryPath = path.join(directory, entry.name);
    if (entry.isDirectory()) {
      files.push(...await listFilesRecursive(entryPath));
    } else if (entry.isFile()) {
      files.push(entryPath);
    }
  }
  return files;
}

async function deleteWorkspaceRelativeFile(workspaceDir, relativePath) {
  const safeRelativePath = normalizeWorkspaceRelativePath(relativePath);
  if (!safeRelativePath) return;
  const workspaceRoot = path.resolve(workspaceDir);
  const target = path.resolve(workspaceRoot, safeRelativePath);
  if (target !== workspaceRoot && !target.startsWith(`${workspaceRoot}${path.sep}`)) {
    return;
  }
  await fs.rm(target, { force: true, recursive: true });
}

function inferStageASourceId(handoff, flags) {
  return slugify(
    firstString(
      flags.projectId,
      flags.sourceId,
      handoff?.selectedPrototype?.id,
      handoff?.selectedPrototype?.slug,
      handoff?.selectedTemplate?.id,
      handoff?.selectedTemplate?.slug,
      handoff?.target?.pageTitle,
      'pixflow-stage-a-run'
    )
  );
}

function inferStageAPrompt(handoff) {
  return firstString(
    handoff?.prompt?.assembledPrompt,
    handoff?.prompt?.userPrompt,
    handoff?.context?.prompt,
    handoff?.selectedPrototype?.prompt,
    handoff?.selectedPrototype?.exampleQuery,
    handoff?.selectedPrototype?.description,
    ''
  );
}

function inferStageATitle(handoff, sourceId) {
  return firstString(
    handoff?.selectedPrototype?.title,
    handoff?.selectedPrototype?.name,
    handoff?.selectedTemplate?.title,
    handoff?.target?.pageTitle,
    sourceId
  );
}

function buildStageAContext(handoff) {
  return {
    target: handoff?.target || {},
    workflow: handoff?.workflow || {},
    selectedPrototype: handoff?.selectedPrototype || null,
    selectedTemplate: handoff?.selectedTemplate || null,
    visualReference: handoff?.visualReference || null,
    includedAttachmentIds: Array.isArray(handoff?.includedAttachmentIds) ? handoff.includedAttachmentIds : [],
    pixflowDesignSystem: handoff?.pixflowDesignSystem || null,
    generationContext: handoff?.context || {},
  };
}

function renderPromptMarkdown(prompt) {
  return `${firstString(prompt, 'No prompt was provided.')}\n`;
}

function renderStageABrief(handoff, metadata) {
  const prototype = handoff?.selectedPrototype || {};
  const target = handoff?.target || {};
  const system = handoff?.pixflowDesignSystem || {};
  const workflow = handoff?.workflow || {};
  const lines = [];

  lines.push(`# ${metadata.title}`);
  lines.push('');
  lines.push('## Goal');
  lines.push('Create the Stage A creative artifact as a polished, self-contained HTML prototype. Match Pixflow Design quality before any downstream conversion happens.');
  lines.push('');
  lines.push('## Target');
  lines.push(`- WordPress post/page: ${safe(target.pageTitle)} (${safe(String(target.wpPostId || ''))})`);
  lines.push(`- Surface: ${safe(workflow.surface)}`);
  lines.push(`- Fidelity: ${safe(metadata.fidelity)}`);
  lines.push('');
  lines.push('## Prototype Route');
  lines.push(`- Prototype: ${safe(prototype.title || prototype.name)}`);
  lines.push(`- Prototype id: ${safe(prototype.id || prototype.slug)}`);
  if (prototype.description) {
    lines.push(`- Reference description: ${prototype.description}`);
  }
  lines.push('');
  lines.push('## Design System');
  lines.push(`- Selected Pixflow Design system: ${safe(system.title || system.name || system.id)}`);
  lines.push('- Pixflow maps this into implementation output only after Stage A is approved.');
  lines.push('');
  lines.push('## Inputs');
  lines.push(`- Visual direction: ${safe(workflow.visualDirection)}`);
  lines.push(`- Context chips: ${Array.isArray(workflow.selectedContexts) ? workflow.selectedContexts.join(', ') || '-' : '-'}`);
  lines.push(`- Attachment ids: ${Array.isArray(handoff?.includedAttachmentIds) ? handoff.includedAttachmentIds.join(', ') || '-' : '-'}`);
  lines.push('');
  lines.push('## Output Contract');
  lines.push('- Write the finished artifact to `drafts/index.html`.');
  lines.push('- Keep it self-contained enough for the outer Pixflow CLI browser screenshot QA.');
  lines.push('- Do not produce implementation JSON, class mappings, CMS blocks, or runtime output in Stage A.');
  lines.push('- Do not mention Pixflow workflow internals, Bricks, WordPress, conversion stages, JSON, class mappings, or implementation wrappers in visible artifact copy. These are process constraints only.');
  lines.push('- Do not capture screenshots manually, run Playwright/Puppeteer, probe browser tooling, or install browser tooling inside the model run. The outer Pixflow CLI owns screenshot capture and browser QA after the model run.');
  lines.push('');

  return `${lines.join('\n')}\n`;
}

function renderStageAInstructions(handoff, metadata) {
  const hasReference = Boolean(handoff?.visualReference) || (Array.isArray(handoff?.includedAttachmentIds) && handoff.includedAttachmentIds.length > 0);
  const requiredReads = Array.isArray(metadata?.requiredModelReads) && metadata.requiredModelReads.length > 0
    ? metadata.requiredModelReads
    : requiredModelReadsFromHandoff(handoff);
  const hasRootSkillReads = requiredReads.includes('skill.md') || requiredReads.includes('layout-library.md');
  const lines = [];
  lines.push('# Pixflow Design Local CLI Stage A');
  lines.push('');
  lines.push('You are running the Pixflow Design Stage A workflow. This stage must behave like Pixflow Design: create and repair a high-quality web prototype first, then let Pixflow import and convert it later.');
  lines.push('');
  lines.push('## Hard Boundary');
  lines.push('- Do not use Bricks skills, Bricks JSON, Bricks selectors, Bricks template structure, or WordPress output in this stage.');
  lines.push('- Do not optimize for the Bricks compiler while designing. The artifact quality comes first.');
  lines.push('- Do not include visible artifact copy that mentions Pixflow workflow internals, Bricks, WordPress, conversion stages, JSON, class mappings, or implementation wrappers. Keep those concepts in planning files only.');
  lines.push('- The only required deliverables are `drafts/index.html`, `composition-dna.md`, `stage-a-self-critique.md`, and TODO progress updates. The outer Pixflow CLI handles screenshots and browser QA after the model run.');
  lines.push('');
  lines.push('## Files To Read First');
  lines.push('- `prompt.md`: assembled user/design prompt from Pixflow.');
  lines.push('- `brief.md`: normalized project brief and selected prototype route.');
  lines.push('- `context.json`: machine-readable Pixflow context payload.');
  lines.push('- `TODO.md`: the stage checklist.');
  lines.push('- `workspace-manifest.json`: the staged Pixflow Design source-file inventory.');
  lines.push('- `source-contract.json`: required reads, route parity, extraction tasks, and Stage A resource boundary.');
  lines.push('- `composition-dna.md`: write this before authoring the final artifact to capture the selected prototype/route structure.');
  lines.push('- `pixflow-design-core.md`: Pixflow Design prompt/discovery/critique source summary.');
  lines.push('- `plugin.md`, `stage-atoms.md`, and `plugin-snapshot.json` when present: the applied Pixflow Design plugin, active atoms, and frozen route context.');
  lines.push('- `.od-skills/<selected-prototype>/...` when present: the primary runtime-style Pixflow Design route skill. This takes priority over generic supporting skills.');
  if (hasRootSkillReads) {
    lines.push('- `skill.md` and `layout-library.md` only when they are listed under Required Reads: supporting Pixflow Design side files/layouts, never the selected route when a runtime skill exists.');
  }
  lines.push('- `checklist.md`: the active Pixflow Design quality gates.');
  lines.push('- `design-system.md`, `tokens.css`, `components-manifest.md`, and `components.html` when present: selected Pixflow Design design-system contract and component fixtures.');
  if (requiredReads.length > 0) {
    lines.push('');
    lines.push('## Pixflow Design Required Reads');
    for (const read of requiredReads) {
      lines.push(`- \`${read}\``);
    }
  }
  lines.push('');
  lines.push('## Mirrored Pixflow Design Execution Order');
  lines.push('1. Read the source contract, route parity, active plugin, stage atoms, design system, selected `.od-skills/<prototype>/` runtime skill, checklist, and every required Pixflow Design read before authoring `drafts/index.html`.');
  lines.push('2. Update `TODO.md` as the live progress ledger, matching Pixflow Design TodoWrite behavior. Mark items in progress/completed as they happen; do not batch all checkmarks at the end.');
  lines.push('3. Write `composition-dna.md` before HTML: section order, hero geometry, media roles, asset mapping, metadata density, lower-section rhythm, responsive translation, and signature motifs.');
  lines.push('4. Bind `tokens.css` and component manifest evidence into the artifact before inventing any component styling. Copy token values verbatim when a token block exists.');
  lines.push('5. If the selected `.od-skills/<prototype>/` route includes a seed/example file, use it as the structural basis. Do not write a generic page from scratch when Pixflow Design supplied a stronger route.');
  lines.push('6. Write `drafts/index.html` as the canonical standalone artifact. Pixflow imports this file later; do not emit implementation output or a separate artifact wrapper.');
  lines.push('7. Run the checklist and the Pixflow Design 5-dimensional critique: philosophy, hierarchy, execution, specificity, restraint. Repair anything under 3/5.');
  lines.push('8. Write `stage-a-self-critique.md` with the five scores, what changed during repair, and any remaining non-blocking risks.');
  lines.push('');
  lines.push('## Quality Bar');
  lines.push('- Build a complete homepage/prototype with consistent rhythm from hero through lower sections.');
  lines.push('- Use realistic copy, hierarchy, spacing, responsive behavior, and visual polish.');
  lines.push('- If a prototype or design system is selected, use it as a direction source, not a shallow skin.');
  lines.push('- Treat selected prototype examples and route files as structural evidence. Before writing, extract their composition DNA: section count/order, hero geometry, media roles, annotation density, navigation treatment, lower-section rhythms, responsive behavior, and any signature panels or motifs.');
  lines.push('- Preserve the selected prototype route at section level. Adapt the words and brand variables, but do not replace bespoke prototype sections with a generic landing-page stack, repeated equal cards, or a conventional SaaS template unless the prototype itself does that.');
  lines.push('- Every major section should have a distinct composition role. Mix editorial plates, split layouts, dark/light contrast slabs, indexes, rails, tables, proof blocks, media crops, and typographic moments according to the selected Pixflow Design example instead of repeating one grid pattern.');
  lines.push('- Match Pixflow Design density: use purposeful small labels, counts, issue/page markers, chips, corner notes, captions, and microcopy where the selected system/example uses them. These details must support the design rather than becoming random decoration.');
  lines.push('- Use local prototype/plugin assets by their intended roles from manifests and filenames. Do not downgrade supplied assets into faint backgrounds or generic thumbnails when the prototype expects them to carry section identity.');
  lines.push('- Preserve route-authored JavaScript and motion when the selected Pixflow Design example uses it, including scroll reveal, sticky header behavior, counters, marquee controls, or live-data polish. Do not strip scripts merely to simplify conversion.');
  lines.push('- If the selected example uses reveal motion, implement it as Pixflow Design does: a working `IntersectionObserver`/`data-revealed` runtime and reduced-motion fallback. Make it compatible with outer screenshot QA, but do not run manual browser/screenshot tooling inside the model pass.');
  lines.push('- Match the selected Pixflow Design example `data-od-id` density. Use markers for Pixflow Design-style landmarks and top-level sections first, plus only distinctive motifs/components the route itself treats as important. Do not over-instrument every inner wrapper just for Pixflow/Bricks conversion; conversion enrichment happens later.');
  lines.push('- Preserve the selected example density: if the Pixflow Design route carries long editorial copy, dense CSS, micro-labels, and scripted polish, the Pixflow artifact should not become a shorter, cleaner substitute. The local QA reports artifacts whose CSS craft layer is materially thinner than the staged Pixflow Design example so we can compare parity without forcing an automatic second run.');
  lines.push('- Do not spend time installing, probing, or running browser automation tooling inside the model run. The outer Pixflow CLI captures screenshots and runs browser QA after you finish; if local browser tooling is unavailable to the model, continue with static checks.');
  lines.push('- Avoid oversized blank scroll gaps. Every section heading must be followed by its real body content in the same visual band, and dark/light panels must not appear empty in screenshot QA.');
  lines.push('- Give each major section explicit background ownership. Do not rely on body-level page-height percentage gradient splits, because mobile page height changes can put lower sections on the wrong background band.');
  lines.push('- Check mobile at phone width before finishing: headings, body copy, captions, chips, and lower-section cards must remain legible against their rendered background. Repair any dark-text-on-dark-band or light-text-on-light-band issues.');
  lines.push('- Apply Pixflow Design anti-slop rules: no placeholder text, no generic Feature One/Two sections, no default violet/indigo trust gradients, no emoji-as-icons, no left-border rounded AI cards, no invented metrics, and no exposed designer/demo controls inside product UI.');
  lines.push('- Treat lower sections as first-class design work. The selected prototype route must remain recognizable below the fold, not just in the hero.');
  if (hasReference) {
    lines.push('- Inspect supplied references before layout decisions, then translate their intent rather than copying defects.');
  }
  lines.push('- Before finishing, perform a self-critique pass and repair weak lower sections.');
  lines.push('');
  lines.push('## Final Response');
  lines.push(`After creating \`drafts/index.html\`, summarize what was built for ${metadata.title}. Do not run or mention manual screenshots; the outer Pixflow CLI captures those after the model run.`);
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function renderStageARunnerPrompt(metadata) {
  return [
    'Read AGENTS.md first, then execute TODO.md exactly.',
    'Use this filesystem workspace as the complete source of truth for Pixflow Design Stage A.',
    'This is a Pixflow Design-quality artifact pass only. Do not create Bricks JSON, WordPress output, or conversion metadata.',
    'Keep workflow internals out of visible artifact copy: do not mention Pixflow, Bricks, WordPress, conversion stages, JSON, class mappings, or implementation wrappers in the rendered page.',
    'Before writing drafts/index.html, read source-contract.json, workspace-manifest.json, the active Pixflow Design skill/design-system/plugin files, and every required read listed in TODO.md.',
    'Update TODO.md throughout the run to mirror Pixflow Design TodoWrite progress.',
    'Write composition-dna.md before authoring the final artifact so the selected prototype route is preserved through every section.',
    'Match the selected Pixflow Design example data-od-id pattern: landmarks and top-level route sections first, plus only distinctive motifs/components the example itself marks or clearly treats as comparison anchors. Do not add dense inner annotations for Bricks conversion in Stage A.',
    'Assign explicit backgrounds to every major section and verify phone-width text contrast; avoid body-level percentage gradient splits for section transitions.',
    'Create drafts/index.html as the complete standalone artifact.',
    'Run checklist.md and a five-dimensional Pixflow Design critique, repair weak areas, and write stage-a-self-critique.md.',
    'Do not install, probe, or run browser automation tooling inside the model run; the outer Pixflow CLI handles screenshots and browser QA after you finish.',
    `Finish only when ${metadata.title} is ready for screenshot comparison against the selected Pixflow Design baseline.`,
    '',
  ].join('\n');
}

function renderStageATodo(metadata) {
  const reads = Array.isArray(metadata.requiredModelReads) ? metadata.requiredModelReads : [];
  const hasRootSkillReads = reads.includes('skill.md') || reads.includes('layout-library.md');
  const lines = [];
  lines.push(`# Stage A TODO: ${metadata.title}`);
  lines.push('');
  lines.push('- [ ] Read `prompt.md`, `brief.md`, `context.json`, `workspace-manifest.json`, and `source-contract.json` before coding.');
  lines.push('- [ ] Read `pixflow-design-core.md`, `plugin.md`, `stage-atoms.md`, `plugin-snapshot.json`, and `checklist.md` when present.');
  if (hasRootSkillReads) {
    lines.push('- [ ] Read root `skill.md` and `layout-library.md` only because they are listed in Required Reads; do not let them override the selected runtime skill.');
  }
  lines.push('- [ ] Read the selected `.od-skills/<prototype>/` runtime skill before generic supporting skills; this mirrors Pixflow Design CLI route staging.');
  lines.push('- [ ] Read `design-system.md`, `tokens.css`, `components-manifest.md`, and `components.html` when present; bind token/component evidence into the artifact.');
  for (const read of reads) {
    lines.push(`- [ ] Read \`${read}\` from the Pixflow Design workspace preflight.`);
  }
  lines.push('- [ ] Review `route-parity.json` and preserve the selected Pixflow Design route, including route-specific extraction/source tasks.');
  lines.push('- [ ] Plan the page sections and the visual system before writing the final artifact.');
  lines.push('- [ ] Extract the selected prototype/example composition DNA: section order, distinctive layouts, asset roles, metadata density, and lower-section rhythm.');
  lines.push('- [ ] Write `composition-dna.md` with the selected route/prototype structure, asset roles, signature motifs, and responsive translation notes.');
  lines.push('- [ ] Use the selected `.od-skills/<prototype>/` seed/example structure as the basis when available; do not replace it with a generic landing-page stack.');
  lines.push('- [ ] Match the selected Pixflow Design example `data-od-id` density: landmarks and top-level route sections first, plus only distinctive motifs/components the example itself marks or clearly treats as comparison anchors.');
  lines.push('- [ ] Create `drafts/index.html` as a complete Pixflow Design-quality HTML prototype.');
  lines.push('- [ ] Review hero, mid-page, lower sections, responsive behavior, spacing, typography, and CTAs.');
  lines.push('- [ ] Verify phone-width mobile contrast and section background ownership; no lower-section heading/copy may sit on the wrong dark/light band.');
  lines.push('- [ ] Remove body-level page-height percentage gradient splits used for section transitions; use explicit section backgrounds instead.');
  lines.push('- [ ] Score the artifact against the selected Pixflow Design example for section distinctiveness, editorial detail, asset-role fidelity, and mobile translation; repair anything that feels generic.');
  lines.push('- [ ] Run `checklist.md` and the Pixflow Design 5-dimensional critique: philosophy, hierarchy, execution, specificity, restraint.');
  lines.push('- [ ] Write `stage-a-self-critique.md` with the five scores, repairs made, and remaining risks.');
  lines.push('- [ ] Preserve Pixflow Design-authored scripts/motion when present in the selected route, including reveal, sticky-header, counter, marquee, or live-data behavior.');
  lines.push('- [ ] If scroll reveal is used, implement a working reveal runtime and reduced-motion handling; the outer Pixflow CLI verifies screenshots after the model run.');
  lines.push('- [ ] Repair any weak sections before import into Pixflow.');
  lines.push('- [ ] Keep Bricks conversion out of Stage A.');
  lines.push('- [ ] Remove visible artifact copy that mentions Bricks, WordPress, JSON, class mappings, conversion stages, or implementation wrappers.');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function requiredModelReadsFromHandoff(handoff) {
  const workspace = workspacePreflightFromHandoff(handoff);
  if (!workspace) {
    return [];
  }
  const sourceContract = objectValue(workspace.source_contract || workspace.sourceContract);
  return requiredModelReadsFromSourceContract(sourceContract);
}

function requiredModelReadsFromSourceContract(sourceContract) {
  const reads = Array.isArray(sourceContract.required_model_reads)
    ? sourceContract.required_model_reads
    : Array.isArray(sourceContract.requiredModelReads)
      ? sourceContract.requiredModelReads
      : [];
  return reads.map((item) => firstString(item)).filter(Boolean);
}

function sameStringList(left, right) {
  const a = (left || []).map((item) => firstString(item)).filter(Boolean).sort();
  const b = (right || []).map((item) => firstString(item)).filter(Boolean).sort();
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

function renderStageAWorkspaceReadme(result) {
  const lines = [];
  lines.push(`# Pixflow Stage A Workspace: ${result.title}`);
  lines.push('');
  lines.push('This folder was prepared by the Pixflow Design CLI bridge.');
  lines.push('');
  lines.push('## Run');
  lines.push('');
  lines.push('```bash');
  lines.push(result.suggestedRunCommand);
  lines.push('```');
  lines.push('');
  lines.push('## Import');
  lines.push('');
  lines.push('After `drafts/index.html` exists, import it back into Pixflow:');
  lines.push('');
  lines.push('```bash');
  lines.push(result.importCommand);
  lines.push('```');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

function renderStageBWorkspaceReadme(result) {
  const lines = [];
  lines.push(`# Pixflow Stage B Workspace: ${result.title}`);
  lines.push('');
  lines.push('This folder was prepared by the Pixflow Design CLI bridge for local Bricks conversion.');
  lines.push('');
  lines.push('## Source');
  lines.push('');
  lines.push(`- Stage A workspace: \`${result.stageAWorkspace}\``);
  lines.push(`- Stage A artifact: \`${result.stageAArtifact}\``);
  lines.push('');
  lines.push('## Run');
  lines.push('');
  lines.push('```bash');
  lines.push(result.suggestedRunCommand);
  lines.push('```');
  lines.push('');
  lines.push('## Expected Output');
  lines.push('');
  lines.push('- `stage-b-route-contract.json`');
  lines.push('- `stage-b-theme-style-contract.json`');
  lines.push('- `stage-b-theme-style-health.json`');
  lines.push('- `stage-b-color-system.json`');
  lines.push('- `stage-b-font-system.json`');
  lines.push('- `stage-b-icon-system.json`');
  lines.push('- `bricks-result.json`');
  lines.push('- `bricks-payload.json`');
  lines.push('- `bricks-header-payload.json`');
  lines.push('- `bricks-footer-payload.json`');
  lines.push('- `global-classes.json`');
  lines.push('- `conversion-report.md`');
  lines.push('');
  return `${lines.join('\n')}\n`;
}

async function runBridgeDaemonCommand(args, flags) {
  const subcommand = firstString(args[0], 'help').toLowerCase();

  if (subcommand === 'help' || flags.help) {
    printBridgeDaemonHelp();
    return;
  }

  if (subcommand === 'start') {
    await startBridgeDaemon(flags);
    return;
  }

  if (subcommand === 'status') {
    const status = await fetchBridgeDaemonJson(flags, '/v1/status');
    outputResult(status, flags, renderBridgeDaemonStatusSummary);
    return;
  }

  if (subcommand === 'stop') {
    const stopped = await fetchBridgeDaemonJson(flags, '/v1/shutdown', { method: 'POST' });
    outputResult(stopped, flags, (result) => `Pixflow Bridge daemon: ${result.status || 'unknown'}`);
    return;
  }

  throw new CliError(`Unknown daemon subcommand "${subcommand}". Use "daemon help".`);
}

async function pairBridgeFromProtocolUrl(args, flags) {
  const payload = parseBridgeProtocolPairPayload(args, flags);
  const host = firstString(flags.host, process.env.PIXFLOW_BRIDGE_HOST, DEFAULT_BRIDGE_DAEMON_HOST);
  if (!isLoopbackHost(host)) {
    throw new CliError(`Pixflow Bridge pairing only supports loopback hosts. Refusing host "${host}".`);
  }

  const port = parsePositiveIntegerFlag(
    firstString(flags.port, process.env.PIXFLOW_BRIDGE_PORT),
    DEFAULT_BRIDGE_DAEMON_PORT
  );
  const dataDir = resolveBridgeDaemonDataDir(flags);

  await fetchBridgeDaemonJson({ ...flags, host, port }, '/v1/shutdown', { method: 'POST' }).catch(() => {});
  await sleep(500);

  const context = await createBridgeDaemonContext({ host, port, dataDir });
  const result = await pairBridgeSite(context, payload);
  if (result.status !== 'ok') {
    return result;
  }

  const daemon = startBridgeDaemonDetached({ dataDir, host, port });
  return {
    ...result,
    message: 'Pixflow Bridge is connected to this Pixflow Design site.',
    daemon,
  };
}

function parseBridgeProtocolPairPayload(args, flags) {
  const raw = firstString(flags.url, flags.uri, args[0]);
  if (!raw) {
    throw new CliError('Missing Pixflow Bridge pairing URL.');
  }

  let encoded = raw;
  if (/^pixflow-bridge:\/\//i.test(raw)) {
    let parsed;
    try {
      parsed = new URL(raw);
    } catch {
      throw new CliError('Pixflow Bridge pairing URL is invalid.');
    }
    const action = firstString(parsed.hostname, parsed.pathname.replace(/^\/+/, ''));
    if (action !== 'pair') {
      throw new CliError(`Unsupported Pixflow Bridge URL action "${action}".`);
    }
    encoded = firstString(parsed.searchParams.get('payload') || '');
  }

  if (!encoded) {
    throw new CliError('Pixflow Bridge pairing URL is missing its payload.');
  }

  let payload = {};
  try {
    payload = JSON.parse(Buffer.from(normalizeBase64Url(encoded), 'base64').toString('utf8'));
  } catch {
    throw new CliError('Pixflow Bridge pairing payload is invalid.');
  }

  if (!isPlainObject(payload)) {
    throw new CliError('Pixflow Bridge pairing payload must be a JSON object.');
  }

  for (const key of ['siteUrl', 'pairingCompleteUrl', 'challengeId', 'challengeSecret']) {
    if (!firstString(payload[key])) {
      throw new CliError(`Pixflow Bridge pairing payload is missing ${key}.`);
    }
  }

  return payload;
}

function normalizeBase64Url(value) {
  const text = firstString(value).replace(/-/g, '+').replace(/_/g, '/');
  return `${text}${'='.repeat((4 - (text.length % 4)) % 4)}`;
}

function startBridgeDaemonDetached({ dataDir, host, port }) {
  const cliFile = fileURLToPath(import.meta.url);
  const child = spawn(process.execPath, [
    cliFile,
    'daemon',
    'start',
    '--data-dir',
    dataDir,
    '--host',
    host,
    '--port',
    String(port),
  ], {
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  child.unref();
  return {
    pid: child.pid,
    url: `http://${host}:${port}`,
  };
}

function renderBridgeProtocolPairSummary(result) {
  const site = result.site || {};
  const daemon = result.daemon || {};
  const lines = [];
  lines.push(result.message || 'Pixflow Bridge pairing completed.');
  lines.push(`Site: ${safe(site.siteName || site.siteUrl)}`);
  lines.push(`Status: ${safe(site.status || result.status)}`);
  if (daemon.url) {
    lines.push(`Daemon: ${safe(daemon.url)}`);
  }
  return lines.join('\n');
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

function printBridgeDaemonHelp() {
  process.stdout.write(`Pixflow Bridge Daemon ${VERSION}

Usage:
  node tools/pixflow-design-cli/pixflow-design-cli.mjs daemon start [options]
  node tools/pixflow-design-cli/pixflow-design-cli.mjs daemon status [options]
  node tools/pixflow-design-cli/pixflow-design-cli.mjs daemon stop [options]

Options:
  --host <host>             Loopback host. Default: ${DEFAULT_BRIDGE_DAEMON_HOST}.
  --port <port>             Local daemon port. Default: ${DEFAULT_BRIDGE_DAEMON_PORT}.
  --daemon-url <url>        Existing daemon URL for status/stop.
  --data-dir <path>         Bridge state folder. Default: OS app data folder.
  --json                    Print raw JSON for status/stop.

Initial daemon API:
  GET    /v1/status
  GET    /v1/agents
  POST   /v1/agents/active
  GET    /v1/sites
  POST   /v1/sites/pair
  DELETE /v1/sites/:id
  POST   /v1/runs
  GET    /v1/runs
  GET    /v1/runs/:id
  GET    /v1/runs/:id/events
  POST   /v1/runs/:id/cancel
  POST   /v1/shutdown
`);
}

async function startBridgeDaemon(flags) {
  const host = firstString(flags.host, process.env.PIXFLOW_BRIDGE_HOST, DEFAULT_BRIDGE_DAEMON_HOST);
  if (!isLoopbackHost(host)) {
    throw new CliError(`Pixflow Bridge daemon only supports loopback hosts. Refusing host "${host}".`);
  }

  const port = parsePositiveIntegerFlag(
    firstString(flags.port, process.env.PIXFLOW_BRIDGE_PORT),
    DEFAULT_BRIDGE_DAEMON_PORT
  );
  const dataDir = resolveBridgeDaemonDataDir(flags);
  const context = await createBridgeDaemonContext({ host, port, dataDir });

  const server = http.createServer((request, response) => {
    handleBridgeDaemonRequest(context, request, response).catch((error) => {
      sendBridgeJson(response, 500, {
        status: 'error',
        code: 'bridge_daemon_request_failed',
        message: error instanceof Error ? error.message : String(error),
      });
    });
  });

  context.shutdown = () => {
    if (context.pollTimer) {
      clearInterval(context.pollTimer);
      context.pollTimer = null;
    }
    for (const child of context.children.values()) {
      child.kill('SIGTERM');
    }
    for (const subscribers of context.eventSubscribers.values()) {
      for (const subscriber of subscribers) {
        subscriber.end();
      }
    }
    server.close();
  };

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => {
      server.off('error', reject);
      resolve();
    });
  });

  process.on('SIGINT', () => {
    context.shutdown();
    process.exit(0);
  });
  process.on('SIGTERM', () => {
    context.shutdown();
    process.exit(0);
  });

  const url = `http://${host}:${port}`;
  if (flags.json) {
    process.stdout.write(`${JSON.stringify(buildBridgeDaemonStatus(context), null, 2)}\n`);
  } else {
    process.stdout.write(`Pixflow Bridge daemon listening on ${url}\n`);
    process.stdout.write(`Data: ${dataDir}\n`);
  }

  startBridgeOutboundPoller(context);
}

async function createBridgeDaemonContext({ host, port, dataDir }) {
  await fs.mkdir(dataDir, { recursive: true });
  const stateFile = path.join(dataDir, 'bridge-state.json');
  const runsDir = path.join(dataDir, 'runs');
  await fs.mkdir(runsDir, { recursive: true });

  const state = await loadBridgeDaemonState(stateFile);
  state.protocolVersion = BRIDGE_DAEMON_PROTOCOL_VERSION;
  state.bridgeVersion = VERSION;
  state.updatedAt = new Date().toISOString();
  await writeJsonFile(stateFile, state);

  return {
    host,
    port,
    dataDir,
    stateFile,
    runsDir,
    startedAt: new Date().toISOString(),
    state,
    children: new Map(),
    eventSubscribers: new Map(),
    pollTimer: null,
    polling: false,
    shutdown: null,
  };
}

async function loadBridgeDaemonState(stateFile) {
  const state = await readOptionalJson(stateFile);
  return {
    type: 'pixflow_bridge_daemon_state',
    version: 1,
    bridgeVersion: firstString(state.bridgeVersion, VERSION),
    protocolVersion: firstString(state.protocolVersion, BRIDGE_DAEMON_PROTOCOL_VERSION),
    createdAt: firstString(state.createdAt, new Date().toISOString()),
    updatedAt: firstString(state.updatedAt, new Date().toISOString()),
    activeAgentId: normalizeBridgeAgentId(firstString(state.activeAgentId, state.active_agent_id, 'codex')),
    sites: Array.isArray(state.sites) ? state.sites.filter(isPlainObject) : [],
    runs: Array.isArray(state.runs) ? state.runs.filter(isPlainObject) : [],
  };
}

async function saveBridgeDaemonState(context) {
  context.state.updatedAt = new Date().toISOString();
  await writeJsonFile(context.stateFile, context.state);
}

async function handleBridgeDaemonRequest(context, request, response) {
  const requestUrl = new URL(request.url || '/', `http://${context.host}:${context.port}`);
  const pathname = requestUrl.pathname.replace(/\/+$/, '') || '/';
  applyBridgeCorsHeaders(context, request, response, pathname);

  if (request.method === 'OPTIONS') {
    response.writeHead(204);
    response.end();
    return;
  }

  if (request.method === 'GET' && pathname === '/v1/status') {
    sendBridgeJson(response, 200, buildBridgeDaemonStatus(context));
    return;
  }

  if (request.method === 'GET' && pathname === '/v1/agents') {
    sendBridgeJson(response, 200, await buildBridgeDaemonAgentStatus(context));
    return;
  }

  if (request.method === 'POST' && pathname === '/v1/agents/active') {
    const payload = await readBridgeJsonRequest(request);
    const result = await setBridgeDaemonActiveAgent(context, payload);
    sendBridgeJson(response, result.status === 'ok' ? 200 : 400, result);
    return;
  }

  if (request.method === 'GET' && pathname === '/v1/sites') {
    sendBridgeJson(response, 200, {
      status: 'ok',
      sites: context.state.sites.map(sanitizeBridgeSiteRecord),
    });
    return;
  }

  if (request.method === 'POST' && pathname === '/v1/sites/pair') {
    const payload = await readBridgeJsonRequest(request);
    const paired = await pairBridgeSite(context, payload);
    sendBridgeJson(response, paired.status === 'ok' ? 201 : 400, paired);
    return;
  }

  const siteDelete = pathname.match(/^\/v1\/sites\/([^/]+)$/);
  if (request.method === 'DELETE' && siteDelete) {
    const removed = await deleteBridgeSite(context, decodeURIComponent(siteDelete[1]));
    sendBridgeJson(response, removed.removed ? 200 : 404, removed);
    return;
  }

  if (request.method === 'GET' && pathname === '/v1/runs') {
    sendBridgeJson(response, 200, {
      status: 'ok',
      runs: context.state.runs.map(sanitizeBridgeRunRecord),
    });
    return;
  }

  if (request.method === 'POST' && pathname === '/v1/runs') {
    const payload = await readBridgeJsonRequest(request);
    const run = await startBridgeDaemonRun(context, payload);
    sendBridgeJson(response, 202, {
      status: 'accepted',
      run: sanitizeBridgeRunRecord(run),
    });
    return;
  }

  const runEvents = pathname.match(/^\/v1\/runs\/([^/]+)\/events$/);
  if (request.method === 'GET' && runEvents) {
    await handleBridgeRunEventsRequest(context, response, decodeURIComponent(runEvents[1]), requestUrl);
    return;
  }

  const runCancel = pathname.match(/^\/v1\/runs\/([^/]+)\/cancel$/);
  if (request.method === 'POST' && runCancel) {
    const result = await cancelBridgeDaemonRun(context, decodeURIComponent(runCancel[1]));
    sendBridgeJson(response, result.status === 'not_found' ? 404 : 200, result);
    return;
  }

  const runGet = pathname.match(/^\/v1\/runs\/([^/]+)$/);
  if (request.method === 'GET' && runGet) {
    const run = findBridgeRun(context, decodeURIComponent(runGet[1]));
    sendBridgeJson(response, run ? 200 : 404, run ? {
      status: 'ok',
      run: sanitizeBridgeRunRecord(run),
    } : {
      status: 'not_found',
      code: 'bridge_run_not_found',
    });
    return;
  }

  if (request.method === 'POST' && pathname === '/v1/shutdown') {
    sendBridgeJson(response, 202, {
      status: 'stopping',
      message: 'Pixflow Bridge daemon shutdown scheduled.',
    });
    setTimeout(() => {
      context.shutdown?.();
      process.exit(0);
    }, 50).unref?.();
    return;
  }

  sendBridgeJson(response, 404, {
    status: 'not_found',
    code: 'bridge_daemon_route_not_found',
    path: pathname,
  });
}

function buildBridgeDaemonStatus(context) {
  const runningCount = context.state.runs.filter((run) => run.status === 'running').length;
  const installation = readBridgeInstallationManifestSync();
  return {
    status: 'ok',
    service: 'pixflow-bridge-daemon',
    bridgeVersion: VERSION,
    protocolVersion: BRIDGE_DAEMON_PROTOCOL_VERSION,
    installerVersion: firstString(installation.installerVersion),
    installedAt: firstString(installation.installedAt),
    updatedAt: firstString(installation.updatedAt),
    installRoot: firstString(installation.installRoot),
    pid: process.pid,
    host: context.host,
    port: context.port,
    url: `http://${context.host}:${context.port}`,
    dataDir: context.dataDir,
    nodeVersion: process.version,
    platform: process.platform,
    arch: process.arch,
    startedAt: context.startedAt,
    sites: {
      count: context.state.sites.length,
      connected: context.state.sites.filter((site) => site.status === 'connected').length,
    },
    runs: {
      count: context.state.runs.length,
      running: runningCount,
    },
    capabilities: {
      daemon: true,
      headless: true,
      runRegistry: true,
      eventLog: true,
      eventStream: true,
      cancellation: true,
      sitePairingRecords: true,
      providerCatalog: true,
      providerDetection: true,
      providerActiveSelection: true,
      providerAuthUi: false,
      installerUpdater: true,
    },
  };
}

function readBridgeInstallationManifestSync() {
  const cliPath = fileURLToPath(import.meta.url);
  const cliDir = path.dirname(cliPath);
  const candidates = [
    path.resolve(cliDir, '..', '..', 'manifest.json'),
    path.resolve(cliDir, '..', '..', '..', 'manifest.json'),
    path.resolve(process.cwd(), 'manifest.json'),
  ];
  for (const candidate of candidates) {
    try {
      const raw = readFileSync(candidate, 'utf8');
      const parsed = JSON.parse(raw);
      if (isPlainObject(parsed) && firstString(parsed.type) === 'pixflow_bridge_installation') {
        return parsed;
      }
    } catch {
      // Not an installed bridge manifest path.
    }
  }
  return {};
}

async function buildBridgeDaemonAgentStatus(context) {
  const detected = [];
  for (const agent of BRIDGE_AGENT_CATALOG) {
    const command = await detectFirstCommand(agent);
    const version = command.path ? await probeBridgeAgentVersion(command.path, agent.versionArgs || ['--version']) : '';
    const auth = command.path ? await probeBridgeAgentAuthStatus(agent, command.path) : {
      status: 'unknown',
      message: 'CLI executable was not found.',
    };
    detected.push({
      id: agent.id,
      label: agent.label,
      description: agent.description,
      commands: agent.commands,
      available: command.path !== '',
      command: command.command,
      path: command.path,
      pathSource: command.pathSource,
      pathSourceLabel: command.pathSourceLabel,
      version,
      docsUrl: sanitizeBridgeHttpsUrl(agent.docsUrl),
      installUrl: sanitizeBridgeHttpsUrl(agent.installUrl),
      authStatus: auth.status,
      authMessage: auth.message,
      authProbe: auth.probe,
      supportStatus: agent.supportStatus || 'detected',
      active: normalizeBridgeAgentId(context.state.activeAgentId) === agent.id,
      notes: command.path === ''
        ? buildBridgeUnavailableAgentNotes(agent)
        : buildBridgeAgentNotes(agent, auth, command),
    });
  }

  const available = detected.filter((agent) => agent.available);
  const runnerReady = detected.filter((agent) => agent.available && agent.supportStatus === 'stage_runner_ready');
  const authOk = detected.filter((agent) => agent.available && agent.authStatus === 'ok');
  const authMissing = detected.filter((agent) => agent.available && agent.authStatus === 'missing');
  const activeAgentId = normalizeBridgeAgentId(context.state.activeAgentId);
  const activeAgent = detected.find((agent) => agent.id === activeAgentId) || null;

  return {
    status: 'ok',
    activeAgentId,
    activeAgent,
    counts: {
      total: detected.length,
      available: available.length,
      runnerReady: runnerReady.length,
      authOk: authOk.length,
      authMissing: authMissing.length,
      unavailable: detected.length - available.length,
    },
    agents: detected,
    customRunner: {
      available: true,
      notes: `Custom runner commands remain available through direct CLI flags. Runner-ready presets: ${Array.from(BRIDGE_STAGE_RUNNER_AGENT_IDS).join(', ')}.`,
    },
  };
}

function startBridgeOutboundPoller(context) {
  if (context.pollTimer) {
    return;
  }

  const poll = () => {
    pollPairedBridgeSites(context).catch((error) => {
      if (!context.lastPollError || context.lastPollError !== (error?.message || String(error))) {
        context.lastPollError = error?.message || String(error);
        process.stderr.write(`Pixflow Bridge poll warning: ${context.lastPollError}\n`);
      }
    });
  };

  context.pollTimer = setInterval(poll, 2500);
  context.pollTimer.unref?.();
  setTimeout(poll, 250).unref?.();
}

async function pollPairedBridgeSites(context) {
  if (context.polling) {
    return;
  }

  context.polling = true;
  try {
    const sites = context.state.sites.filter((site) => firstString(site.status) === 'connected' && firstString(site.bridgeToken));
    for (const site of sites) {
      await pollPairedBridgeSite(context, site);
    }
  } finally {
    context.polling = false;
  }
}

async function pollPairedBridgeSite(context, site) {
  const pollUrl = bridgeSiteEndpoint(site, 'jobsPoll', '/cli-bridge/jobs/poll');
  const completeUrl = bridgeSiteEndpoint(site, 'jobsComplete', '/cli-bridge/jobs/complete');
  if (!pollUrl || !completeUrl) {
    return;
  }

  const agentStatus = await buildBridgeDaemonAgentStatus(context);
  const pollResult = await postBridgeSiteJson(site, pollUrl, {
    ...buildBridgeDaemonHeartbeatPayload(context, site),
    agentCounts: agentStatus.counts || {},
    activeAgentId: agentStatus.activeAgentId || '',
  });
  const jobs = Array.isArray(pollResult.jobs) ? pollResult.jobs.filter(isPlainObject) : [];
  for (const job of jobs) {
    await completeBridgeSiteJob(context, site, completeUrl, job);
  }
}

function buildBridgeDaemonHeartbeatPayload(context, site) {
  const installation = readBridgeInstallationManifestSync();
  return {
    bridgeId: firstString(site.bridgeId),
    bridgeVersion: VERSION,
    protocolVersion: BRIDGE_DAEMON_PROTOCOL_VERSION,
    installerVersion: firstString(installation.installerVersion),
    nodeVersion: process.version,
    platform: process.platform,
    arch: process.arch,
    activeAgentId: normalizeBridgeAgentId(context.state.activeAgentId),
  };
}

async function completeBridgeSiteJob(context, site, completeUrl, job) {
  const jobId = firstString(job.jobId, job.id);
  const type = firstString(job.type);
  if (!jobId) {
    return;
  }

  try {
    let result = {};
    if (type === 'agents_scan') {
      result = await buildBridgeDaemonAgentStatus(context);
    } else if (type === 'agents_set_active') {
      const payload = objectValue(job.payload);
      const selected = await setBridgeDaemonActiveAgent(context, payload);
      if (selected.status !== 'ok') {
        throw new CliError(selected.message || 'Could not set active CLI provider.');
      }
      result = await buildBridgeDaemonAgentStatus(context);
    } else {
      throw new CliError(`Unsupported Pixflow Bridge job type "${type}".`);
    }

    await postBridgeSiteJson(site, completeUrl, {
      jobId,
      status: 'completed',
      result,
    });
  } catch (error) {
    await postBridgeSiteJson(site, completeUrl, {
      jobId,
      status: 'failed',
      error: {
        message: error?.message || String(error),
      },
    }).catch(() => {});
  }
}

function bridgeSiteEndpoint(site, key, fallbackRoute) {
  const endpoints = objectValue(site.endpoints);
  const explicit = firstString(endpoints[key], endpoints[toSnakeCase(key)]);
  if (explicit) {
    return explicit;
  }

  const siteUrl = normalizeSiteUrl(site.siteUrl);
  if (!siteUrl) {
    return '';
  }
  const namespace = normalizeRestNamespace(firstString(site.restNamespace, DEFAULT_REST_NAMESPACE));
  return `${siteUrl.replace(/\/+$/, '')}/wp-json/${namespace}${fallbackRoute}`;
}

function toSnakeCase(value) {
  return firstString(value).replace(/[A-Z]/g, (match) => `_${match.toLowerCase()}`);
}

async function postBridgeSiteJson(site, url, payload) {
  const token = firstString(site.bridgeToken);
  if (!token) {
    throw new CliError('Paired Pixflow site is missing its bridge token.');
  }

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload || {}),
  });
  const text = await response.text();
  const body = parseJsonBody(text, url);
  if (!response.ok) {
    throw new CliError(`Pixflow Bridge site request failed (${response.status})`, {
      url,
      status: response.status,
      body,
    });
  }
  return body;
}

async function detectFirstCommand(agent) {
  for (const command of agent.commands || []) {
    const found = await commandExists(agent, command);
    if (found.path) {
      return found;
    }
  }
  return emptyBridgeCommandResult();
}

async function commandExists(agent, command) {
  const entries = bridgeAgentSearchEntries(agent);
  const extensions = process.platform === 'win32'
    ? (process.env.PATHEXT || '.EXE;.CMD;.BAT;.COM').split(';').filter(Boolean)
    : [''];
  const seen = new Set();

  for (const entry of entries) {
    const dir = entry.dir;
    for (const extension of extensions) {
      const candidate = path.join(dir, process.platform === 'win32' && !path.extname(command) ? `${command}${extension}` : command);
      const normalized = process.platform === 'win32' ? candidate.toLowerCase() : candidate;
      if (seen.has(normalized)) continue;
      seen.add(normalized);
      try {
        await fs.access(candidate);
        const source = bridgeResolvedCommandSource(agent, candidate, entry);
        return {
          command,
          path: candidate,
          pathSource: source.pathSource,
          pathSourceLabel: source.pathSourceLabel,
        };
      } catch {
        // Try next candidate.
      }
    }
  }
  return emptyBridgeCommandResult(command);
}

function detectFirstCommandSync(agent) {
  for (const command of agent.commands || []) {
    const found = commandExistsSync(agent, command);
    if (found.path) {
      return found;
    }
  }
  return emptyBridgeCommandResult();
}

function commandExistsSync(agent, command) {
  const entries = bridgeAgentSearchEntries(agent);
  const extensions = process.platform === 'win32'
    ? (process.env.PATHEXT || '.EXE;.CMD;.BAT;.COM').split(';').filter(Boolean)
    : [''];
  const seen = new Set();

  for (const entry of entries) {
    const dir = entry.dir;
    for (const extension of extensions) {
      const candidate = path.join(dir, process.platform === 'win32' && !path.extname(command) ? `${command}${extension}` : command);
      const normalized = process.platform === 'win32' ? candidate.toLowerCase() : candidate;
      if (seen.has(normalized)) continue;
      seen.add(normalized);
      if (existsSync(candidate)) {
        const source = bridgeResolvedCommandSource(agent, candidate, entry);
        return {
          command,
          path: candidate,
          pathSource: source.pathSource,
          pathSourceLabel: source.pathSourceLabel,
        };
      }
    }
  }
  return emptyBridgeCommandResult(command);
}

function emptyBridgeCommandResult(command = '') {
  return {
    command,
    path: '',
    pathSource: '',
    pathSourceLabel: '',
  };
}

function bridgeAgentSearchEntries(agent) {
  const entries = bridgeAgentSearchPaths().map((dir) => ({
    dir,
    pathSource: bridgePathSource(dir),
    pathSourceLabel: bridgePathSourceLabel(dir),
  }));
  entries.push(...bridgeAntigravityExtensionSearchEntries(agent));
  return entries;
}

function bridgeResolvedCommandSource(agent, candidate, fallbackEntry = {}) {
  const extensionSource = bridgeAntigravityExtensionSourceForPath(agent, candidate);
  if (extensionSource.pathSource) {
    return extensionSource;
  }
  return {
    pathSource: firstString(fallbackEntry.pathSource),
    pathSourceLabel: firstString(fallbackEntry.pathSourceLabel),
  };
}

function bridgeAgentSearchPaths() {
  const seen = new Set();
  const paths = [
    path.dirname(process.execPath),
    ...(process.env.Path || process.env.PATH || '').split(path.delimiter),
    ...bridgeKnownToolchainPaths(),
  ];

  return paths
    .map((entry) => firstString(entry).trim())
    .filter((entry) => {
      if (!entry) return false;
      const normalized = process.platform === 'win32' ? entry.toLowerCase() : entry;
      if (seen.has(normalized)) return false;
      seen.add(normalized);
      return true;
    });
}

function bridgeKnownToolchainPaths() {
  const home = os.homedir();
  const paths = [];

  if (process.platform === 'win32') {
    const appData = firstString(process.env.APPDATA);
    const localAppData = firstString(process.env.LOCALAPPDATA);
    const programFiles = firstString(process.env.ProgramFiles);
    const programFilesX86 = firstString(process.env['ProgramFiles(x86)']);
    paths.push(
      appData ? path.join(appData, 'npm') : '',
      localAppData ? path.join(localAppData, 'pnpm') : '',
      localAppData ? path.join(localAppData, 'Programs', 'nodejs') : '',
      localAppData ? path.join(localAppData, 'Programs', 'Antigravity', 'bin') : '',
      localAppData ? path.join(localAppData, 'Microsoft', 'WinGet', 'Links') : '',
      programFiles ? path.join(programFiles, 'nodejs') : '',
      programFilesX86 ? path.join(programFilesX86, 'nodejs') : '',
      path.join(home, 'scoop', 'shims'),
      path.join(home, '.local', 'bin'),
      path.join(home, '.bun', 'bin'),
      path.join(home, '.cargo', 'bin'),
      path.join(home, '.volta', 'bin'),
    );
  } else {
    const xdgDataHome = firstString(process.env.XDG_DATA_HOME, path.join(home, '.local', 'share'));
    paths.push(
      '/opt/homebrew/bin',
      '/usr/local/bin',
      '/usr/bin',
      path.join(home, '.local', 'bin'),
      path.join(home, '.npm-global', 'bin'),
      path.join(home, '.bun', 'bin'),
      path.join(home, '.cargo', 'bin'),
      path.join(home, '.deno', 'bin'),
      path.join(home, '.volta', 'bin'),
      path.join(xdgDataHome, 'pnpm'),
    );
  }

  const fnmRoot = firstString(process.env.FNM_DIR, path.join(home, '.fnm'));
  paths.push(...bridgeVersionManagerBinPaths(path.join(fnmRoot, 'node-versions'), 3));
  paths.push(...bridgeVersionManagerBinPaths(path.join(home, '.nvm', 'versions', 'node'), 3));
  paths.push(...bridgeVersionManagerBinPaths(path.join(home, '.asdf', 'installs', 'nodejs'), 3));
  paths.push(...bridgeVersionManagerBinPaths(path.join(home, '.mise', 'installs', 'node'), 3));

  return paths.filter(Boolean);
}

function bridgePathSource(dir) {
  const value = firstString(dir);
  if (!value) return '';
  const normalized = process.platform === 'win32' ? value.toLowerCase() : value;
  const runtimeDir = path.dirname(process.execPath);
  if (normalized === (process.platform === 'win32' ? runtimeDir.toLowerCase() : runtimeDir)) {
    return 'bridge_runtime';
  }
  const pathDirs = (process.env.Path || process.env.PATH || '')
    .split(path.delimiter)
    .map((entry) => process.platform === 'win32' ? entry.toLowerCase() : entry);
  if (pathDirs.includes(normalized)) {
    return 'path';
  }
  return 'known_toolchain';
}

function bridgePathSourceLabel(dir) {
  const source = bridgePathSource(dir);
  if (source === 'bridge_runtime') return 'Pixflow Bridge runtime';
  if (source === 'path') return 'System PATH';
  return 'Local CLI install';
}

function bridgeAntigravityExtensionSearchEntries(agent) {
  if (process.platform !== 'win32') return [];
  const agentId = firstString(agent?.id);
  const specs = bridgeAntigravityExtensionSpecs(agentId);
  if (specs.length === 0) return [];
  const home = os.homedir();
  const root = path.join(home, '.antigravity', 'extensions');
  const entries = [];
  let extensions = [];
  try {
    extensions = requireFsSyncReaddir(root);
  } catch {
    return entries;
  }

  for (const extension of extensions.sort((left, right) => right.name.localeCompare(left.name))) {
    if (!extension.isDirectory()) continue;
    for (const spec of specs) {
      if (!spec.match.test(extension.name)) continue;
      for (const segments of spec.dirSegments) {
        const dir = path.join(root, extension.name, ...segments);
        if (!existsSync(dir)) continue;
        entries.push({
          dir,
          pathSource: 'antigravity_extension',
          pathSourceLabel: spec.label,
        });
      }
    }
  }

  return entries;
}

function bridgeAntigravityExtensionSourceForPath(agent, filePath) {
  if (process.platform !== 'win32') {
    return emptyBridgeCommandSource();
  }
  const value = firstString(filePath);
  if (!value) return emptyBridgeCommandSource();
  const home = os.homedir();
  const root = path.join(home, '.antigravity', 'extensions');
  const relative = path.relative(root, value);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
    return emptyBridgeCommandSource();
  }
  const extensionName = relative.split(/[\\/]/)[0] || '';
  for (const spec of bridgeAntigravityExtensionSpecs(firstString(agent?.id))) {
    if (spec.match.test(extensionName)) {
      return {
        pathSource: 'antigravity_extension',
        pathSourceLabel: spec.label,
      };
    }
  }
  return {
    pathSource: 'antigravity_extension',
    pathSourceLabel: `Antigravity extension: ${extensionName}`,
  };
}

function emptyBridgeCommandSource() {
  return {
    pathSource: '',
    pathSourceLabel: '',
  };
}

function bridgeAntigravityExtensionSpecs(agentId) {
  if (agentId === 'codex') {
    return [
      {
        match: /^openai\.chatgpt-/i,
        dirSegments: [['bin', 'windows-x86_64']],
        label: 'Antigravity extension: OpenAI ChatGPT',
      },
    ];
  }
  if (agentId === 'claude') {
    return [
      {
        match: /^anthropic\.claude-code-/i,
        dirSegments: [['resources', 'native-binary']],
        label: 'Antigravity extension: Claude Code',
      },
    ];
  }
  if (agentId === 'kilo') {
    return [
      {
        match: /^kilocode\.kilo-code-/i,
        dirSegments: [['bin']],
        label: 'Antigravity extension: Kilo Code',
      },
    ];
  }
  return [];
}

function buildBridgeUnavailableAgentNotes(agent) {
  const extensionHint = bridgeUnavailableProviderExtensionHint(agent);
  if (extensionHint) return extensionHint;
  return 'CLI executable was not found on PATH or known provider extension paths.';
}

function bridgeUnavailableProviderExtensionHint(agent) {
  if (process.platform !== 'win32') return '';
  const agentId = firstString(agent?.id);
  if (agentId !== 'gemini') return '';
  const home = os.homedir();
  const root = path.join(home, '.antigravity', 'extensions');
  let extensions = [];
  try {
    extensions = requireFsSyncReaddir(root);
  } catch {
    return '';
  }
  const installedGoogleCompanions = extensions
    .filter((entry) => entry.isDirectory())
    .map((entry) => entry.name)
    .filter((name) => /^google\.(?:gemini-cli-vscode-ide-companion|geminicodeassist)-/i.test(name));
  if (installedGoogleCompanions.length === 0) return '';
  return 'Gemini Code Assist/Gemini CLI Companion extension was detected, but it does not include the standalone `gemini` executable Pixflow needs. Install the official Gemini CLI, then rescan CLIs.';
}

function bridgeVersionManagerBinPaths(root, maxDepth) {
  const out = [];
  function walk(dir, depth) {
    if (depth > maxDepth) return;
    let entries = [];
    try {
      entries = requireFsSyncReaddir(dir);
    } catch {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === 'bin') {
          out.push(full);
          continue;
        }
        walk(full, depth + 1);
      }
    }
  }
  walk(root, 0);
  return out;
}

function requireFsSyncReaddir(dir) {
  // Keep sync directory walking in one tiny helper so the daemon's broader
  // async file path style stays readable.
  return readdirSync(dir, { withFileTypes: true });
}

async function probeBridgeAgentAuthStatus(agent, commandPath) {
  if (!commandPath) {
    return {
      status: 'unknown',
      message: 'CLI executable was not found.',
      probe: '',
    };
  }

  const probe = agent.authProbe || null;
  if (!probe || !Array.isArray(probe.args)) {
    return {
      status: 'unknown',
      message: `${agent.label} is installed. Pixflow does not yet have a safe auth-status probe for this CLI; run the provider's login/status command if generation fails.`,
      probe: '',
    };
  }

  try {
    const result = await runBridgeCommandCapture(commandPath, probe.args, Number(probe.timeoutMs || 5000));
    const output = `${result.stdout || ''}\n${result.stderr || ''}`;
    const authFailure = classifyBridgeAgentAuthFailure(agent.id, output);
    if (authFailure) {
      return {
        status: 'missing',
        message: authFailure,
        probe: probe.label || probe.args.join(' '),
      };
    }

    if ((result.code || 0) === 0) {
      return {
        status: 'ok',
        message: `${agent.label} auth probe passed.`,
        probe: probe.label || probe.args.join(' '),
      };
    }

    return {
      status: 'unknown',
      message: `${agent.label} auth probe exited with code ${result.code}. ${summarizeBridgeProbeOutput(output)}`,
      probe: probe.label || probe.args.join(' '),
    };
  } catch (error) {
    return {
      status: 'unknown',
      message: `${agent.label} auth probe could not be completed: ${error instanceof Error ? error.message : String(error)}`,
      probe: probe.label || probe.args.join(' '),
    };
  }
}

function buildBridgeAgentNotes(agent, auth, command = {}) {
  const source = firstString(command.pathSourceLabel);
  const prefix = source ? `Found via ${source}. ` : 'Executable found. ';
  if (auth?.status === 'ok') {
    return `${prefix}Auth probe passed.`;
  }
  if (auth?.status === 'missing') {
    return `${prefix}${auth.message || 'Provider authentication is missing.'}`;
  }
  if (agent.supportStatus === 'stage_runner_ready') {
    return `${prefix}${auth?.message || 'Auth could not be verified without running the provider.'}`;
  }
  return `${prefix}This provider is available for install/detection; Stage A/B adapter support is pending.`;
}

function classifyBridgeAgentAuthFailure(agentId, text) {
  const value = firstString(text);
  if (!value.trim()) return '';
  if (agentId === 'cursor-agent' && /authentication required|not authenticated|not logged in|unauthenticated|cursor_api_key|agent login/i.test(value)) {
    return 'Cursor Agent is not authenticated. Run `cursor-agent login`, then `cursor-agent status`, and retry. For automation, ensure CURSOR_API_KEY is available to Pixflow Bridge.';
  }
  if (/unauthori[sz]ed|authentication required|not authenticated|not logged in|please (sign|log)[ -]?in|invalid[ _-]?(api[ _-]?)?key|incorrect api key|credentials? (missing|invalid|required)|oauth token .*expired|session expired|\blogin\b|status[ _-]?code\s*401|http\s*401/i.test(value)) {
    return `${agentLabelForId(agentId)} is installed but does not appear to be authenticated. Open its docs or run its login command, then rescan CLIs.`;
  }
  return '';
}

function summarizeBridgeProbeOutput(text) {
  const trimmed = firstString(text).replace(/\s+/g, ' ').trim();
  if (!trimmed) return 'No probe output was returned.';
  return trimmed.length > 220 ? `${trimmed.slice(0, 220)}...` : trimmed;
}

function agentLabelForId(agentId) {
  return BRIDGE_AGENT_CATALOG.find((agent) => agent.id === agentId)?.label || agentId;
}

async function probeBridgeAgentVersion(commandPath, versionArgs) {
  if (!commandPath) return '';
  try {
    const result = await runBridgeCommandCapture(commandPath, versionArgs, 2500);
    return firstString(result.stdout, result.stderr).split(/\r?\n/)[0]?.trim() || '';
  } catch {
    return '';
  }
}

function runBridgeCommandCapture(commandPath, args, timeoutMs) {
  return new Promise((resolve, reject) => {
    const child = spawn(commandPath, args, {
      cwd: process.cwd(),
      shell: process.platform === 'win32' && /\.(cmd|bat)$/i.test(commandPath),
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      reject(new Error('version_probe_timeout'));
    }, timeoutMs);
    timer.unref?.();
    child.stdout?.on('data', (chunk) => {
      stdout += chunk.toString('utf8');
    });
    child.stderr?.on('data', (chunk) => {
      stderr += chunk.toString('utf8');
    });
    child.once('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
    child.once('close', (code, signal) => {
      clearTimeout(timer);
      resolve({ stdout, stderr, code: code ?? 0, signal: signal || '' });
    });
  });
}

async function setBridgeDaemonActiveAgent(context, payload) {
  const agentId = normalizeBridgeAgentId(firstString(payload.agentId, payload.agent_id, payload.id));
  const agent = BRIDGE_AGENT_CATALOG.find((item) => item.id === agentId);
  if (!agent) {
    return {
      status: 'invalid',
      code: 'bridge_agent_unknown',
      message: 'Unknown CLI provider.',
      agentId,
    };
  }

  context.state.activeAgentId = agent.id;
  await saveBridgeDaemonState(context);
  return {
    status: 'ok',
    message: `${agent.label} is now the active Pixflow Bridge CLI provider.`,
    activeAgentId: agent.id,
    activeAgent: {
      id: agent.id,
      label: agent.label,
      description: agent.description,
    },
  };
}

function normalizeBridgeAgentId(value) {
  const id = firstString(value).toLowerCase().trim().replace(/_/g, '-');
  return BRIDGE_AGENT_CATALOG.some((agent) => agent.id === id) ? id : 'codex';
}

function sanitizeBridgeHttpsUrl(value) {
  const raw = firstString(value).trim();
  if (!raw) return '';
  try {
    const parsed = new URL(raw);
    return parsed.protocol === 'https:' ? parsed.toString() : '';
  } catch {
    return '';
  }
}

async function pairBridgeSite(context, payload) {
  const siteUrl = normalizeSiteUrl(firstString(payload.siteUrl, payload.site_url));
  if (!siteUrl) {
    return {
      status: 'invalid',
      code: 'bridge_pair_missing_site_url',
      message: 'Pairing requires siteUrl.',
    };
  }

  const bridgeId = firstString(payload.bridgeId, payload.bridge_id, stableBridgeId(`bridge:${siteUrl}:${os.hostname()}`));
  const pairPayload = {
    ...payload,
    bridgeId,
  };
  const completedPairing = await completeBridgePairingWithWordPress(context, pairPayload);
  if (completedPairing.status && completedPairing.status !== 'ok') {
    return completedPairing;
  }

  const siteId = firstString(payload.siteId, payload.site_id, stableBridgeId(`site:${siteUrl}`));
  const now = new Date().toISOString();
  const existing = context.state.sites.find((site) => firstString(site.siteId) === siteId || normalizeSiteUrl(site.siteUrl) === siteUrl);
  const bridgeToken = firstString(
    completedPairing.bridgeToken,
    completedPairing.token,
    payload.bridgeToken,
    payload.token,
    existing?.bridgeToken
  );
  const pairing = objectValue(completedPairing.pairing);
  const endpoints = objectValue(completedPairing.endpoints);
  const next = {
    siteId,
    siteUrl,
    siteName: firstString(payload.siteName, payload.site_name, siteUrl),
    restNamespace: firstString(payload.restNamespace, payload.rest_namespace, DEFAULT_REST_NAMESPACE),
    status: firstString(payload.status, bridgeToken) ? 'connected' : 'pending',
    bridgeToken,
    bridgeId: firstString(bridgeId, existing?.bridgeId),
    endpoints: Object.keys(endpoints).length > 0 ? endpoints : objectValue(existing?.endpoints),
    tokenMasked: maskSecret(bridgeToken),
    pairingChallengeId: firstString(payload.pairingChallengeId, payload.pairing_challenge_id, payload.challengeId, pairing.pairingId, existing?.pairingChallengeId),
    pairingId: firstString(pairing.pairingId, existing?.pairingId),
    pairingStatus: firstString(pairing.status, existing?.pairingStatus),
    tokenExpiresAt: firstString(pairing.tokenExpiresAt, existing?.tokenExpiresAt),
    createdAt: firstString(existing?.createdAt, now),
    updatedAt: now,
  };

  if (existing) {
    Object.assign(existing, next);
  } else {
    context.state.sites.push(next);
  }
  await saveBridgeDaemonState(context);

  return {
    status: 'ok',
    site: sanitizeBridgeSiteRecord(next),
  };
}

async function completeBridgePairingWithWordPress(context, payload) {
  const completeUrl = firstString(
    payload.pairingCompleteUrl,
    payload.pairing_complete_url,
    payload.completeUrl,
    payload.complete_url
  );
  const challengeId = firstString(
    payload.challengeId,
    payload.challenge_id,
    payload.pairingChallengeId,
    payload.pairing_challenge_id
  );
  const challengeSecret = firstString(payload.challengeSecret, payload.challenge_secret);

  if (!completeUrl && !challengeId && !challengeSecret) {
    return {};
  }

  if (!completeUrl || !challengeId || !challengeSecret) {
    return {
      status: 'invalid',
      code: 'bridge_pair_incomplete_challenge',
      message: 'Pairing completion requires completeUrl, challengeId, and challengeSecret.',
    };
  }

  let response;
  try {
    response = await fetch(completeUrl, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        challengeId,
        challengeSecret,
        bridgeId: firstString(payload.bridgeId, payload.bridge_id, stableBridgeId(`daemon:${context.host}:${context.port}`)),
        bridgeLabel: firstString(payload.bridgeLabel, payload.bridge_label, `${os.hostname()} Pixflow CLI bridge`),
        bridgeProtocolVersion: BRIDGE_DAEMON_PROTOCOL_VERSION,
        bridgeVersion: VERSION,
        daemonUrl: bridgeDaemonBaseUrl(context),
      }),
    });
  } catch (error) {
    return {
      status: 'error',
      code: 'bridge_pair_complete_request_failed',
      message: `Could not complete WordPress bridge pairing: ${error.message}`,
    };
  }

  const text = await response.text();
  let body = {};
  try {
    body = text.trim() ? JSON.parse(text) : {};
  } catch {
    return {
      status: 'error',
      code: 'bridge_pair_complete_invalid_response',
      message: 'WordPress bridge pairing returned invalid JSON.',
      httpStatus: response.status,
    };
  }

  if (!response.ok || firstString(body.status) !== 'ok') {
    return {
      status: firstString(body.status, 'error'),
      code: firstString(body.code, `http_${response.status}`),
      message: firstString(body.message, `WordPress bridge pairing returned HTTP ${response.status}.`),
      httpStatus: response.status,
    };
  }

  return body;
}

async function deleteBridgeSite(context, siteId) {
  const before = context.state.sites.length;
  context.state.sites = context.state.sites.filter((site) => firstString(site.siteId) !== siteId);
  const removed = context.state.sites.length !== before;
  if (removed) {
    await saveBridgeDaemonState(context);
  }
  return {
    status: removed ? 'ok' : 'not_found',
    removed,
    siteId,
  };
}

async function startBridgeDaemonRun(context, payload) {
  const command = firstString(payload.command, payload.kind);
  const allowedCommands = new Set([
    'status',
    'resources',
    'preflight',
    'prepare-stage-a',
    'run-stage-a',
    'repair-stage-a',
    'prepare-stage-b',
    'run-stage-b',
    'repair-stage-b',
    'import-stage-b',
    'insert-stage-b',
    'import-artifact',
    'stage-a-status',
  ]);
  if (!allowedCommands.has(command)) {
    throw new CliError(`Daemon run command "${command}" is not allowed.`);
  }

  let args = Array.isArray(payload.args)
    ? payload.args.map((arg) => String(arg)).filter((arg) => arg !== '')
    : [];
  if (args.some((arg) => arg === 'daemon')) {
    throw new CliError('Daemon runs cannot spawn nested daemon commands.');
  }
  args = normalizeBridgeDaemonRunArgs(context, command, args);

  const runId = firstString(payload.runId, payload.run_id, generateBridgeRunId());
  const runDir = path.join(context.runsDir, runId);
  await fs.mkdir(runDir, { recursive: true });
  await writeBridgeRunInputFiles(runDir, payload.files);
  const eventsFile = path.join(runDir, 'events.jsonl');
  const stderrFile = path.join(runDir, 'stderr.log');
  const stdoutFile = path.join(runDir, 'stdout.log');
  const now = new Date().toISOString();
  const run = {
    runId,
    status: 'running',
    command,
    args,
    siteId: firstString(payload.siteId, payload.site_id),
    label: firstString(payload.label, payload.title, command),
    createdAt: now,
    updatedAt: now,
    startedAt: now,
    completedAt: '',
    exitCode: null,
    signal: '',
    runDir,
    eventsFile,
    stdoutFile,
    stderrFile,
    eventCount: 0,
  };
  context.state.runs.unshift(run);
  context.state.runs = context.state.runs.slice(0, 100);
  await saveBridgeDaemonState(context);
  await appendBridgeRunEvent(context, run, 'run_started', {
    command,
    args,
    activeAgentId: normalizeBridgeAgentId(context.state.activeAgentId),
  });

  const cliFile = fileURLToPath(import.meta.url);
  const workingDirectory = firstString(payload.cwd, payload.workingDirectory, payload.working_directory) === 'runDir'
    ? runDir
    : process.cwd();
  const child = spawn(process.execPath, [cliFile, command, ...args], {
    cwd: workingDirectory,
    shell: false,
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  context.children.set(runId, child);

  const stdoutStream = createWriteStream(stdoutFile, { flags: 'a' });
  const stderrStream = createWriteStream(stderrFile, { flags: 'a' });

  child.stdout?.on('data', (chunk) => {
    stdoutStream.write(chunk);
    void appendBridgeRunEvent(context, run, 'stdout', {
      text: limitBridgeEventText(chunk.toString('utf8')),
    });
  });

  child.stderr?.on('data', (chunk) => {
    stderrStream.write(chunk);
    void appendBridgeRunEvent(context, run, 'stderr', {
      text: limitBridgeEventText(chunk.toString('utf8')),
    });
  });

  child.on('error', (error) => {
    run.status = 'failed';
    run.updatedAt = new Date().toISOString();
    run.completedAt = run.updatedAt;
    run.signal = '';
    context.children.delete(runId);
    stdoutStream.end();
    stderrStream.end();
    void appendBridgeRunEvent(context, run, 'run_error', {
      message: error.message,
    }).finally(() => saveBridgeDaemonState(context));
  });

  child.on('close', (code, signal) => {
    run.exitCode = code;
    run.signal = signal || '';
    if (run.status !== 'cancelled') {
      run.status = code === 0 ? 'completed' : 'failed';
    }
    run.updatedAt = new Date().toISOString();
    run.completedAt = run.updatedAt;
    context.children.delete(runId);
    stdoutStream.end();
    stderrStream.end();
    void appendBridgeRunEvent(context, run, 'run_finished', {
      status: run.status,
      exitCode: code,
      signal: signal || '',
    }).finally(() => saveBridgeDaemonState(context));
  });

  return run;
}

async function writeBridgeRunInputFiles(runDir, files) {
  if (!Array.isArray(files)) {
    return;
  }

  let totalBytes = 0;
  for (const file of files) {
    if (!file || typeof file !== 'object') {
      continue;
    }

    const relativePath = sanitizeBridgeRunInputFilePath(firstString(file.path, file.name));
    if (!relativePath) {
      throw new CliError('Bridge run input file path is invalid.');
    }

    const encoding = firstString(file.encoding).toLowerCase();
    const rawContent = firstString(file.content, file.contents, file.data);
    const contents = encoding === 'base64'
      ? Buffer.from(rawContent, 'base64')
      : Buffer.from(rawContent, 'utf8');
    totalBytes += contents.length;
    if (contents.length <= 0 || contents.length > 25 * 1024 * 1024 || totalBytes > 32 * 1024 * 1024) {
      throw new CliError('Bridge run input file payload is too large.');
    }

    const target = path.join(runDir, relativePath);
    const resolved = path.resolve(target);
    const base = path.resolve(runDir);
    if (resolved !== base && !resolved.startsWith(`${base}${path.sep}`)) {
      throw new CliError('Bridge run input file path escaped the run folder.');
    }

    await fs.mkdir(path.dirname(resolved), { recursive: true });
    await fs.writeFile(resolved, contents);
  }
}

function sanitizeBridgeRunInputFilePath(value) {
  const clean = firstString(value).replace(/\\/g, '/').replace(/\0/g, '').replace(/^\/+/, '');
  if (!clean || clean.includes('../') || clean === '..' || path.isAbsolute(clean)) {
    return '';
  }
  return clean
    .split('/')
    .filter(Boolean)
    .join(path.sep);
}

function normalizeBridgeDaemonRunArgs(context, command, args) {
  if (!bridgeDaemonCommandSupportsRunner(command) || bridgeArgsDeclareRunner(args)) {
    return args;
  }
  return [...args, '--runner', normalizeBridgeAgentId(context.state.activeAgentId)];
}

function bridgeDaemonCommandSupportsRunner(command) {
  return new Set([
    'run-stage-a',
    'repair-stage-a',
    'run-stage-b',
    'repair-stage-b',
  ]).has(command);
}

function bridgeArgsDeclareRunner(args) {
  const runnerFlags = [
    '--runner',
    '--agent',
    '--runner-command',
    '--runnerCommand',
    '--stage-b-runner',
    '--stageBRunner',
  ];
  return args.some((arg) => runnerFlags.some((flag) => arg === flag || arg.startsWith(`${flag}=`)));
}

async function cancelBridgeDaemonRun(context, runId) {
  const run = findBridgeRun(context, runId);
  if (!run) {
    return {
      status: 'not_found',
      code: 'bridge_run_not_found',
      runId,
    };
  }
  const child = context.children.get(runId);
  if (!child) {
    return {
      status: run.status,
      run: sanitizeBridgeRunRecord(run),
      message: 'Run is not currently active.',
    };
  }
  run.status = 'cancelled';
  run.updatedAt = new Date().toISOString();
  child.kill('SIGTERM');
  await appendBridgeRunEvent(context, run, 'run_cancel_requested', {});
  await saveBridgeDaemonState(context);
  return {
    status: 'cancelled',
    run: sanitizeBridgeRunRecord(run),
  };
}

async function handleBridgeRunEventsRequest(context, response, runId, requestUrl) {
  const run = findBridgeRun(context, runId);
  if (!run) {
    sendBridgeJson(response, 404, {
      status: 'not_found',
      code: 'bridge_run_not_found',
      runId,
    });
    return;
  }

  const stream = requestUrl.searchParams.get('stream') === '1'
    || requestUrl.searchParams.get('format') === 'sse';
  const events = await readBridgeRunEvents(run.eventsFile);
  if (!stream) {
    sendBridgeJson(response, 200, {
      status: 'ok',
      runId,
      events,
    });
    return;
  }

  response.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  for (const event of events) {
    response.write(`event: ${event.event || 'message'}\n`);
    response.write(`data: ${JSON.stringify(event)}\n\n`);
  }

  if (['completed', 'failed', 'cancelled'].includes(firstString(run.status))) {
    response.end();
    return;
  }

  const subscribers = context.eventSubscribers.get(runId) || new Set();
  subscribers.add(response);
  context.eventSubscribers.set(runId, subscribers);
  response.on('close', () => {
    subscribers.delete(response);
  });
}

async function appendBridgeRunEvent(context, run, event, data) {
  run.eventCount = Number(run.eventCount || 0) + 1;
  run.updatedAt = new Date().toISOString();
  const record = {
    sequence: run.eventCount,
    runId: run.runId,
    event,
    at: run.updatedAt,
    data: data || {},
  };
  await fs.appendFile(run.eventsFile, `${JSON.stringify(record)}\n`, 'utf8');
  const subscribers = context.eventSubscribers.get(run.runId);
  if (subscribers) {
    for (const subscriber of subscribers) {
      subscriber.write(`event: ${event}\n`);
      subscriber.write(`data: ${JSON.stringify(record)}\n\n`);
    }
    if (['run_finished', 'run_error'].includes(event)) {
      for (const subscriber of subscribers) {
        subscriber.end();
      }
      subscribers.clear();
    }
  }
}

async function readBridgeRunEvents(eventsFile) {
  const text = await readOptionalText(eventsFile);
  const events = [];
  for (const line of text.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const parsed = parseJsonText(trimmed);
    if (Object.keys(parsed).length > 0) {
      events.push(parsed);
    }
  }
  return events;
}

function findBridgeRun(context, runId) {
  return context.state.runs.find((run) => firstString(run.runId) === runId) || null;
}

function sanitizeBridgeRunRecord(run) {
  return {
    runId: firstString(run.runId),
    status: firstString(run.status),
    command: firstString(run.command),
    args: Array.isArray(run.args) ? run.args.map((arg) => String(arg)) : [],
    siteId: firstString(run.siteId),
    label: firstString(run.label),
    createdAt: firstString(run.createdAt),
    updatedAt: firstString(run.updatedAt),
    startedAt: firstString(run.startedAt),
    completedAt: firstString(run.completedAt),
    exitCode: run.exitCode,
    signal: firstString(run.signal),
    eventCount: Number(run.eventCount || 0),
    eventsFile: firstString(run.eventsFile),
    stdoutFile: firstString(run.stdoutFile),
    stderrFile: firstString(run.stderrFile),
  };
}

function sanitizeBridgeSiteRecord(site) {
  return {
    siteId: firstString(site.siteId),
    siteUrl: normalizeSiteUrl(site.siteUrl),
    siteName: firstString(site.siteName),
    restNamespace: firstString(site.restNamespace, DEFAULT_REST_NAMESPACE),
    status: firstString(site.status),
    bridgeId: firstString(site.bridgeId),
    tokenMasked: firstString(site.tokenMasked, maskSecret(site.bridgeToken)),
    pairingChallengeId: firstString(site.pairingChallengeId),
    pairingId: firstString(site.pairingId),
    pairingStatus: firstString(site.pairingStatus),
    tokenExpiresAt: firstString(site.tokenExpiresAt),
    createdAt: firstString(site.createdAt),
    updatedAt: firstString(site.updatedAt),
  };
}

async function readBridgeJsonRequest(request) {
  const chunks = [];
  for await (const chunk of request) {
    chunks.push(Buffer.from(chunk));
  }
  const raw = Buffer.concat(chunks).toString('utf8').trim();
  if (!raw) {
    return {};
  }
  const parsed = parseJsonText(raw);
  if (Object.keys(parsed).length === 0 && raw !== '{}') {
    throw new CliError('Request body must be valid JSON.');
  }
  return parsed;
}

function sendBridgeJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(`${JSON.stringify(payload || {}, null, 2)}\n`);
}

function applyBridgeCorsHeaders(context, request, response, pathname) {
  const origin = firstString(request.headers.origin);
  if (!origin) {
    return;
  }
  const allowed = pathname === '/v1/status'
    || pathname === '/v1/agents'
    || pathname === '/v1/agents/active'
    || pathname === '/v1/sites/pair'
    || pathname === '/v1/runs'
    || /^\/v1\/runs\/[^/]+(?:\/events|\/cancel)?$/.test(pathname)
    || isPairedBridgeOrigin(context, origin)
    || isLoopbackOrigin(origin);
  if (!allowed) {
    return;
  }
  response.setHeader('Access-Control-Allow-Origin', origin);
  response.setHeader('Vary', 'Origin');
  response.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Pixflow-Bridge-Intent');
  response.setHeader('Access-Control-Allow-Private-Network', 'true');
}

function isPairedBridgeOrigin(context, origin) {
  let normalizedOrigin = '';
  try {
    const parsed = new URL(origin);
    normalizedOrigin = `${parsed.protocol}//${parsed.host}`;
  } catch {
    return false;
  }
  return context.state.sites.some((site) => {
    try {
      const parsed = new URL(normalizeSiteUrl(site.siteUrl));
      return `${parsed.protocol}//${parsed.host}` === normalizedOrigin;
    } catch {
      return false;
    }
  });
}

function isLoopbackOrigin(origin) {
  try {
    const parsed = new URL(origin);
    return isLoopbackHost(parsed.hostname);
  } catch {
    return false;
  }
}

function isLoopbackHost(host) {
  const normalized = firstString(host).toLowerCase().replace(/^\[|\]$/g, '');
  return normalized === '127.0.0.1' || normalized === 'localhost' || normalized === '::1';
}

function resolveBridgeDaemonDataDir(flags) {
  const explicit = firstString(flags.dataDir, process.env.PIXFLOW_BRIDGE_DATA_DIR);
  if (explicit) {
    return path.resolve(process.cwd(), explicit);
  }

  if (process.platform === 'win32') {
    return path.join(firstString(process.env.LOCALAPPDATA, process.env.APPDATA, os.homedir()), 'Pixflow Bridge');
  }
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'Pixflow Bridge');
  }
  return path.join(firstString(process.env.XDG_DATA_HOME, path.join(os.homedir(), '.local', 'share')), 'pixflow-bridge');
}

function bridgeDaemonBaseUrl(flags) {
  const explicit = firstString(flags.daemonUrl, process.env.PIXFLOW_BRIDGE_DAEMON_URL);
  if (explicit) {
    return explicit.replace(/\/+$/, '');
  }
  const host = firstString(flags.host, process.env.PIXFLOW_BRIDGE_HOST, DEFAULT_BRIDGE_DAEMON_HOST);
  const port = parsePositiveIntegerFlag(
    firstString(flags.port, process.env.PIXFLOW_BRIDGE_PORT),
    DEFAULT_BRIDGE_DAEMON_PORT
  );
  return `http://${host}:${port}`;
}

async function fetchBridgeDaemonJson(flags, route, init = {}) {
  const url = `${bridgeDaemonBaseUrl(flags)}${route}`;
  let response;
  try {
    response = await fetch(url, {
      method: init.method || 'GET',
      headers: {
        Accept: 'application/json',
        ...(init.body ? { 'Content-Type': 'application/json' } : {}),
      },
      body: init.body ? JSON.stringify(init.body) : undefined,
    });
  } catch (error) {
    throw new CliError(`Cannot reach Pixflow Bridge daemon at ${url}: ${error?.message || error}`);
  }
  const text = await response.text();
  const body = parseJsonBody(text, url);
  if (!response.ok) {
    throw new CliError(`Pixflow Bridge daemon request failed (${response.status})`, {
      url,
      status: response.status,
      body,
    });
  }
  return body;
}

function renderBridgeDaemonStatusSummary(result) {
  const lines = [];
  lines.push(`Pixflow Bridge daemon: ${result.status || 'unknown'}`);
  lines.push(`URL: ${safe(result.url)}`);
  lines.push(`Version: ${safe(result.bridgeVersion)} / protocol ${safe(result.protocolVersion)}`);
  lines.push(`PID: ${firstString(result.pid, '-')} / Node ${safe(result.nodeVersion)}`);
  lines.push(`Sites: ${Number(result.sites?.connected || 0)} connected, ${Number(result.sites?.count || 0)} total`);
  lines.push(`Runs: ${Number(result.runs?.running || 0)} running, ${Number(result.runs?.count || 0)} total`);
  lines.push(`Data: ${safe(result.dataDir)}`);
  return lines.join('\n');
}

function generateBridgeRunId() {
  return `pfbridge-run-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}

function stableBridgeId(seed) {
  return createHash('sha256').update(String(seed || '')).digest('hex').slice(0, 16);
}

function maskSecret(value) {
  const text = firstString(value);
  if (!text) {
    return '';
  }
  if (text.length <= 8) {
    return `${text.slice(0, 2)}...${text.slice(-2)}`;
  }
  return `${text.slice(0, 4)}...${text.slice(-4)}`;
}

function limitBridgeEventText(text) {
  const value = String(text || '');
  return value.length > 8000 ? `${value.slice(0, 8000)}\n[truncated]` : value;
}

async function loadConfig(flags) {
  const configPath = typeof flags.config === 'string' ? flags.config : '';
  const fileConfig = configPath ? await readJsonConfig(configPath) : {};

  const config = {
    ...fileConfig,
    siteUrl: firstString(flags.site, flags.siteUrl, process.env.PIXFLOW_SITE_URL, fileConfig.siteUrl),
    token: firstString(flags.token, process.env.PIXFLOW_CLI_TOKEN, process.env.PIXFLOW_EDITOR_TOKEN, fileConfig.token),
    wpCookie: firstString(flags.wpCookie, flags.cookie, process.env.PIXFLOW_WP_COOKIE, fileConfig.wpCookie, fileConfig.cookie),
    restNamespace: firstString(flags.restNamespace, process.env.PIXFLOW_REST_NAMESPACE, fileConfig.restNamespace, DEFAULT_REST_NAMESPACE),
    stage: firstString(flags.stage, process.env.PIXFLOW_STAGE, fileConfig.stage, DEFAULT_STAGE),
  };

  config.siteUrl = normalizeSiteUrl(config.siteUrl);
  config.restNamespace = normalizeRestNamespace(config.restNamespace);

  const missing = [];
  if (!config.siteUrl) {
    missing.push('siteUrl');
  }
  if (!config.token) {
    missing.push('token');
  }
  if (missing.length > 0) {
    throw new CliError(
      `Missing required config: ${missing.join(', ')}. Use --site, --token, --config, PIXFLOW_SITE_URL, or PIXFLOW_CLI_TOKEN.`
    );
  }

  return config;
}

async function readJsonConfig(configPath) {
  const absolutePath = path.resolve(process.cwd(), configPath);
  let raw = '';
  try {
    raw = stripBom(await fs.readFile(absolutePath, 'utf8'));
  } catch (error) {
    throw new CliError(`Could not read config file: ${absolutePath}`);
  }

  try {
    return JSON.parse(raw);
  } catch (error) {
    throw new CliError(`Config file is not valid JSON: ${absolutePath}`);
  }
}

function createPixflowClient(config) {
  const baseUrl = `${config.siteUrl}/wp-json/${config.restNamespace}`;

  return {
    async post(route, payload) {
      const url = `${baseUrl}${route}`;
      const headers = {
        Accept: 'application/json',
        Authorization: `Bearer ${config.token}`,
        'Content-Type': 'application/json',
      };

      if (typeof config.wpCookie === 'string' && config.wpCookie.trim()) {
        headers.Cookie = config.wpCookie.trim();
      }

      const response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload || {}),
      });

      const text = await response.text();
      const body = parseJsonBody(text, url);
      if (!response.ok) {
        throw new CliError(`Pixflow bridge request failed (${response.status})`, {
          url,
          status: response.status,
          body,
        });
      }

      return body;
    },
  };
}

function parseJsonBody(text, url) {
  if (!text) {
    return {};
  }

  try {
    return JSON.parse(text);
  } catch (error) {
    throw new CliError(`Pixflow bridge did not return JSON: ${url}`);
  }
}

function outputResult(result, flags, renderer) {
  if (flags.json) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    return;
  }

  process.stdout.write(`${renderer(result)}\n`);
}

function renderStatusSummary(result) {
  const lines = [];
  lines.push(`Pixflow CLI Bridge Status: ${result.status || 'unknown'}`);
  lines.push(`Site: ${safe(result.site?.name)} (${safe(result.site?.homeUrl)})`);
  lines.push(`Pixflow: ${safe(result.runtime?.pluginVersion)} / bridge ${safe(result.runtime?.bridgeContractVersion)}`);
  lines.push(`License: ${result.license?.present ? 'present' : 'missing'} ${safe(result.license?.licenseKeyMasked)}`.trim());
  lines.push(`Bricks: ${result.bricks?.active ? 'active' : 'inactive'} ${safe(result.bricks?.version)}`.trim());
  if (result.style?.available) {
    lines.push(`Style route: ${safe(result.style?.activeRouteId)} (${safe(result.style?.mode)})`);
    lines.push(`Theme styles: ${Number(Object.keys(objectValue(result.style?.themeStyles)).length)} total, ${Number((result.style?.themeStyleActiveIds || []).length)} active`);
  }
  lines.push(`Resources: ${result.resources?.ready ? 'ready' : 'blocked'} (${Number(result.resources?.installedPackCount || 0)} installed)`);
  return lines.join('\n');
}

function renderResourcesSummary(result) {
  const packs = result.resourcePacks || {};
  const lines = [];
  lines.push(`Pixflow Resources: ${result.status || 'unknown'} (${result.stage || DEFAULT_STAGE})`);
  lines.push(`Ready: ${result.ready ? 'yes' : 'no'}`);
  lines.push(`Required packs: ${Number(packs.required_pack_count || packs.requiredPackCount || 0)}`);
  lines.push(`Installed packs: ${Number(packs.installed_pack_count || packs.installedPackCount || 0)}`);
  lines.push(`Missing required: ${Number(packs.missing_required_pack_count || packs.missingRequiredPackCount || 0)}`);
  lines.push(`Invalid required: ${Number(packs.invalid_required_pack_count || packs.invalidRequiredPackCount || 0)}`);
  return lines.join('\n');
}

function renderPreflightSummary(result) {
  const lines = [];
  lines.push(renderStatusSummary(result.status));
  lines.push('');
  lines.push(renderResourcesSummary(result.resources));
  return lines.join('\n');
}

function renderImportSummary(result) {
  const imported = result.import || {};
  const run = imported.run || {};
  const qa = imported.qa || {};
  const lines = [];
  lines.push(`CLI Stage A Import: ${result.status || imported.status || 'unknown'}`);
  lines.push(`Run: ${safe(imported.runId || run.runId)}`);
  lines.push(`Accepted: ${imported.accepted ? 'yes' : 'no'}`);
  lines.push(`Bricks conversion ready: ${imported.bricksConversionReady ? 'yes' : 'no'}`);
  lines.push(`QA: ${safe(qa.status)}${typeof qa.score === 'number' ? ` (${qa.score})` : ''}`);
  return lines.join('\n');
}

function renderStageBImportSummary(result) {
  const run = result.run || {};
  const summary = result.summary || {};
  const lines = [];
  lines.push(`CLI Stage B Import: ${result.status || 'unknown'}`);
  lines.push(`Run: ${safe(result.runId || run.runId)}`);
  lines.push(`Run status: ${safe(run.status)}`);
  lines.push(`Elements: ${Number(summary.elementCount || run.elementCount || 0)}`);
  lines.push(`Global classes: ${Number(summary.globalClassCount || run.classCount || 0)}`);
  lines.push(`Sections: ${Number(summary.sectionCount || run.sectionCount || 0)}`);
  return lines.join('\n');
}

function renderStageBInsertSummary(result) {
  const insert = result.insert || {};
  const lines = [];
  lines.push(`CLI Stage B Insert: ${result.status || 'unknown'}`);
  lines.push(`Run: ${safe(result.runId)}`);
  lines.push(`Page: ${safe(insert.pageTitle)} (${safe(String(insert.postId || insert.targetWpPostId || ''))})`);
  lines.push(`Created: ${insert.created ? 'yes' : 'no'}`);
  lines.push(`Inserted sections: ${Number(insert.insertedCount || 0)}`);
  lines.push(`Elements: ${Number(insert.elementCount || 0)}`);
  if (insert.header) {
    lines.push(`Header template: ${safe(insert.header.templateTitle)} (${safe(String(insert.header.templateId || ''))}, ${safe(insert.header.scope)})`);
  }
  if (insert.footer) {
    lines.push(`Footer template: ${safe(insert.footer.templateTitle)} (${safe(String(insert.footer.templateId || ''))}, ${safe(insert.footer.scope)})`);
  }
  if (insert.editUrl) {
    lines.push(`Bricks edit URL: ${insert.editUrl}`);
  }
  if (insert.viewUrl) {
    lines.push(`View URL: ${insert.viewUrl}`);
  }
  return lines.join('\n');
}

function renderStageAStatusSummary(result) {
  const run = result.run || {};
  const lines = [];
  lines.push(`CLI Stage A Status: ${result.status || 'unknown'}`);
  lines.push(`Run: ${safe(run.runId)}`);
  lines.push(`Run status: ${safe(run.status)}`);
  lines.push(`Stage A progress: ${safe(run.stageAArtifactProgressStatus)}`);
  lines.push(`Stage A QA: ${safe(run.stageAArtifactQaStatus)}${typeof run.stageAArtifactQaScore === 'number' ? ` (${run.stageAArtifactQaScore})` : ''}`);
  lines.push(`Bricks conversion ready: ${run.bricksConversionReady ? 'yes' : 'no'}`);
  return lines.join('\n');
}

function renderPrepareStageASummary(result) {
  const lines = [];
  lines.push(`Stage A workspace prepared: ${result.workspaceDir}`);
  lines.push(`Source: ${safe(result.sourceId)}`);
  lines.push(`Prompt: ${result.promptFile}`);
  lines.push(`Instructions: ${result.instructionsFile}`);
  lines.push(`TODO: ${result.todoFile}`);
  lines.push(`Runner prompt: ${result.runnerPromptFile}`);
  lines.push(`Local QA report: ${result.qaFile}`);
  lines.push('');
  lines.push('Run locally:');
  lines.push(result.suggestedRunCommand);
  lines.push('');
  lines.push('Import after drafts/index.html exists:');
  lines.push(result.importCommand);
  return lines.join('\n');
}

function renderRunStageASummary(result) {
  const lines = [];
  lines.push(`Stage A local run: ${result.status || 'unknown'}`);
  lines.push(`Workspace: ${result.workspaceDir}`);
  lines.push(`Artifact: ${result.artifactFile}`);
  lines.push(`Runner exit code: ${result.runnerExitCode ?? '-'}`);
  if (result.runnerEventsFile) {
    lines.push(`Runner events: ${result.runnerEventsFile}`);
  }
  if (result.stageAQa) {
    lines.push(`Local Stage A QA: ${safe(result.stageAQa.status)} (${Number(result.stageAQa.score || 0)})`);
    lines.push(`Local Stage A QA report: ${result.qaFile}`);
  }
  if (result.stageAToolTraceFile) {
    lines.push(`Stage A tool trace: ${result.stageAToolTraceFile}`);
  }
  if (result.imported) {
    lines.push('');
    lines.push(renderImportSummary(result.imported));
  } else {
    lines.push('');
    lines.push('Import command:');
    lines.push(result.importCommand);
  }
  return lines.join('\n');
}

function renderPrepareStageBSummary(result) {
  const lines = [];
  lines.push(`Stage B workspace prepared: ${result.workspaceDir}`);
  lines.push(`Source: ${safe(result.sourceId)}`);
  lines.push(`Stage A artifact: ${result.stageAArtifact}`);
  lines.push(`Instructions: ${result.instructionsFile}`);
  lines.push(`TODO: ${result.todoFile}`);
  lines.push(`Runner prompt: ${result.runnerPromptFile}`);
  lines.push(`Route contract: ${result.routeContractFile}`);
  lines.push(`Theme style contract: ${result.themeStyleContractFile}`);
  lines.push(`Theme style health: ${result.themeStyleHealthFile}`);
  lines.push(`Bricks MCP: ${result.bricksMcpFile}`);
  lines.push(`Plugin MCP: ${result.pluginMcpFile}`);
  lines.push(`Bricks skills: ${result.skills?.active ? `${result.skills.fileCount} files` : 'missing'}`);
  lines.push(`Stage A media: ${Number(result.stageAMedia?.fileCount || 0)} files`);
  lines.push(`Local QA report: ${result.qaFile}`);
  lines.push('');
  lines.push('Run locally:');
  lines.push(result.suggestedRunCommand);
  return lines.join('\n');
}

function renderRunStageBSummary(result) {
  const lines = [];
  lines.push(`Stage B local run: ${result.status || 'unknown'}`);
  lines.push(`Workspace: ${result.workspaceDir}`);
  lines.push(`Result: ${result.resultFile}`);
  lines.push(`Payload: ${result.payloadFile}`);
  lines.push(`Global classes: ${result.globalClassesFile}`);
  lines.push(`Runner exit code: ${result.runnerExitCode ?? '-'}`);
  if (result.runnerEventsFile) {
    lines.push(`Runner events: ${result.runnerEventsFile}`);
  }
  if (result.stageBQa) {
    lines.push(`Local Stage B QA: ${safe(result.stageBQa.status)} (${Number(result.stageBQa.score || 0)})`);
    lines.push(`Local Stage B QA report: ${result.qaFile}`);
    lines.push(`Elements: ${Number(result.stageBQa.summary?.elementCount || 0)}`);
    lines.push(`Header elements: ${Number(result.stageBQa.summary?.headerElementCount || 0)}`);
    lines.push(`Footer elements: ${Number(result.stageBQa.summary?.footerElementCount || 0)}`);
    lines.push(`Global classes: ${Number(result.stageBQa.summary?.globalClassCount || 0)}`);
    lines.push(`Top-level sections: ${Number(result.stageBQa.summary?.topLevelSectionCount || 0)}`);
    lines.push(`Route: ${safe(result.stageBQa.summary?.routeId)} / ${safe(result.stageBQa.summary?.styleMode)}`);
    lines.push(`Theme style: ${safe(result.stageBQa.summary?.themeStyleMode)} (${safe(result.stageBQa.summary?.themeStyleHealthStatus)})`);
  }
  if (Array.isArray(result.repairAttempts) && result.repairAttempts.length > 0) {
    lines.push(`Repair attempts: ${result.repairAttempts.length}`);
    for (const attempt of result.repairAttempts) {
      lines.push(`- #${attempt.attempt}: ${safe(attempt.qaBefore?.status)} -> ${safe(attempt.qaAfter?.status)} (${Number(attempt.qaAfter?.score || 0)})`);
    }
  }
  if (result.imported) {
    lines.push('');
    lines.push(renderStageBImportSummary(result.imported));
  }
  if (result.inserted) {
    lines.push('');
    lines.push(renderStageBInsertSummary(result.inserted));
  }
  return lines.join('\n');
}

function printHelp() {
  process.stdout.write(`Pixflow Design CLI Bridge Runner ${VERSION}

Usage:
  node tools/pixflow-design-cli/pixflow-design-cli.mjs <command> [options]

Commands:
  daemon      Start, inspect, or stop the local Pixflow Bridge daemon.
  status      Check site, Pixflow, Bricks, license, and resource readiness.
  resources   Check required Pixflow Design resource packs.
  preflight   Run status and resources checks together.
  prepare-stage-a
              Prepare a local Pixflow Design-style Stage A workspace from a handoff JSON file.
  run-stage-a
              Prepare a workspace, launch the local Stage A model CLI, and optionally import.
  repair-stage-a
              Rerun focused local CLI repair passes against an existing Stage A workspace.
  prepare-stage-b
              Prepare a local Bricks conversion workspace from an accepted Stage A workspace.
  run-stage-b
              Prepare a Stage B workspace, launch the local Bricks conversion model CLI, and optionally import/insert.
  repair-stage-b
              Rerun focused local CLI repair passes against an existing Stage B workspace.
  import-stage-b
              Import a completed CLI Stage B Bricks result into a Direct Generation run.
  insert-stage-b
              Insert an imported CLI Stage B Bricks result into a Bricks page.
  import-artifact
              Import a completed CLI/Pixflow Design Stage A HTML artifact.
  stage-a-status
              Check imported Stage A run status.
  help        Show this help.

Options:
  --config, -c <path>       JSON config file.
  --site <url>              WordPress site URL.
  --token <token>           Pixflow runtime/editor bearer token.
  --restNamespace <value>   REST namespace. Default: pixflow-ai/v1.
  --stage <stage>           Resource stage. Default: stage_a.
  --handoff <path>          Stage A handoff JSON from Pixflow settings.
  --stage-a-workspace <path>
                            Accepted Stage A workspace for Stage B conversion.
  --workspace <path>        Parent folder for prepare-stage-a workspaces.
  --project-id <id>         Optional stable workspace/source id.
  --force                   Overwrite known files in an existing workspace.
  --runner <name>           Local runner preset for run-stage-a/run-stage-b. Bridge runs default to the active provider; direct CLI runs default to codex.
                            Runner-ready presets: codex, claude, gemini, opencode, cursor-agent, qwen.
  --runner-command <cmd>    Custom local runner command. Supports {workspace}, {prompt}, {artifact}, {result}.
  --model <model>           Optional model for the Codex runner preset.
  --reasoning <effort>      Optional Codex reasoning effort.
  --repair-attempts <n>     Post-QA CLI repair passes before failing. Default: Stage A ${DEFAULT_STAGE_A_REPAIR_ATTEMPTS}, Stage B ${DEFAULT_STAGE_B_REPAIR_ATTEMPTS}.
  --stage-b-min-score <n>   Minimum local Stage B QA score for import/insert. Default: ${DEFAULT_STAGE_B_MIN_QA_SCORE}.
  --stage-b-allow-p1        Allow P1 Stage B issues through the local score gate. Default: off.
  --allow-low-stage-b-qa    Bypass Stage B score/P1 gate for local inspection only; P0 issues still fail.
  --import                  Import artifact/result after run-stage-a or run-stage-b succeeds.
  --insert                  After run-stage-b import, create/update a Bricks page.
  --result-file <path>      Stage B bricks-result.json for import-stage-b or insert-stage-b.
  --qa-file <path>          Stage B QA JSON for import-stage-b.
  --conversion-report-file <path>
                            Stage B conversion report markdown for import-stage-b.
  --include-header <yes|no> Stage B header choice when Stage A has a header landmark.
  --header-scope <scope>    Header template scope: current-page or sitewide. Default: current-page.
  --header-template-title <title>
                            Optional Bricks header template title.
  --include-footer <yes|no> Stage B footer choice when Stage A has a footer landmark.
  --footer-scope <scope>    Footer template scope: current-page or sitewide. Default: current-page.
  --footer-template-title <title>
                            Optional Bricks footer template title.
  --page-title <title>      Target page title for Stage B insert.
  --target-post-id <id>     Existing Bricks page to replace/append during Stage B insert.
  --replace-existing <bool> Replace existing target page content. Default: true.
  --post-status <status>    New page status. Default: publish.
  --host <host>             Daemon loopback host. Default: ${DEFAULT_BRIDGE_DAEMON_HOST}.
  --port <port>             Daemon port. Default: ${DEFAULT_BRIDGE_DAEMON_PORT}.
  --daemon-url <url>        Existing daemon URL for daemon status/stop.
  --data-dir <path>         Local bridge state folder for daemon mode.
  --html <path>             Stage A HTML artifact for import-artifact.
  --prompt <text>           Prompt to store with imported artifact.
  --prompt-file <path>      Prompt file to store with imported artifact.
  --metadata <json>         JSON metadata for imported artifact.
  --metadata-file <path>    JSON metadata file for imported artifact.
  --source-id <id>          Prototype/project/source id for imported artifact.
  --fidelity <value>        high_fidelity or wireframe.
  --run-id <id>             Run id for stage-a-status, Stage B import, or Stage B insert.
  --json                    Print raw JSON.
  --help, -h                Show help.

Environment:
  PIXFLOW_SITE_URL
  PIXFLOW_CLI_TOKEN
  PIXFLOW_EDITOR_TOKEN
  PIXFLOW_REST_NAMESPACE
  PIXFLOW_STAGE
`);
}

function printError(message) {
  process.stderr.write(`Error: ${message}\n`);
}

function firstString(...values) {
  for (const value of values) {
    if (typeof value === 'string' && value.trim() !== '') {
      return value.trim();
    }
    if (typeof value === 'number' && Number.isFinite(value)) {
      return String(value);
    }
  }
  return '';
}

function objectValue(value) {
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}

function isPlainObject(value) {
  return value && typeof value === 'object' && !Array.isArray(value);
}

function firstPlainObject(...values) {
  for (const value of values) {
    if (isPlainObject(value) && Object.keys(value).length > 0) {
      return value;
    }
  }
  return {};
}

function normalizeKey(value) {
  const raw = firstString(value)
    .replace(/\\/g, '/')
    .replace(/^plugin:/i, '')
    .replace(/^od:/i, '');
  const basename = raw.includes('/') ? raw.split('/').filter(Boolean).pop() : raw;
  return firstString(basename)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function stringArrayFromUnknown(value) {
  return Array.isArray(value) ? value.map((item) => firstString(item)).filter(Boolean) : [];
}

function normalizeWorkspaceRelativePath(value) {
  const raw = firstString(value).replace(/\\/g, '/');
  if (!raw || /^[a-z]+:\/\//i.test(raw) || path.isAbsolute(raw)) {
    return '';
  }

  const parts = [];
  for (const part of raw.split('/')) {
    if (!part || part === '.') {
      continue;
    }
    if (part === '..') {
      parts.pop();
      continue;
    }
    parts.push(part);
  }

  return parts.join('/');
}

function normalizeSiteUrl(siteUrl) {
  const normalized = firstString(siteUrl).replace(/\/+$/, '');
  if (!normalized) {
    return '';
  }
  if (!/^https?:\/\//i.test(normalized)) {
    return `https://${normalized}`;
  }
  return normalized;
}

function normalizeRestNamespace(namespace) {
  return firstString(namespace, DEFAULT_REST_NAMESPACE).replace(/^\/+|\/+$/g, '');
}

function slugify(value) {
  const slug = firstString(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return slug || 'pixflow-stage-a-run';
}

function quoteForShell(value) {
  const text = String(value || '');
  if (text === '') {
    return '""';
  }
  if (/^[A-Za-z0-9_./:=-]+$/.test(text)) {
    return text;
  }
  return `"${text.replace(/(["$`])/g, '\\$1')}"`;
}

function safe(value) {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : '-';
}

function stripBom(value) {
  return typeof value === 'string' ? value.replace(/^\uFEFF/, '') : value;
}

class CliError extends Error {
  constructor(message, details = null) {
    super(message);
    this.name = 'CliError';
    this.details = details;
  }
}

main().catch((error) => {
  if (error instanceof CliError) {
    printError(error.message);
    if (error.details) {
      process.stderr.write(`${JSON.stringify(error.details, null, 2)}\n`);
    }
    process.exitCode = 1;
    return;
  }

  printError(error?.message || String(error));
  process.exitCode = 1;
});
