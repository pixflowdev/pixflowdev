# Pixflow Design CLI Bridge Runner

This is the local runner scaffold for the Pixflow Design CLI bridge.

Its current job is to connect to a WordPress Pixflow site, verify readiness,
prepare a local Pixflow Design-style Stage A workspace from a Pixflow handoff JSON
file, and import the completed Stage A HTML artifact back into Pixflow.

- Pixflow plugin/runtime status
- masked license state
- Bricks availability
- required Pixflow Design resource packs

The existing WordPress/API Stage A runtime remains unchanged.

## Usage

Create a local config file from the example:

```bash
cp tools/pixflow-design-cli/pixflow-design-cli.config.example.json pixflow-design-cli.config.json
```

Set the site URL and an editor/runtime bearer token. For local WordPress
runtime routes, include the matching logged-in WordPress cookie from the same
builder session because the bearer token is session-bound:

```json
{
  "siteUrl": "https://example.com",
  "token": "paste-runtime-editor-token-here",
  "wpCookie": "wordpress_logged_in_...=..."
}
```

Then run:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs status --config pixflow-design-cli.config.json
node tools/pixflow-design-cli/pixflow-design-cli.mjs resources --config pixflow-design-cli.config.json
node tools/pixflow-design-cli/pixflow-design-cli.mjs preflight --config pixflow-design-cli.config.json
```

Environment variables are also supported:

```bash
PIXFLOW_SITE_URL=https://example.com PIXFLOW_CLI_TOKEN=... PIXFLOW_WP_COOKIE=... node tools/pixflow-design-cli/pixflow-design-cli.mjs status
```

Use JSON output for automation:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs status --json
```

## Local Bridge Daemon

The user-facing Pixflow Bridge runtime starts as a local, loopback-only daemon.
It wraps the existing CLI commands, persists local run state, streams run
events, and gives the Pixflow Design UI a stable local API to connect to.

Install or update the local bridge:

```powershell
powershell -ExecutionPolicy Bypass -File tools\pixflow-bridge-installer\install-bridge.ps1 -Start
```

On macOS/Linux:

```bash
sh tools/pixflow-bridge-installer/install-bridge.sh --start
```

Start the daemon:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs daemon start
```

Inspect it:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs daemon status --json
```

Stop it:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs daemon stop
```

Useful daemon flags:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs daemon start \
  --host 127.0.0.1 \
  --port 47873 \
  --data-dir ./build/.tmp/pixflow-bridge-dev
```

Initial local API:

- `GET /v1/status`
- `GET /v1/agents`
- `GET /v1/sites`
- `POST /v1/sites/pair`
- `DELETE /v1/sites/:id`
- `POST /v1/runs`
- `GET /v1/runs`
- `GET /v1/runs/:id`
- `GET /v1/runs/:id/events`
- `GET /v1/runs/:id/events?stream=1`
- `POST /v1/runs/:id/cancel`
- `POST /v1/shutdown`

Run creation accepts only known Pixflow CLI commands and an argument array. It
does not expose an arbitrary shell execution endpoint.

Pairing:

- Open Pixflow Design settings in WordPress.
- Choose Local CLI, then use Detect daemon and Connect bridge.
- WordPress creates a short-lived pairing challenge and the local daemon
  exchanges it for a scoped `pfbridge_*` token.
- The token is stored only in the local daemon state; WordPress stores its hash.
- Use Disconnect in Pixflow Design settings before handing a site to a client.

Prepare a local Stage A workspace from the handoff JSON copied in Pixflow
Design settings:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs prepare-stage-a \
  --handoff ./pixflow-stage-a-handoff.json \
  --workspace ./pixflow-stage-a-runs
```

The prepared workspace contains:

- `prompt.md`
- `brief.md`
- `context.json`
- `AGENTS.md`
- `TODO.md`
- `metadata.json`
- `drafts/index.html` target path

Run the local model CLI inside that workspace and create `drafts/index.html`.
The generated `README.md` in the workspace includes the suggested run command
and import command.

Run the local Stage A command directly with the default Codex CLI preset:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs run-stage-a \
  --handoff ./pixflow-stage-a-handoff.json \
  --workspace ./pixflow-stage-a-runs \
  --force
```

Run the Pixflow Library page-generation variant for sitemap pages that use
Pixflow Library sections as required guidance:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs run-library-page \
  --handoff ./pixflow-stage-a-handoff.json \
  --workspace ./pixflow-stage-a-runs \
  --library-page \
  --force
```

This route still uses the normal Pixflow import boundary, but the model
workspace is Library-specific: it must produce `library-page-plan.json`,
`section-flow-critique.md`, and a preview artifact while preserving the sitemap
section plan.

Use a custom local runner command if you want to launch another model CLI:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs run-stage-a \
  --handoff ./pixflow-stage-a-handoff.json \
  --runner-command "my-agent --cwd {workspace} --prompt {prompt}"
```

Add `--import --config pixflow-design-cli.config.json` to import the artifact
after the local runner exits successfully.

Import a completed Stage A artifact without Bricks conversion:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs import-artifact \
  --config pixflow-design-cli.config.json \
  --html ./pixflow-design-run/index.html \
  --prompt-file ./pixflow-design-run/prompt.md \
  --metadata-file ./pixflow-design-run/metadata.json
```

Check the imported run:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs stage-a-status \
  --config pixflow-design-cli.config.json \
  --run-id pfai-run-1234567890abcdef
```

The WordPress bridge will still run Pixflow's Stage A artifact inspection and
QA. Bricks conversion is marked ready only if that existing boundary accepts
the imported artifact.

Prepare a local Stage B Bricks conversion workspace from an accepted Stage A
workspace:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs prepare-stage-b \
  --stage-a-workspace ./pixflow-stage-a-runs/pixflow-design-landing \
  --workspace ./pixflow-stage-b-runs
```

Run the local Stage B conversion with Codex CLI:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs run-stage-b \
  --stage-a-workspace ./pixflow-stage-a-runs/pixflow-design-landing \
  --workspace ./pixflow-stage-b-runs \
  --force \
  --include-header yes \
  --header-scope current-page \
  --include-footer yes \
  --footer-scope current-page \
  --config pixflow-design-cli.config.json \
  --run-id pfai-run-1234567890abcdef \
  --import \
  --insert \
  --page-title "Pixflow Design Landing Test"
```

The Stage B workspace stages the accepted Stage A HTML, Pixflow Bricks MCP
contract, Pixflow Plugin MCP contract, and the Bricks Web Prototype skill pack.
When available, it also stages a Pixflow-owned clean-room HTML-to-Bricks
baseline:

- `bricks-baseline-result.json`
- `bricks-baseline-payload.json`
- `bricks-baseline-header-payload.json`
- `bricks-baseline-footer-payload.json`
- `bricks-baseline-global-classes.json`
- `stage-b-baseline-report.md`

The Stage B model should start from that baseline and run a focused cleanup
pass: preserve valid ids, class ids, attributes, responsive breakpoint settings,
image refs, header/footer extraction, page settings, and source class
ownership; then repair semantic Bricks choices and fidelity gaps. It should not
regenerate the page from scratch unless the baseline is missing or invalid.
The local model must output:

- `stage-b-route-contract.json`
- `stage-b-theme-style-contract.json`
- `stage-b-theme-style-health.json`
- `stage-b-color-system.json`
- `stage-b-font-system.json`
- `stage-b-icon-system.json`
- `bricks-result.json`
- `bricks-payload.json`
- `bricks-header-payload.json`
- `bricks-footer-payload.json`
- `global-classes.json`
- `conversion-report.md`

If Stage A contains a distinct header, Stage B writes `stage-b-header-plan.json`.
Header inclusion is explicit: use `--include-header yes` or
`--include-header no`. When included, use `--header-scope current-page` to
attach the Bricks header template only to the inserted page, or
`--header-scope sitewide` to apply it across the site. Approved header elements
are emitted separately as `bricks-result.json.stage_b_header.content`; the
plugin creates the Bricks header template and conditions during insertion.
Included headers are subject to local Stage B QA: the header inner wrapper and
any fallback nav/action block must have explicit Bricks flex row/wrap controls
on the elements themselves, not only in class CSS. When a real menu source is
available, Stage B should use the dedicated Bricks `nav-menu` element and keep
CTA actions as buttons.

Immediately after the header plan, if Stage A contains a distinct footer, Stage
B writes `stage-b-footer-plan.json`. Footer inclusion is also explicit: use
`--include-footer yes` or `--include-footer no`. When included, use
`--footer-scope current-page` to attach the Bricks footer template only to the
inserted page, or `--footer-scope sitewide` to apply it across the site.
Approved footer elements are emitted separately as
`bricks-result.json.stage_b_footer.content`; the plugin creates the Bricks
footer template and conditions during insertion.

Stage B follows the Pixflow Bricks contract staged into each workspace:

- Read `stage-b-route-contract.json`,
  `stage-b-theme-style-contract.json`, and
  `stage-b-theme-style-health.json` before authoring Bricks settings or
  global classes.
- Reuse Bricks setup/style primitives before creating new ones: theme style
  defaults, existing global classes, variables, then new classes/tokens.
- If `safeToLeanOnThemeStyles` is false, emit explicit page-scoped section,
  container, button, form, divider, card, and media baselines.
- For non-Pixflow routes, theme-style creation/mutation requires explicit user
  approval and a recorded scope; otherwise Stage B uses page-scoped fallbacks.
- Keep Stage B design-system palette rows token-backed with a literal fallback,
  for example `{ "name": "paper", "raw": "var(--paper)", "light": "#efe7d2" }`,
  so Bricks labels the token and the frontend still resolves a real color.
- Copy `stage-b-font-system.json` into `bricks-result.json.stage_b_font_system`.
  Pixflow installs Google Fonts into Bricks custom fonts before insertion;
  Stage B output must not add Google font imports, font URL injections, or
  ad hoc `@font-face` rules.
- Preserve Stage A body and tag-level typography inheritance. If the baseline
  projects body, heading, paragraph, link, or button font controls into Bricks
  settings, keep those controls unless source comparison proves they are wrong;
  otherwise the frontend can fall back to the site theme font.
- Copy `stage-b-icon-system.json` into `bricks-result.json.stage_b_icon_system`
  when sidecar icons are used. Pixflow builds/installs the requested Tabler SVG
  subset into Bricks custom icon sets before insertion; Stage B output must not
  use Font Awesome page icons or raw inline SVG icon markup.
- Standalone Pixflow SVG icon styling uses Bricks' nested global-class
  `settings.icon` object, for example `height`, `width`, `stroke`,
  `strokeWidth`, and `fill` for filled icons. Do not use `iconSize` or
  `iconColor` for Pixflow SVG icons.
- Keep `_cssGlobalClasses` as a flat array of class ID strings.
- Use Bricks underscore controls; avoid unprefixed style keys like `direction`,
  `fontSize`, `padding`, or `background`.
- Put typography under `_typography`; use scalar strings for number/unit
  controls such as `_width`, `_rowGap`, `_widthMax`, and `_heightMin`.
- Heading elements use `settings.tag` for the semantic HTML tag (`h1`-`h6`).
  Do not use `tagName`; Bricks ignores it and renders the default heading tag.
- Use valid Bricks link objects, for example
  `{ "type": "external", "url": "https://example.com" }`.
- Preserve Stage A `data-*`, `aria-*`, and source anchor `id` attributes with
  `_attributes`. Do not set Bricks `_cssId` during Stage B.
- Preserve safe Stage A JavaScript with page-level Bricks script settings:
  `bricks-result.json.page_settings.customScriptsBodyFooter` and
  `bricks-result.json.stage_b_page_settings.customScriptsBodyFooter`.
  Do not use Bricks `code` elements for Stage B JavaScript.
- Preserve source border radius, horizontal row wrappers, button icons,
  card/proof markers, and marquee rhythm with Bricks settings and Tabler SVG
  placeholders where the Stage A artifact used those affordances.
- Keep header/footer payloads separate from normal page content; Pixflow creates
  the `bricks_template` posts and applies `templateConditions`.
- Run local Stage B QA and repair targeted failures before import/insert.

Repair an existing Stage B workspace after QA fails:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs repair-stage-b \
  --workspace ./pixflow-stage-b-runs/pixflow-design-landing \
  --repair-attempts 1
```

When `--import` is present, the CLI posts the Stage B Bricks result and QA
artifacts back into the Direct Generation run. When `--insert` is also present,
the plugin creates or updates a real Bricks page through the normal Pixflow
Bricks mutation path.

You can also import or insert a completed Stage B workspace explicitly:

```bash
node tools/pixflow-design-cli/pixflow-design-cli.mjs import-stage-b \
  --config pixflow-design-cli.config.json \
  --run-id pfai-run-1234567890abcdef \
  --result-file ./pixflow-stage-b-runs/pixflow-design-landing/bricks-result.json \
  --qa-file ./pixflow-stage-b-runs/pixflow-design-landing/stage-b-qa.json \
  --conversion-report-file ./pixflow-stage-b-runs/pixflow-design-landing/conversion-report.md

node tools/pixflow-design-cli/pixflow-design-cli.mjs insert-stage-b \
  --config pixflow-design-cli.config.json \
  --run-id pfai-run-1234567890abcdef \
  --include-header yes \
  --header-scope current-page \
  --include-footer yes \
  --footer-scope current-page \
  --page-title "Pixflow Design Landing Test"
```

## Next Steps

The next runner phase will add:

- event streaming back to the Pixflow panel
- tighter panel-side progress display for Stage B import/insertion
