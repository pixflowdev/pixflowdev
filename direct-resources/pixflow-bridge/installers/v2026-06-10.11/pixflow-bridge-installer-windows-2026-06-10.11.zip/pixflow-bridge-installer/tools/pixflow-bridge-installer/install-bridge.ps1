param(
    [string] $InstallRoot = "",
    [string] $SourceRoot = "",
    [int] $Port = 47873,
    [string] $HostName = "127.0.0.1",
    [switch] $Start,
    [switch] $NoStart,
    [switch] $NoNodeInstall,
    [switch] $EnableAutostart,
    [switch] $NoAutostart,
    [switch] $CreateDesktopShortcut,
    [switch] $CreateAppShortcut,
    [switch] $Uninstall,
    [switch] $RemoveData,
    [switch] $AllowDowngrade,
    [switch] $Json
)

$ErrorActionPreference = "Stop"
$MinimumNodeMajor = 20

function Get-NodeMajor {
    $node = Get-Command node -ErrorAction SilentlyContinue
    if (-not $node) {
        return 0
    }

    $version = (& node --version 2>$null)
    if (-not $version) {
        return 0
    }

    $match = [regex]::Match($version, "v?(\d+)")
    if (-not $match.Success) {
        return 0
    }

    return [int] $match.Groups[1].Value
}

function Install-NodeRuntime {
    if ($NoNodeInstall) {
        throw "Node.js $MinimumNodeMajor or newer is required. Re-run without -NoNodeInstall or install Node.js first."
    }

    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) {
        throw "Node.js $MinimumNodeMajor or newer is required, and winget is not available to install it automatically."
    }

    Write-Host "Installing or updating Node.js LTS with winget..."
    & winget install OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) {
        & winget upgrade OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
    }

    $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Resolve-Path (Join-Path $scriptDir "..\..")
$installer = Join-Path $scriptDir "install-bridge.mjs"

if ($Uninstall) {
    $installedRuntime = Join-Path $(if ($InstallRoot) { $InstallRoot } else { Join-Path $env:LOCALAPPDATA "Pixflow Bridge" }) "install-bridge.mjs"
    if (Test-Path $installedRuntime) {
        $installer = $installedRuntime
    }
}

$nodeMajor = Get-NodeMajor
if ($nodeMajor -lt $MinimumNodeMajor) {
    Install-NodeRuntime
    $nodeMajor = Get-NodeMajor
}

if ($nodeMajor -lt $MinimumNodeMajor) {
    throw "Node.js $MinimumNodeMajor or newer is required after install/update. Current major version: $nodeMajor."
}

$argsList = @(
    $installer
)

if ($Uninstall) {
    $argsList += "--uninstall"
    if ($RemoveData) {
        $argsList += "--remove-data"
    }
} else {
    $argsList += @(
        "--source-root", $(if ($SourceRoot) { $SourceRoot } else { $repoRoot }),
        "--port", $Port,
        "--host", $HostName
    )

    if ($Start -and -not $NoStart) {
        $argsList += "--start"
    }
    if ($NoStart) {
        $argsList += "--no-start"
    }
    if ($EnableAutostart -and -not $NoAutostart) {
        $argsList += "--enable-autostart"
    }
    if ($NoAutostart) {
        $argsList += "--no-autostart"
    }
    if ($CreateDesktopShortcut) {
        $argsList += "--create-desktop-shortcut"
    }
    if ($CreateAppShortcut) {
        $argsList += "--create-app-shortcut"
    }
    if ($AllowDowngrade) {
        $argsList += "--allow-downgrade"
    }
}

if ($InstallRoot) {
    $argsList += @("--install-root", $InstallRoot)
}
if ($Json) {
    $argsList += "--json"
}

& node @argsList
