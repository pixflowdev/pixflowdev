#!/usr/bin/env node

import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import process from 'node:process';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const INSTALLER_VERSION = '2026-06-04.15';
const MIN_NODE_MAJOR = 20;
const DEFAULT_PORT = 47873;
const DEFAULT_HOST = '127.0.0.1';
const INSTALLER_RUNTIME = 'install-bridge.mjs';

async function main() {
  const flags = parseArgs(process.argv.slice(2));
  if (flags.version) {
    process.stdout.write(`Pixflow Bridge installer ${INSTALLER_VERSION}\n`);
    return;
  }
  if (flags.help) {
    process.stdout.write(renderHelp());
    return;
  }
  const installRoot = path.resolve(
    process.cwd(),
    firstString(flags.installRoot, flags.installDir, defaultInstallRoot())
  );

  if (flags.uninstall) {
    const result = await uninstallBridge({
      installRoot,
      removeData: truthyFlag(flags.removeData),
    });
    await printResult(result, flags);
    return;
  }

  const sourceRoot = path.resolve(
    process.cwd(),
    firstString(flags.sourceRoot, flags.source, defaultSourceRoot())
  );
  const appRoot = path.join(installRoot, 'app');
  const dataRoot = path.join(installRoot, 'data');
  const binRoot = path.join(installRoot, 'bin');
  const sourceCliRoot = path.join(sourceRoot, 'tools', 'pixflow-design-cli');
  const targetCliRoot = path.join(appRoot, 'tools', 'pixflow-design-cli');
  const port = positiveInteger(firstString(flags.port, process.env.PIXFLOW_BRIDGE_PORT), DEFAULT_PORT);
  const host = firstString(flags.host, process.env.PIXFLOW_BRIDGE_HOST, DEFAULT_HOST);
  const startDaemon = Boolean(flags.start) && !flags.noStart;
  const enableAutostart = truthyFlag(flags.enableAutostart) || truthyFlag(flags.autostart);
  const createDesktopShortcut = truthyFlag(flags.createDesktopShortcut) || truthyFlag(flags.desktopShortcut);
  const createAppShortcut = truthyFlag(flags.createAppShortcut) || truthyFlag(flags.startMenuShortcut) || truthyFlag(flags.appShortcut);
  const previousManifest = await readJson(path.join(installRoot, 'manifest.json'));
  const cliVersion = await readCliVersion(path.join(sourceCliRoot, 'pixflow-design-cli.mjs'));
  const previousVersion = firstString(previousManifest.bridgeVersion);
  const versionDelta = previousVersion ? compareVersions(cliVersion, previousVersion) : 1;
  if (versionDelta < 0 && !flags.allowDowngrade) {
    throw new Error(`Installed Pixflow Bridge ${previousVersion} is newer than source ${cliVersion}. Re-run with --allow-downgrade to replace it.`);
  }

  assertNodeRuntime();
  await assertSource(sourceCliRoot);
  await fs.mkdir(appRoot, { recursive: true });
  await fs.mkdir(dataRoot, { recursive: true });
  await fs.mkdir(binRoot, { recursive: true });
  await copyDirectory(sourceCliRoot, targetCliRoot);
  await copyInstallerRuntime(installRoot);

  const launchContext = {
    installRoot,
    appRoot,
    binRoot,
    cliPath: path.join(targetCliRoot, 'pixflow-design-cli.mjs'),
    installerPath: path.join(installRoot, INSTALLER_RUNTIME),
    dataRoot,
    host,
    port,
  };

  await writeWrappers(launchContext);
  const lifecycle = await configureLifecycle({
    ...launchContext,
    enableAutostart,
    createDesktopShortcut,
    createAppShortcut,
  });

  const now = new Date().toISOString();
  const manifest = {
    type: 'pixflow_bridge_installation',
    version: 1,
    installerVersion: INSTALLER_VERSION,
    bridgeVersion: cliVersion,
    previousBridgeVersion: previousVersion,
    protocolVersion: '2026-06-04.2',
    minNodeMajor: MIN_NODE_MAJOR,
    mode: installMode(previousManifest, versionDelta),
    platform: process.platform,
    arch: process.arch,
    nodeVersion: process.version,
    installRoot,
    appRoot,
    dataRoot,
    binRoot,
    installerPath: launchContext.installerPath,
    lifecycle,
    installedAt: firstString(previousManifest.installedAt, now),
    updatedAt: now,
  };

  await writeJson(path.join(installRoot, 'manifest.json'), manifest);

  let daemon = null;
  if (startDaemon) {
    daemon = startBridgeDaemon({
      cliPath: path.join(targetCliRoot, 'pixflow-design-cli.mjs'),
      dataRoot,
      host,
      port,
    });
  }

  const result = {
    status: 'ok',
    message: installMessage(previousManifest, versionDelta),
    manifest,
    daemon,
    commands: {
      bridge: process.platform === 'win32'
        ? path.join(binRoot, 'pixflow-bridge.cmd')
        : path.join(binRoot, 'pixflow-bridge'),
      start: daemonStartCommand(launchContext),
      status: daemonStatusCommand(launchContext),
      stop: daemonStopCommand(launchContext),
      uninstall: uninstallCommand(launchContext),
    },
  };

  await printResult(result, flags);
  if (daemon) {
    process.stdout.write(`Daemon: http://${host}:${port}\n`);
  }
}

function parseArgs(args) {
  const flags = {};
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (!arg.startsWith('--')) {
      continue;
    }
    const raw = arg.slice(2);
    const eq = raw.indexOf('=');
    const key = camelCase(eq >= 0 ? raw.slice(0, eq) : raw);
    if (eq >= 0) {
      flags[key] = raw.slice(eq + 1);
      continue;
    }
    const next = args[index + 1];
    if (next && !next.startsWith('--')) {
      flags[key] = next;
      index += 1;
    } else {
      flags[key] = true;
    }
  }
  return flags;
}

function renderHelp() {
  return [
    `Pixflow Bridge installer ${INSTALLER_VERSION}`,
    '',
    'Usage:',
    '  node tools/pixflow-bridge-installer/install-bridge.mjs [options]',
    '',
    'Options:',
    '  --start                         Start the local daemon after install/update.',
    '  --enable-autostart              Start Pixflow Bridge automatically when the user signs in.',
    '  --create-desktop-shortcut       Create a desktop launcher.',
    '  --create-app-shortcut           Create Start Menu/app launcher entries.',
    '  --uninstall                     Remove Pixflow Bridge launchers and installed files.',
    '  --remove-data                   With --uninstall, also remove local bridge data.',
    '  --install-root <path>           Override the install directory.',
    '  --source-root <path>            Override the source directory used for install/update.',
    '  --host <host>                   Daemon host. Default: 127.0.0.1.',
    '  --port <port>                   Daemon port. Default: 47873.',
    '  --version                       Print installer version and exit.',
    '  --help                          Show this help.',
    '',
  ].join('\n');
}

function camelCase(value) {
  return String(value || '').replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
}

function firstString(...values) {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) {
      return value.trim();
    }
  }
  return '';
}

function positiveInteger(value, fallback) {
  const parsed = Number.parseInt(String(value || ''), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function truthyFlag(value) {
  if (value === true) return true;
  if (value === false || value === null || value === undefined) return false;
  return ['1', 'true', 'yes', 'on'].includes(String(value).trim().toLowerCase());
}

function installMode(previousManifest, versionDelta) {
  if (!previousManifest.version) {
    return 'installed';
  }
  if (versionDelta > 0) {
    return 'updated';
  }
  if (versionDelta < 0) {
    return 'downgraded';
  }
  return 'repaired';
}

function installMessage(previousManifest, versionDelta) {
  const mode = installMode(previousManifest, versionDelta);
  if (mode === 'installed') return 'Pixflow Bridge installed.';
  if (mode === 'updated') return 'Pixflow Bridge updated.';
  if (mode === 'downgraded') return 'Pixflow Bridge downgraded.';
  return 'Pixflow Bridge repaired.';
}

function compareVersions(left, right) {
  const a = String(left || '').split(/[.-]/).map((part) => Number.parseInt(part, 10));
  const b = String(right || '').split(/[.-]/).map((part) => Number.parseInt(part, 10));
  const length = Math.max(a.length, b.length, 3);
  for (let index = 0; index < length; index += 1) {
    const av = Number.isFinite(a[index]) ? a[index] : 0;
    const bv = Number.isFinite(b[index]) ? b[index] : 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

function defaultSourceRoot() {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
}

function defaultInstallRoot() {
  if (process.platform === 'win32') {
    return path.join(firstString(process.env.LOCALAPPDATA, process.env.APPDATA, os.homedir()), 'Pixflow Bridge');
  }
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'Pixflow Bridge');
  }
  return path.join(firstString(process.env.XDG_DATA_HOME, path.join(os.homedir(), '.local', 'share')), 'pixflow-bridge');
}

function assertNodeRuntime() {
  const major = Number.parseInt(process.versions.node.split('.')[0] || '0', 10);
  if (!Number.isFinite(major) || major < MIN_NODE_MAJOR) {
    throw new Error(`Pixflow Bridge requires Node.js ${MIN_NODE_MAJOR} or newer. Current runtime: ${process.version}`);
  }
}

async function assertSource(sourceCliRoot) {
  if (!existsSync(path.join(sourceCliRoot, 'pixflow-design-cli.mjs'))) {
    throw new Error(`Pixflow Design CLI source was not found at ${sourceCliRoot}`);
  }
}

async function readCliVersion(cliPath) {
  const source = await fs.readFile(cliPath, 'utf8');
  const match = source.match(/const\s+VERSION\s*=\s*['"]([^'"]+)['"]/);
  return match ? match[1] : '0.0.0';
}

async function copyDirectory(source, target) {
  await fs.mkdir(target, { recursive: true });
  await fs.cp(source, target, {
    recursive: true,
    force: true,
    errorOnExist: false,
  });
}

async function copyInstallerRuntime(installRoot) {
  await fs.copyFile(fileURLToPath(import.meta.url), path.join(installRoot, INSTALLER_RUNTIME));
}

async function writeWrappers(context) {
  const { installRoot, binRoot, cliPath, dataRoot, host, port } = context;
  await fs.writeFile(path.join(binRoot, 'pixflow-bridge.cmd'), [
    '@echo off',
    'setlocal',
    `"${process.execPath}" "${cliPath}" %*`,
    'endlocal',
    '',
  ].join('\r\n'), 'utf8');

  await fs.writeFile(path.join(binRoot, 'pixflow-bridge.ps1'), [
    '$ErrorActionPreference = "Stop"',
    `& "${process.execPath}" "${cliPath}" @args`,
    '',
  ].join('\n'), 'utf8');

  const shellWrapper = [
    '#!/usr/bin/env sh',
    `exec "${process.execPath}" "${cliPath}" "$@"`,
    '',
  ].join('\n');
  const shellPath = path.join(binRoot, 'pixflow-bridge');
  await fs.writeFile(shellPath, shellWrapper, 'utf8');
  try {
    await fs.chmod(shellPath, 0o755);
  } catch {
    // Windows chmod is best-effort for the portable shell wrapper.
  }

  await fs.writeFile(path.join(installRoot, 'start-daemon.cmd'), [
    '@echo off',
    'setlocal',
    `start "Pixflow Bridge" /min "${process.execPath}" "${cliPath}" daemon start --data-dir "${dataRoot}" --host ${host} --port ${port}`,
    'endlocal',
    '',
  ].join('\r\n'), 'utf8');

  await fs.writeFile(path.join(installRoot, 'stop-daemon.cmd'), [
    '@echo off',
    'setlocal',
    `"${process.execPath}" "${cliPath}" daemon stop --daemon-url http://${host}:${port}`,
    'endlocal',
    '',
  ].join('\r\n'), 'utf8');

  const startShellPath = path.join(installRoot, 'start-daemon.sh');
  await fs.writeFile(startShellPath, [
    '#!/usr/bin/env sh',
    `nohup "${process.execPath}" "${cliPath}" daemon start --data-dir "${dataRoot}" --host ${host} --port ${port} >/dev/null 2>&1 &`,
    '',
  ].join('\n'), 'utf8');

  const stopShellPath = path.join(installRoot, 'stop-daemon.sh');
  await fs.writeFile(stopShellPath, [
    '#!/usr/bin/env sh',
    `exec "${process.execPath}" "${cliPath}" daemon stop --daemon-url "http://${host}:${port}"`,
    '',
  ].join('\n'), 'utf8');

  try {
    await fs.chmod(startShellPath, 0o755);
    await fs.chmod(stopShellPath, 0o755);
  } catch {
    // Windows chmod is best-effort for Unix launchers.
  }

  await writeUninstallers(context);
}

async function writeUninstallers(context) {
  const { installRoot, installerPath } = context;

  await fs.writeFile(path.join(installRoot, 'Uninstall Pixflow Bridge.cmd'), [
    '@echo off',
    'setlocal',
    `powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall-pixflow-bridge.ps1"`,
    'endlocal',
    '',
  ].join('\r\n'), 'utf8');

  await fs.writeFile(path.join(installRoot, 'uninstall-pixflow-bridge.ps1'), [
    '$ErrorActionPreference = "Stop"',
    `& "${process.execPath}" "${installerPath}" --uninstall`,
    'Write-Host "Pixflow Bridge has been uninstalled. Local bridge data was preserved."',
    '',
  ].join('\n'), 'utf8');

  const uninstallShellPath = path.join(installRoot, 'uninstall-pixflow-bridge.sh');
  await fs.writeFile(uninstallShellPath, [
    '#!/usr/bin/env sh',
    `exec "${process.execPath}" "${installerPath}" --uninstall`,
    '',
  ].join('\n'), 'utf8');

  try {
    await fs.chmod(uninstallShellPath, 0o755);
  } catch {
    // Windows chmod is best-effort for Unix launchers.
  }
}

async function configureLifecycle(context) {
  const autostart = context.enableAutostart
    ? await enableAutostart(context)
    : await disableAutostart(context);
  const shortcuts = await configureShortcuts(context);

  return {
    autostart,
    shortcuts,
    uninstaller: {
      available: true,
      preserveDataByDefault: true,
      windows: path.join(context.installRoot, 'Uninstall Pixflow Bridge.cmd'),
      unix: path.join(context.installRoot, 'uninstall-pixflow-bridge.sh'),
    },
  };
}

async function configureShortcuts(context) {
  const result = {
    desktop: { enabled: false, paths: [] },
    appMenu: { enabled: false, paths: [] },
  };

  if (context.createDesktopShortcut) {
    result.desktop = await writeDesktopShortcut(context);
  } else {
    result.desktop = await removeDesktopShortcut(context);
  }

  if (context.createAppShortcut) {
    result.appMenu = await writeAppShortcut(context);
  } else {
    result.appMenu = await removeAppShortcut(context);
  }

  return result;
}

async function enableAutostart(context) {
  if (process.platform === 'win32') {
    const startupDir = windowsStartupDir();
    const target = path.join(startupDir, 'Pixflow Bridge.cmd');
    await fs.mkdir(startupDir, { recursive: true });
    await fs.copyFile(path.join(context.installRoot, 'start-daemon.cmd'), target);
    return { enabled: true, method: 'windows_startup_folder', path: target };
  }

  if (process.platform === 'darwin') {
    const agentsDir = path.join(os.homedir(), 'Library', 'LaunchAgents');
    const target = path.join(agentsDir, 'dev.pixflow.bridge.plist');
    await fs.mkdir(agentsDir, { recursive: true });
    await fs.writeFile(target, macosLaunchAgent(context), 'utf8');
    return { enabled: true, method: 'macos_launch_agent', path: target };
  }

  const autostartDir = path.join(firstString(process.env.XDG_CONFIG_HOME, path.join(os.homedir(), '.config')), 'autostart');
  const target = path.join(autostartDir, 'pixflow-bridge.desktop');
  await fs.mkdir(autostartDir, { recursive: true });
  await fs.writeFile(target, linuxDesktopFile(context, 'Pixflow Bridge', context.launchScript || path.join(context.installRoot, 'start-daemon.sh')), 'utf8');
  return { enabled: true, method: 'linux_xdg_autostart', path: target };
}

async function disableAutostart() {
  const paths = [];
  if (process.platform === 'win32') {
    paths.push(path.join(windowsStartupDir(), 'Pixflow Bridge.cmd'));
  } else if (process.platform === 'darwin') {
    paths.push(path.join(os.homedir(), 'Library', 'LaunchAgents', 'dev.pixflow.bridge.plist'));
  } else {
    paths.push(path.join(firstString(process.env.XDG_CONFIG_HOME, path.join(os.homedir(), '.config')), 'autostart', 'pixflow-bridge.desktop'));
  }

  await removePaths(paths);
  return { enabled: false, removed: paths };
}

async function writeDesktopShortcut(context) {
  const desktop = path.join(os.homedir(), 'Desktop');
  await fs.mkdir(desktop, { recursive: true });
  if (process.platform === 'win32') {
    const target = path.join(desktop, 'Pixflow Bridge.cmd');
    await fs.copyFile(path.join(context.installRoot, 'start-daemon.cmd'), target);
    return { enabled: true, paths: [target] };
  }

  if (process.platform === 'darwin') {
    const target = path.join(desktop, 'Pixflow Bridge.command');
    await fs.copyFile(path.join(context.installRoot, 'start-daemon.sh'), target);
    await fs.chmod(target, 0o755);
    return { enabled: true, paths: [target] };
  }

  const target = path.join(desktop, 'pixflow-bridge.desktop');
  await fs.writeFile(target, linuxDesktopFile(context, 'Pixflow Bridge', path.join(context.installRoot, 'start-daemon.sh')), 'utf8');
  await fs.chmod(target, 0o755);
  return { enabled: true, paths: [target] };
}

async function removeDesktopShortcut() {
  const desktop = path.join(os.homedir(), 'Desktop');
  const paths = [
    path.join(desktop, 'Pixflow Bridge.cmd'),
    path.join(desktop, 'Pixflow Bridge.command'),
    path.join(desktop, 'pixflow-bridge.desktop'),
  ];
  await removePaths(paths);
  return { enabled: false, removed: paths };
}

async function writeAppShortcut(context) {
  if (process.platform === 'win32') {
    const menuDir = windowsPixflowProgramsDir();
    await fs.mkdir(menuDir, { recursive: true });
    const startTarget = path.join(menuDir, 'Pixflow Bridge.cmd');
    const stopTarget = path.join(menuDir, 'Stop Pixflow Bridge.cmd');
    const uninstallTarget = path.join(menuDir, 'Uninstall Pixflow Bridge.cmd');
    await fs.copyFile(path.join(context.installRoot, 'start-daemon.cmd'), startTarget);
    await fs.copyFile(path.join(context.installRoot, 'stop-daemon.cmd'), stopTarget);
    await fs.copyFile(path.join(context.installRoot, 'Uninstall Pixflow Bridge.cmd'), uninstallTarget);
    return { enabled: true, paths: [startTarget, stopTarget, uninstallTarget] };
  }

  if (process.platform === 'darwin') {
    const appsDir = path.join(os.homedir(), 'Applications');
    await fs.mkdir(appsDir, { recursive: true });
    const target = path.join(appsDir, 'Pixflow Bridge.command');
    await fs.copyFile(path.join(context.installRoot, 'start-daemon.sh'), target);
    await fs.chmod(target, 0o755);
    return { enabled: true, paths: [target] };
  }

  const appsDir = path.join(firstString(process.env.XDG_DATA_HOME, path.join(os.homedir(), '.local', 'share')), 'applications');
  await fs.mkdir(appsDir, { recursive: true });
  const target = path.join(appsDir, 'pixflow-bridge.desktop');
  await fs.writeFile(target, linuxDesktopFile(context, 'Pixflow Bridge', path.join(context.installRoot, 'start-daemon.sh')), 'utf8');
  await fs.chmod(target, 0o755);
  return { enabled: true, paths: [target] };
}

async function removeAppShortcut() {
  const paths = [
    path.join(windowsPixflowProgramsDir(), 'Pixflow Bridge.cmd'),
    path.join(windowsPixflowProgramsDir(), 'Stop Pixflow Bridge.cmd'),
    path.join(windowsPixflowProgramsDir(), 'Uninstall Pixflow Bridge.cmd'),
    path.join(os.homedir(), 'Applications', 'Pixflow Bridge.command'),
    path.join(firstString(process.env.XDG_DATA_HOME, path.join(os.homedir(), '.local', 'share')), 'applications', 'pixflow-bridge.desktop'),
  ];
  await removePaths(paths);
  return { enabled: false, removed: paths };
}

async function uninstallBridge({ installRoot, removeData }) {
  const manifest = await readJson(path.join(installRoot, 'manifest.json'));
  const cliPath = firstString(manifest.appRoot) ? path.join(manifest.appRoot, 'tools', 'pixflow-design-cli', 'pixflow-design-cli.mjs') : '';
  const dataRoot = firstString(manifest.dataRoot, path.join(installRoot, 'data'));
  const host = DEFAULT_HOST;
  const port = DEFAULT_PORT;

  if (cliPath && existsSync(cliPath)) {
    await runProcess(process.execPath, [
      cliPath,
      'daemon',
      'stop',
      '--daemon-url',
      `http://${host}:${port}`,
    ]).catch(() => {});
  }

  await disableAutostart();
  await removeDesktopShortcut();
  await removeAppShortcut();

  if (removeData) {
    await fs.rm(installRoot, { recursive: true, force: true });
  } else {
    await removePaths([
      path.join(installRoot, 'app'),
      path.join(installRoot, 'bin'),
      path.join(installRoot, 'manifest.json'),
      path.join(installRoot, 'start-daemon.cmd'),
      path.join(installRoot, 'stop-daemon.cmd'),
      path.join(installRoot, 'start-daemon.sh'),
      path.join(installRoot, 'stop-daemon.sh'),
      path.join(installRoot, 'Uninstall Pixflow Bridge.cmd'),
      path.join(installRoot, 'uninstall-pixflow-bridge.ps1'),
      path.join(installRoot, 'uninstall-pixflow-bridge.sh'),
      path.join(installRoot, INSTALLER_RUNTIME),
    ]);
    await fs.mkdir(dataRoot, { recursive: true }).catch(() => {});
  }

  return {
    status: 'ok',
    message: removeData
      ? 'Pixflow Bridge uninstalled and local data removed.'
      : 'Pixflow Bridge uninstalled. Local data was preserved.',
    installRoot,
    dataRoot: removeData ? '' : dataRoot,
  };
}

async function removePaths(paths) {
  for (const target of paths) {
    if (!target) continue;
    await fs.rm(target, { recursive: true, force: true }).catch(() => {});
  }
}

function startBridgeDaemon({ cliPath, dataRoot, host, port }) {
  const child = spawn(process.execPath, [
    cliPath,
    'daemon',
    'start',
    '--data-dir',
    dataRoot,
    '--host',
    host,
    '--port',
    String(port),
  ], {
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  child.unref();
  return {
    pid: child.pid,
    url: `http://${host}:${port}`,
  };
}

function windowsStartupDir() {
  return path.join(firstString(process.env.APPDATA, path.join(os.homedir(), 'AppData', 'Roaming')), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
}

function windowsPixflowProgramsDir() {
  return path.join(firstString(process.env.APPDATA, path.join(os.homedir(), 'AppData', 'Roaming')), 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Pixflow');
}

function daemonStartCommand({ cliPath, dataRoot, host, port }) {
  return `${quote(process.execPath)} ${quote(cliPath)} daemon start --data-dir ${quote(dataRoot)} --host ${host} --port ${port}`;
}

function daemonStatusCommand({ cliPath, host, port }) {
  return `${quote(process.execPath)} ${quote(cliPath)} daemon status --daemon-url http://${host}:${port}`;
}

function daemonStopCommand({ cliPath, host, port }) {
  return `${quote(process.execPath)} ${quote(cliPath)} daemon stop --daemon-url http://${host}:${port}`;
}

function uninstallCommand({ installerPath }) {
  return `${quote(process.execPath)} ${quote(installerPath)} --uninstall`;
}

function macosLaunchAgent({ cliPath, dataRoot, host, port }) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>dev.pixflow.bridge</string>
  <key>ProgramArguments</key>
  <array>
    <string>${escapeXml(process.execPath)}</string>
    <string>${escapeXml(cliPath)}</string>
    <string>daemon</string>
    <string>start</string>
    <string>--data-dir</string>
    <string>${escapeXml(dataRoot)}</string>
    <string>--host</string>
    <string>${escapeXml(host)}</string>
    <string>--port</string>
    <string>${escapeXml(String(port))}</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>StandardOutPath</key>
  <string>${escapeXml(path.join(dataRoot, 'daemon.out.log'))}</string>
  <key>StandardErrorPath</key>
  <string>${escapeXml(path.join(dataRoot, 'daemon.err.log'))}</string>
</dict>
</plist>
`;
}

function linuxDesktopFile(context, name, executablePath) {
  return [
    '[Desktop Entry]',
    'Type=Application',
    `Name=${name}`,
    'Comment=Start the Pixflow Bridge daemon for Pixflow Design',
    `Exec="${quoteForDesktopFile(executablePath)}"`,
    'Terminal=false',
    'Categories=Development;',
    'X-GNOME-Autostart-enabled=true',
    '',
  ].join('\n');
}

function quoteForDesktopFile(value) {
  return String(value || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

function escapeXml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function runProcess(fileName, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(fileName, args, {
      windowsHide: true,
      stdio: 'ignore',
    });
    child.once('error', reject);
    child.once('exit', (code) => {
      if (code === 0) {
        resolve();
        return;
      }
      reject(new Error(`${fileName} exited with ${code}`));
    });
  });
}

async function readJson(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf8'));
  } catch {
    return {};
  }
}

async function writeJson(filePath, value) {
  await fs.writeFile(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

function quote(value) {
  const text = String(value || '');
  if (!text || /[\s"']/u.test(text)) {
    return `"${text.replace(/"/g, '\\"')}"`;
  }
  return text;
}

async function printResult(result, flags) {
  if (flags.json) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    return;
  }

  process.stdout.write(`${result.message}\n`);
  if (result.installRoot) {
    process.stdout.write(`Install: ${result.installRoot}\n`);
  } else if (result.manifest?.installRoot) {
    process.stdout.write(`Install: ${result.manifest.installRoot}\n`);
  }
  if (result.dataRoot) {
    process.stdout.write(`Data: ${result.dataRoot}\n`);
  } else if (result.manifest?.dataRoot) {
    process.stdout.write(`Data: ${result.manifest.dataRoot}\n`);
  }
  if (result.commands?.bridge) {
    process.stdout.write(`Command: ${result.commands.bridge}\n`);
  }
}

main().catch((error) => {
  process.stderr.write(`Pixflow Bridge installer failed: ${error.message}\n`);
  process.exitCode = 1;
});
