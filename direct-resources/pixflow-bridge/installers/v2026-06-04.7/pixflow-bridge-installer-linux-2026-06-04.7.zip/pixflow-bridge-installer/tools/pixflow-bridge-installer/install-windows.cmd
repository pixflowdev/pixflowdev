@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "INSTALLER=%SCRIPT_DIR%tools\pixflow-bridge-installer\install-bridge.ps1"
set "LOCAL_INSTALLER=%SCRIPT_DIR%install-bridge.ps1"
set "BOOTSTRAP_URL=https://raw.githubusercontent.com/pixflowdev/pixflowdev/main/direct-resources/pixflow-bridge/installers/v2026-06-04.7/pixflow-bridge-installer-windows-2026-06-04.7.zip"

echo Pixflow Bridge Setup
echo.
echo This installer will install or update Pixflow Bridge and start the local daemon.
echo.

if exist "%INSTALLER%" goto run_installer
if exist "%LOCAL_INSTALLER%" (
  set "INSTALLER=%LOCAL_INSTALLER%"
  goto run_installer
)

echo Installer support files were not found next to this launcher.
echo If you opened the launcher directly from the zip file, Pixflow will download and extract the full package now.
echo.

set "BOOTSTRAP_DIR=%TEMP%\pixflow-bridge-installer-%RANDOM%%RANDOM%"
set "BOOTSTRAP_ZIP=%BOOTSTRAP_DIR%\installer.zip"
mkdir "%BOOTSTRAP_DIR%" >nul 2>nul
if errorlevel 1 (
  echo Could not create a temporary installer folder.
  goto installer_failed
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri '%BOOTSTRAP_URL%' -OutFile '%BOOTSTRAP_ZIP%'; Expand-Archive -LiteralPath '%BOOTSTRAP_ZIP%' -DestinationPath '%BOOTSTRAP_DIR%' -Force; exit 0 } catch { Write-Error $_; exit 1 }"
if errorlevel 1 goto installer_failed

set "INSTALLER=%BOOTSTRAP_DIR%\pixflow-bridge-installer\tools\pixflow-bridge-installer\install-bridge.ps1"
if not exist "%INSTALLER%" (
  echo The downloaded installer package did not contain the expected PowerShell installer.
  goto installer_failed
)

:run_installer
powershell -NoProfile -ExecutionPolicy Bypass -File "%INSTALLER%" -Start -EnableAutostart -CreateDesktopShortcut -CreateAppShortcut
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" goto installer_success

:installer_failed
  if "%EXIT_CODE%"=="" set "EXIT_CODE=1"
  echo Pixflow Bridge setup did not complete.
  echo Keep this window open and send the message above to Pixflow support if needed.
  pause
  exit /b %EXIT_CODE%

:installer_success
echo Pixflow Bridge is installed and starting.
echo Return to Pixflow Design, then click Detect daemon and Connect bridge.
pause
exit /b 0
