# Pixflow Bridge Installer

This folder contains the shared installer/updater logic for the local Pixflow
Bridge plus platform launchers used by the downloadable installer packages.

The normal user flow should be a downloaded package from the Pixflow resource
repo, not a copied terminal command. The command examples below are advanced
fallbacks for support and development.

## What It Does

- Checks for Node.js 20 or newer.
- Attempts to install/update Node when possible:
  - Windows: `winget` and `OpenJS.NodeJS.LTS`
  - macOS: Homebrew `node`
  - Linux: `apt-get`, `dnf`, `yum`, or `pacman`
- Installs or updates the local bridge app files.
- Preserves local bridge state under the install `data` folder.
- Writes command wrappers under the install `bin` folder.
- Writes an installation `manifest.json`.
- Can register Pixflow Bridge to start automatically when the user signs in.
- Can create desktop and app-menu launchers.
- Writes an uninstall entry that removes the daemon app and launchers while
  preserving local bridge data by default.
- Can start the loopback daemon after install.
- Blocks accidental downgrades unless `--allow-downgrade` is passed.

## Installer Tiers

Pixflow Bridge uses three installer tiers:

1. Native installer/updater for novice users.
2. Downloadable script package fallback for platforms that do not have a signed
   native build yet.
3. Manual commands for support and development only.

Windows currently has a self-extracting `.exe` wrapper around the same tested
installer package. It presents novice-facing options for autostart, desktop
launcher, and Start Menu entries, and embeds a small tray controller for
start/stop/status. macOS and Linux still use the script package fallback until
we have signed/notarized `.dmg`/`.pkg` and AppImage/deb/rpm release builds.

## Downloadable Packages

Build the self-contained installer packages from the plugin checkout:

```bash
php build/build-pixflow-bridge-installers.php
```

The packages are written to:

```text
build/pixflow-bridge-installers/v<installer-version>/
```

Each package contains the installer logic and `tools/pixflow-design-cli`, so a
non-technical user does not need a local Pixflow plugin checkout.

- Windows: unzip, then double-click `Install Pixflow Bridge.cmd`.
- macOS: unzip, then open `Install Pixflow Bridge.command`.
- Linux: unzip, then run `Install Pixflow Bridge.sh`.

Running the same launcher again updates an existing installation and preserves
the local `data/` folder. The generated uninstall entry removes app files,
autostart, and shortcuts. Local bridge data is preserved unless support runs the
low-level installer with `--remove-data`.

The Windows native setup also installs `Pixflow Bridge Tray.exe` into the
install folder. Desktop, Start Menu, and autostart launchers point at that tray
controller so users have a visible green/gray status indicator and Start/Stop
actions from the system tray.

Build the current Windows native wrapper after the zip package exists:

```bash
php build/build-pixflow-bridge-native-installers.php
```

The Windows native artifact is written next to the zip packages:

```text
build/pixflow-bridge-installers/v<installer-version>/pixflow-bridge-setup-windows-<installer-version>.exe
```

## Windows

Advanced fallback:

```powershell
powershell -ExecutionPolicy Bypass -File tools\pixflow-bridge-installer\install-bridge.ps1
```

Install/update and start the daemon:

```powershell
powershell -ExecutionPolicy Bypass -File tools\pixflow-bridge-installer\install-bridge.ps1 `
  -Start `
  -EnableAutostart `
  -CreateDesktopShortcut `
  -CreateAppShortcut
```

Install to a custom folder:

```powershell
powershell -ExecutionPolicy Bypass -File tools\pixflow-bridge-installer\install-bridge.ps1 `
  -InstallRoot "$env:LOCALAPPDATA\Pixflow Bridge"
```

## macOS / Linux

Advanced fallback:

```bash
sh tools/pixflow-bridge-installer/install-bridge.sh
```

Install/update and start the daemon:

```bash
sh tools/pixflow-bridge-installer/install-bridge.sh \
  --start \
  --enable-autostart \
  --create-desktop-shortcut \
  --create-app-shortcut
```

Install to a custom folder:

```bash
sh tools/pixflow-bridge-installer/install-bridge.sh \
  --install-root "$HOME/.local/share/pixflow-bridge"
```

## Installed Layout

```text
Pixflow Bridge/
  app/      copied bridge runtime files
  bin/      pixflow-bridge command wrappers
  data/     daemon state, connected sites, local run logs
  manifest.json
  start-daemon.*
  stop-daemon.*
  uninstall-pixflow-bridge.*
```

The installer/updater does not delete `data/`. Site pairings, provider auth
state, local run history, and logs should survive updates.

## Connect To WordPress

1. Start the daemon:

   ```bash
   pixflow-bridge daemon start
   ```

2. Open Pixflow Design in WordPress.
3. Go to Settings > Execution > Local CLI.
4. Click Detect daemon.
5. Click Connect bridge.

Use Disconnect in Pixflow Design before handing a site to a client. Revocation
is server-authoritative: the local daemon can keep running, but it can no
longer access a site after the WordPress pairing is revoked.

## Uninstall

Use the generated operating-system launcher when available:

- Windows: Start Menu > Pixflow > Uninstall Pixflow Bridge.
- macOS/Linux: run `uninstall-pixflow-bridge.sh` from the install folder.

Advanced fallback:

```bash
node /path/to/Pixflow\ Bridge/install-bridge.mjs --uninstall
```

By default uninstall preserves the local `data/` folder so existing pairings and
logs are not destroyed accidentally. Support can pass `--remove-data` when a
complete local reset is required.

## Later Native Installer Work

- Code-sign and notarize release installers.
- Replace the ZIP package launchers with signed `.exe`, notarized `.pkg`, and
  distro-friendly Linux packages when release infrastructure is ready.
- Package the macOS bridge as a signed app bundle so `pixflow-bridge://`
  pairing can be registered reliably there. Windows now registers an HKCU URL
  protocol handler, and Linux registers an XDG scheme handler.
- Add macOS menu bar and Linux tray support. Windows now has a bundled tray
  controller in the native setup package.
- Add a signed update feed.
- Add provider auth cards for Codex, Claude, Gemini, and custom local runners.
