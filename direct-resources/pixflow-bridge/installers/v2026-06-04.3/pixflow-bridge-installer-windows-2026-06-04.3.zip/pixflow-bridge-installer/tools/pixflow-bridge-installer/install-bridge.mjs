#!/usr/bin/env node

import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import process from 'node:process';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const INSTALLER_VERSION = '2026-06-04.3';
const MIN_NODE_MAJOR = 20;
const DEFAULT_PORT = 47873;
const DEFAULT_HOST = '127.0.0.1';

async function main() {
  const flags = parseArgs(process.argv.slice(2));
  const sourceRoot = path.resolve(
    process.cwd(),
    firstString(flags.sourceRoot, flags.source, defaultSourceRoot())
  );
  const installRoot = path.resolve(
    process.cwd(),
    firstString(flags.installRoot, flags.installDir, defaultInstallRoot())
  );
  const appRoot = path.join(installRoot, 'app');
  const dataRoot = path.join(installRoot, 'data');
  const binRoot = path.join(installRoot, 'bin');
  const sourceCliRoot = path.join(sourceRoot, 'tools', 'pixflow-design-cli');
  const targetCliRoot = path.join(appRoot, 'tools', 'pixflow-design-cli');
  const port = positiveInteger(firstString(flags.port, process.env.PIXFLOW_BRIDGE_PORT), DEFAULT_PORT);
  const host = firstString(flags.host, process.env.PIXFLOW_BRIDGE_HOST, DEFAULT_HOST);
  const startDaemon = Boolean(flags.start) && !flags.noStart;
  const previousManifest = await readJson(path.join(installRoot, 'manifest.json'));
  const cliVersion = await readCliVersion(path.join(sourceCliRoot, 'pixflow-design-cli.mjs'));
  const previousVersion = firstString(previousManifest.bridgeVersion);
  const versionDelta = previousVersion ? compareVersions(cliVersion, previousVersion) : 1;
  if (versionDelta < 0 && !flags.allowDowngrade) {
    throw new Error(`Installed Pixflow Bridge ${previousVersion} is newer than source ${cliVersion}. Re-run with --allow-downgrade to replace it.`);
  }

  assertNodeRuntime();
  await assertSource(sourceCliRoot);
  await fs.mkdir(appRoot, { recursive: true });
  await fs.mkdir(dataRoot, { recursive: true });
  await fs.mkdir(binRoot, { recursive: true });
  await copyDirectory(sourceCliRoot, targetCliRoot);
  await writeWrappers({ installRoot, appRoot, binRoot });

  const now = new Date().toISOString();
  const manifest = {
    type: 'pixflow_bridge_installation',
    version: 1,
    installerVersion: INSTALLER_VERSION,
    bridgeVersion: cliVersion,
    previousBridgeVersion: previousVersion,
    protocolVersion: '2026-06-04.1',
    minNodeMajor: MIN_NODE_MAJOR,
    mode: installMode(previousManifest, versionDelta),
    platform: process.platform,
    arch: process.arch,
    nodeVersion: process.version,
    installRoot,
    appRoot,
    dataRoot,
    binRoot,
    installedAt: firstString(previousManifest.installedAt, now),
    updatedAt: now,
  };

  await writeJson(path.join(installRoot, 'manifest.json'), manifest);

  let daemon = null;
  if (startDaemon) {
    daemon = startBridgeDaemon({
      cliPath: path.join(targetCliRoot, 'pixflow-design-cli.mjs'),
      dataRoot,
      host,
      port,
    });
  }

  const result = {
    status: 'ok',
    message: installMessage(previousManifest, versionDelta),
    manifest,
    daemon,
    commands: {
      bridge: process.platform === 'win32'
        ? path.join(binRoot, 'pixflow-bridge.cmd')
        : path.join(binRoot, 'pixflow-bridge'),
      start: `${quote(process.execPath)} ${quote(path.join(targetCliRoot, 'pixflow-design-cli.mjs'))} daemon start --data-dir ${quote(dataRoot)} --host ${host} --port ${port}`,
      status: `${quote(process.execPath)} ${quote(path.join(targetCliRoot, 'pixflow-design-cli.mjs'))} daemon status --daemon-url http://${host}:${port}`,
      stop: `${quote(process.execPath)} ${quote(path.join(targetCliRoot, 'pixflow-design-cli.mjs'))} daemon stop --daemon-url http://${host}:${port}`,
    },
  };

  if (flags.json) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    return;
  }

  process.stdout.write(`${result.message}\n`);
  process.stdout.write(`Install: ${installRoot}\n`);
  process.stdout.write(`Data: ${dataRoot}\n`);
  process.stdout.write(`Command: ${result.commands.bridge}\n`);
  if (daemon) {
    process.stdout.write(`Daemon: http://${host}:${port}\n`);
  }
}

function parseArgs(args) {
  const flags = {};
  for (let index = 0; index < args.length; index += 1) {
    const arg = args[index];
    if (!arg.startsWith('--')) {
      continue;
    }
    const raw = arg.slice(2);
    const eq = raw.indexOf('=');
    const key = camelCase(eq >= 0 ? raw.slice(0, eq) : raw);
    if (eq >= 0) {
      flags[key] = raw.slice(eq + 1);
      continue;
    }
    const next = args[index + 1];
    if (next && !next.startsWith('--')) {
      flags[key] = next;
      index += 1;
    } else {
      flags[key] = true;
    }
  }
  return flags;
}

function camelCase(value) {
  return String(value || '').replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
}

function firstString(...values) {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) {
      return value.trim();
    }
  }
  return '';
}

function positiveInteger(value, fallback) {
  const parsed = Number.parseInt(String(value || ''), 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function installMode(previousManifest, versionDelta) {
  if (!previousManifest.version) {
    return 'installed';
  }
  if (versionDelta > 0) {
    return 'updated';
  }
  if (versionDelta < 0) {
    return 'downgraded';
  }
  return 'repaired';
}

function installMessage(previousManifest, versionDelta) {
  const mode = installMode(previousManifest, versionDelta);
  if (mode === 'installed') return 'Pixflow Bridge installed.';
  if (mode === 'updated') return 'Pixflow Bridge updated.';
  if (mode === 'downgraded') return 'Pixflow Bridge downgraded.';
  return 'Pixflow Bridge repaired.';
}

function compareVersions(left, right) {
  const a = String(left || '').split(/[.-]/).map((part) => Number.parseInt(part, 10));
  const b = String(right || '').split(/[.-]/).map((part) => Number.parseInt(part, 10));
  const length = Math.max(a.length, b.length, 3);
  for (let index = 0; index < length; index += 1) {
    const av = Number.isFinite(a[index]) ? a[index] : 0;
    const bv = Number.isFinite(b[index]) ? b[index] : 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

function defaultSourceRoot() {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
}

function defaultInstallRoot() {
  if (process.platform === 'win32') {
    return path.join(firstString(process.env.LOCALAPPDATA, process.env.APPDATA, os.homedir()), 'Pixflow Bridge');
  }
  if (process.platform === 'darwin') {
    return path.join(os.homedir(), 'Library', 'Application Support', 'Pixflow Bridge');
  }
  return path.join(firstString(process.env.XDG_DATA_HOME, path.join(os.homedir(), '.local', 'share')), 'pixflow-bridge');
}

function assertNodeRuntime() {
  const major = Number.parseInt(process.versions.node.split('.')[0] || '0', 10);
  if (!Number.isFinite(major) || major < MIN_NODE_MAJOR) {
    throw new Error(`Pixflow Bridge requires Node.js ${MIN_NODE_MAJOR} or newer. Current runtime: ${process.version}`);
  }
}

async function assertSource(sourceCliRoot) {
  if (!existsSync(path.join(sourceCliRoot, 'pixflow-design-cli.mjs'))) {
    throw new Error(`Pixflow Design CLI source was not found at ${sourceCliRoot}`);
  }
}

async function readCliVersion(cliPath) {
  const source = await fs.readFile(cliPath, 'utf8');
  const match = source.match(/const\s+VERSION\s*=\s*['"]([^'"]+)['"]/);
  return match ? match[1] : '0.0.0';
}

async function copyDirectory(source, target) {
  await fs.mkdir(target, { recursive: true });
  await fs.cp(source, target, {
    recursive: true,
    force: true,
    errorOnExist: false,
  });
}

async function writeWrappers({ installRoot, appRoot, binRoot }) {
  const cliPath = path.join(appRoot, 'tools', 'pixflow-design-cli', 'pixflow-design-cli.mjs');
  const dataRoot = path.join(installRoot, 'data');

  await fs.writeFile(path.join(binRoot, 'pixflow-bridge.cmd'), [
    '@echo off',
    'setlocal',
    `"${process.execPath}" "${cliPath}" %*`,
    'endlocal',
    '',
  ].join('\r\n'), 'utf8');

  await fs.writeFile(path.join(binRoot, 'pixflow-bridge.ps1'), [
    '$ErrorActionPreference = "Stop"',
    `& "${process.execPath}" "${cliPath}" @args`,
    '',
  ].join('\n'), 'utf8');

  const shellWrapper = [
    '#!/usr/bin/env sh',
    `exec "${process.execPath}" "${cliPath}" "$@"`,
    '',
  ].join('\n');
  const shellPath = path.join(binRoot, 'pixflow-bridge');
  await fs.writeFile(shellPath, shellWrapper, 'utf8');
  try {
    await fs.chmod(shellPath, 0o755);
  } catch {
    // Windows chmod is best-effort for the portable shell wrapper.
  }

  await fs.writeFile(path.join(installRoot, 'start-daemon.cmd'), [
    '@echo off',
    'setlocal',
    `"${process.execPath}" "${cliPath}" daemon start --data-dir "${dataRoot}"`,
    'endlocal',
    '',
  ].join('\r\n'), 'utf8');
}

function startBridgeDaemon({ cliPath, dataRoot, host, port }) {
  const child = spawn(process.execPath, [
    cliPath,
    'daemon',
    'start',
    '--data-dir',
    dataRoot,
    '--host',
    host,
    '--port',
    String(port),
  ], {
    detached: true,
    stdio: 'ignore',
    windowsHide: true,
  });
  child.unref();
  return {
    pid: child.pid,
    url: `http://${host}:${port}`,
  };
}

async function readJson(filePath) {
  try {
    return JSON.parse(await fs.readFile(filePath, 'utf8'));
  } catch {
    return {};
  }
}

async function writeJson(filePath, value) {
  await fs.writeFile(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

function quote(value) {
  const text = String(value || '');
  if (!text || /[\s"']/u.test(text)) {
    return `"${text.replace(/"/g, '\\"')}"`;
  }
  return text;
}

main().catch((error) => {
  process.stderr.write(`Pixflow Bridge installer failed: ${error.message}\n`);
  process.exitCode = 1;
});
