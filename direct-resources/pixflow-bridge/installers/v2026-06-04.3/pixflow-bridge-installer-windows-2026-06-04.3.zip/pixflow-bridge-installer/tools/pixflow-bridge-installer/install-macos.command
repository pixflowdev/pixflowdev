#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALLER="$SCRIPT_DIR/tools/pixflow-bridge-installer/install-bridge.sh"
if [ ! -f "$INSTALLER" ]; then
  INSTALLER="$SCRIPT_DIR/install-bridge.sh"
fi

echo "Pixflow Bridge Setup"
echo
echo "This installer will install or update Pixflow Bridge and start the local daemon."
echo

sh "$INSTALLER" --start

echo
echo "Pixflow Bridge is installed and starting."
echo "Return to Pixflow Design, then click Detect daemon and Connect bridge."
echo
read -r -p "Press Return to close this window. " _
