#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
INSTALLER="$SCRIPT_DIR/tools/pixflow-bridge-installer/install-bridge.sh"
if [ ! -f "$INSTALLER" ]; then
  INSTALLER="$SCRIPT_DIR/install-bridge.sh"
fi

echo "Pixflow Bridge Setup"
echo
echo "This installer will install or update Pixflow Bridge and start the local daemon."
echo

sh "$INSTALLER" --start

echo
echo "Pixflow Bridge is installed and starting."
echo "Return to Pixflow Design, then click Detect daemon and Connect bridge."
echo
printf "Press Return to close this window. "
read close_input || true
