#!/usr/bin/env sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

echo "Pixflow Bridge Setup"
echo
echo "This installer will install or update Pixflow Bridge and start the local daemon."
echo

sh "$SCRIPT_DIR/install-bridge.sh" --start

echo
echo "Pixflow Bridge is installed and starting."
echo "Return to Pixflow Design, then click Detect daemon and Connect bridge."
echo
printf "Press Return to close this window. "
read close_input || true

