#!/usr/bin/env sh
set -eu

MIN_NODE_MAJOR=20
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REPO_ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd)
INSTALLER="$SCRIPT_DIR/install-bridge.mjs"
INSTALL_ROOT=""
PORT="47873"
HOST_NAME="127.0.0.1"
START="0"
NO_START="0"
NO_NODE_INSTALL="0"
ALLOW_DOWNGRADE="0"
JSON="0"

node_major() {
  if ! command -v node >/dev/null 2>&1; then
    echo 0
    return
  fi
  node --version 2>/dev/null | sed -n 's/^v\{0,1\}\([0-9][0-9]*\).*/\1/p'
}

install_node_runtime() {
  if [ "$NO_NODE_INSTALL" = "1" ]; then
    echo "Node.js $MIN_NODE_MAJOR or newer is required. Re-run without --no-node-install or install Node.js first." >&2
    exit 1
  fi

  if command -v brew >/dev/null 2>&1; then
    echo "Installing or updating Node.js with Homebrew..."
    brew install node || brew upgrade node
    return
  fi

  if command -v apt-get >/dev/null 2>&1; then
    echo "Installing Node.js with apt-get..."
    sudo apt-get update
    sudo apt-get install -y nodejs npm
    return
  fi

  if command -v dnf >/dev/null 2>&1; then
    echo "Installing Node.js with dnf..."
    sudo dnf install -y nodejs npm
    return
  fi

  if command -v yum >/dev/null 2>&1; then
    echo "Installing Node.js with yum..."
    sudo yum install -y nodejs npm
    return
  fi

  if command -v pacman >/dev/null 2>&1; then
    echo "Installing Node.js with pacman..."
    sudo pacman -Sy --needed nodejs npm
    return
  fi

  echo "Node.js $MIN_NODE_MAJOR or newer is required and no supported package manager was found." >&2
  exit 1
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --install-root)
      INSTALL_ROOT="$2"
      shift 2
      ;;
    --source-root)
      REPO_ROOT="$2"
      shift 2
      ;;
    --port)
      PORT="$2"
      shift 2
      ;;
    --host)
      HOST_NAME="$2"
      shift 2
      ;;
    --start)
      START="1"
      shift
      ;;
    --no-start)
      NO_START="1"
      shift
      ;;
    --no-node-install)
      NO_NODE_INSTALL="1"
      shift
      ;;
    --allow-downgrade)
      ALLOW_DOWNGRADE="1"
      shift
      ;;
    --json)
      JSON="1"
      shift
      ;;
    *)
      echo "Unknown option: $1" >&2
      exit 2
      ;;
  esac
done

MAJOR=$(node_major)
if [ -z "$MAJOR" ]; then
  MAJOR=0
fi

if [ "$MAJOR" -lt "$MIN_NODE_MAJOR" ]; then
  install_node_runtime
  MAJOR=$(node_major)
  if [ -z "$MAJOR" ]; then
    MAJOR=0
  fi
fi

if [ "$MAJOR" -lt "$MIN_NODE_MAJOR" ]; then
  echo "Node.js $MIN_NODE_MAJOR or newer is required after install/update. Current major version: $MAJOR." >&2
  exit 1
fi

set -- "$INSTALLER" --source-root "$REPO_ROOT" --port "$PORT" --host "$HOST_NAME"
if [ -n "$INSTALL_ROOT" ]; then
  set -- "$@" --install-root "$INSTALL_ROOT"
fi
if [ "$START" = "1" ] && [ "$NO_START" != "1" ]; then
  set -- "$@" --start
fi
if [ "$NO_START" = "1" ]; then
  set -- "$@" --no-start
fi
if [ "$ALLOW_DOWNGRADE" = "1" ]; then
  set -- "$@" --allow-downgrade
fi
if [ "$JSON" = "1" ]; then
  set -- "$@" --json
fi

exec node "$@"
