@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "INSTALLER=%SCRIPT_DIR%install-bridge.ps1"

echo Pixflow Bridge Setup
echo.
echo This installer will install or update Pixflow Bridge and start the local daemon.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -File "%INSTALLER%" -Start
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%EXIT_CODE%"=="0" (
  echo Pixflow Bridge setup did not complete.
  echo Keep this window open and send the message above to Pixflow support if needed.
  pause
  exit /b %EXIT_CODE%
)

echo Pixflow Bridge is installed and starting.
echo Return to Pixflow Design, then click Detect daemon and Connect bridge.
pause

