# Resend Source Evidence

## Source Scope

This Design System 2.0 backfill is derived from the curated Pixflow Design bundled fixture.
It does not claim a fresh crawl of the original upstream brand repository or website.

## Included Fixture Files

- design-systems/resend/DESIGN.md
- design-systems/resend/tokens.css
- design-systems/resend/components.html

## Token Contract

`source/token-contract.report.json` maps every TOKEN_SCHEMA binding back to the committed `tokens.css` declaration line.
`design-tokens.json` and `tailwind-v4.css` are derived outputs and should be regenerated from the report and token stylesheet rather than edited by hand.
