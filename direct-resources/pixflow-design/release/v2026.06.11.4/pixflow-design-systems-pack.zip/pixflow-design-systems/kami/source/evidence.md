# kami (紙 / 纸) Source Evidence

## Source Scope

This Design System 2.0 backfill is derived from the curated Pixflow Design bundled fixture.
It does not claim a fresh crawl of the original upstream brand repository or website.

## Included Fixture Files

- design-systems/kami/DESIGN.md
- design-systems/kami/tokens.css
- design-systems/kami/components.html

## Token Contract

`source/token-contract.report.json` maps every TOKEN_SCHEMA binding back to the committed `tokens.css` declaration line.
`design-tokens.json` and `tailwind-v4.css` are derived outputs and should be regenerated from the report and token stylesheet rather than edited by hand.
