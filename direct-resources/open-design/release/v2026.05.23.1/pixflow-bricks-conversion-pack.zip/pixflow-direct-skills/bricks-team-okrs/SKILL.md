---
key: bricks-team-okrs
extends: team-okrs
label: Bricks Team OKRs
---

# Bricks Team OKRs Skill

Use this pack for OKR, quarterly goals, team status, and progress pages. The final output must remain editable Bricks JSON using Pixflow variables, semantic global classes, and short BEM names.

Before planning sections, identify the user's real task, the page state being represented, the proof or support needed, and any factual boundaries. Do not convert this into a generic marketing homepage. Use Open Design-style critique to remove repeated card grids, fake claims, empty media wrappers, and weak hierarchy before Bricks compilation.
