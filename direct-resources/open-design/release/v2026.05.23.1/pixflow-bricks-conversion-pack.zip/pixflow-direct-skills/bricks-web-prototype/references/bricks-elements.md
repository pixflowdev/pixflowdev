# Bricks Web Prototype Element Contract

Use the Bricks Builder skill rules for page JSON.

## Allowed Elements

- `section`, `container`, `block`, `div`
- `heading`, `text-basic`, `button`, `image`

## Required Bricks Discipline

- `section > container > content` hierarchy.
- Flat responsive override keys.
- Generated global-class IDs in `_cssGlobalClasses`.
- Short BEM names.
- No raw HTML, script tags, imported CSS, or unsupported Bricks elements.

## Placeholder Discipline

- Wireframe mode: grey labelled blocks.
- High-fidelity mode: polished editable Bricks surfaces.
- Real screenshot requested as media: use `image` with supplied attachment.
- Product UI requested: use editable Bricks blocks first.
