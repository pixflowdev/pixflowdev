# Bricks Web Prototype Style Spec Contract

## Bricks Settings First

Prefer Bricks settings for spacing, layout, type, background, border, radius, and sizing.

## Scoped Custom CSS

Use `_cssCustom` with `%root%` only for:

- simple transforms
- overlap/collage detail
- local pseudo-elements
- clipping/masks
- advanced but safe backgrounds

## Token Rules

- `var(--background)` for sections.
- `var(--foreground)` for surfaces.
- `var(--border)` for neutral borders.
- `var(--radius--surface)` and `var(--border--surface)` for cards/images.
- `var(--radius--btn)` and `var(--border--btn)` for buttons, badges, and fields.
