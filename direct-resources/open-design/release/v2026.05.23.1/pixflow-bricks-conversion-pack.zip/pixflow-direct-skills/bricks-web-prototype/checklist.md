# Bricks Web Prototype Checklist

## P0

- [ ] The output is Bricks section/style specs, not raw HTML as the final target.
- [ ] A section rhythm is chosen before copy.
- [ ] The page does not use the same layout family twice in a row.
- [ ] No invented metrics, testimonials, logos, or fake product claims.
- [ ] Pixflow tokens and Bricks object shapes are used.

## P1

- [ ] The first screen has one strong visual thesis.
- [ ] Reference screenshots influence hierarchy and spacing without being copied as fragile decorative CSS.
- [ ] Media placeholders are honest and labelled.

## P2

- [ ] Mobile order is clear and readable.
